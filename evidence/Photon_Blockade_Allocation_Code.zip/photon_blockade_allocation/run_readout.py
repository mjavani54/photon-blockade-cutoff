"""Study how photon-register readout error changes the antibunching shot budget."""

import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path
import platform
from math import isfinite, sqrt
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
import scipy
from scipy.optimize import brentq

from cavity import Case, solve_steady_state
from readout_intervals import (
    LEVELS, ZERO_RATES, binomial_box, g2, g2_interval, observed_distribution,
    photon_tails, prospective_box,
)
from sampling import ALPHA, BETA, SHOT_GRID, SHOT_TOLERANCE


HERE = Path(__file__).resolve().parent
POINT_FILE = HERE / "followup_operating_point.json"
RULE_FILE = HERE / "pilot_rule.json"
SEED = 732991
SYMMETRIC_RATES = (0, 0.0001, 0.00025, 0.0005, 0.001, 0.0025, 0.005, 0.01, 0.02, 0.03, 0.05)
METHODS = (("raw", 0), ("known_matrix", 0), ("calibrated_10000", 10_000), ("calibrated_100000", 100_000))
RESULTS_ZIP = "Photon_Blockade_Readout_Results.zip"


def source_cases():
    source = json.loads(POINT_FILE.read_text(encoding="utf-8"))
    settings = json.loads(RULE_FILE.read_text(encoding="utf-8"))["settings"]
    if (settings["alpha"], settings["beta"], settings["shot_tolerance"], settings["shot_grid"]) != (
        ALPHA, BETA, SHOT_TOLERANCE, SHOT_GRID.tolist()
    ):
        raise ValueError("Shot settings differ from the frozen pilot settings")

    case = source["case"]
    probabilities = np.array(source["probabilities"], dtype=float)
    mean = float(probabilities @ LEVELS)
    if (
        case["guard_cutoff"] != 3 or len(probabilities) != 4
        or not np.isclose(mean, case["selected_mean"], rtol=1e-12, atol=0)
        or not np.isclose(g2(probabilities), case["selected_g2"], rtol=1e-12, atol=0)
    ):
        raise ValueError("The operating point and the four-level populations disagree")
    target = {
        "case_id": case["case_id"], "reference_g2": case["reference_g2"],
        "reference_mean": case["reference_mean"], "finite_mean": mean,
        "probabilities": probabilities.tolist(), "finite_g2": g2(probabilities),
    }

    def empty_state(drive):
        empty = Case("empty-matched", "control", "", drive, 0.0, (), (), ())
        return solve_steady_state(empty, 3)

    drive = brentq(lambda d: empty_state(d).mean - mean, 0.25 * sqrt(mean), sqrt(mean), xtol=1e-13)
    vacuum = empty_state(drive)
    control = {
        "case_id": "empty-matched", "reference_g2": 1.0, "reference_mean": 4 * drive**2,
        "finite_mean": vacuum.mean, "probabilities": vacuum.probabilities.tolist(),
        "finite_g2": vacuum.g2, "drive": drive, "cavity_detuning": 0.0,
    }
    for model in (target, control):
        scale = max(1.0, model["finite_g2"])
        model.update(cutoff_budget=settings["cutoff_tolerance"] * scale, shot_tolerance=SHOT_TOLERANCE * scale)
        if abs(model["finite_g2"] - model["reference_g2"]) > model["cutoff_budget"]:
            raise ValueError(f"Cutoff error exceeds budget for {model['case_id']}")
    return source, target, control


def modeled_scenarios(smoke):
    rates = (0, 0.01) if smoke else SYMMETRIC_RATES
    scenarios = [
        {"name": f"symmetric_{rate:g}", "rates": [rate] * 4} for rate in rates
    ]
    scenarios.append({"name": "asymmetric_msb_loss_0.05", "rates": [0.001, 0.001, 0.0001, 0.05]})
    return scenarios


def probability_bounds(method, rates, calibration_shots, batches, rng):
    """Build the prospective and realized readout-rate intervals."""
    if calibration_shots == 0:
        center = ZERO_RATES if method == "raw" else rates
        return (center, center), (center, center), ALPHA, BETA / 6
    # Four rate counts from the two prepared calibration states plus three science tails.
    marginal_tail = BETA / 14
    planning = prospective_box(calibration_shots, rates, ALPHA / 2, marginal_tail)
    observed_counts = rng.binomial(calibration_shots, rates, size=(batches, len(rates)))
    realized = binomial_box(calibration_shots, observed_counts, observed_counts, ALPHA / 2)
    return planning, realized, ALPHA / 2, marginal_tail


def shot_plans(target, observed, rate_box, data_alpha, marginal_tail):
    tails = photon_tails(observed)
    tail_box = prospective_box(SHOT_GRID, tails, data_alpha, marginal_tail)
    lower, upper = g2_interval(tail_box, rate_box)
    limit_lower, limit_upper = g2_interval((tails, tails), rate_box)
    width = upper - lower
    cutoff_budget = target["cutoff_budget"]
    criteria = {
        "decision": upper + cutoff_budget < 1,
        "precision": width <= 2 * target["shot_tolerance"],
    }
    specs = {}
    for goal, criterion in criteria.items():
        indices = np.flatnonzero(criterion)
        index = int(indices[0]) if indices.size else len(SHOT_GRID) - 1
        specs[goal] = {
            "plan_pass": bool(indices.size), "science_shots": int(SHOT_GRID[index]),
            "planning_g2_lower": finite(lower[index]), "planning_g2_upper": finite(upper[index]),
            "planning_width": finite(width[index]),
            "infinite_shot_g2_upper": finite(limit_upper + cutoff_budget),
            "infinite_shot_width": finite(limit_upper - limit_lower),
        }
    return specs


def batch_outcome(model, observed, shots, rate_box, alpha, batches, rng):
    counts = rng.multinomial(shots, observed, size=batches)
    tails = np.cumsum(counts[:, :0:-1], axis=-1)[:, ::-1]
    lower, upper = g2_interval(binomial_box(shots, tails, tails, alpha), rate_box)
    cutoff_budget = model["cutoff_budget"]
    reference_g2 = model["reference_g2"]
    midpoint = lower + 0.5 * (upper - lower)
    return {
        "batches": batches,
        "antibunching_calls": int((upper + cutoff_budget < 1).sum()),
        "reference_covered": int(((lower - cutoff_budget <= reference_g2) & (reference_g2 <= upper + cutoff_budget)).sum()),
        "width_target_met": int(((upper - lower) <= 2 * model["shot_tolerance"]).sum()),
        "precision_target_met": int((np.abs(midpoint - reference_g2) <= cutoff_budget + model["shot_tolerance"]).sum()),
        "median_midpoint": finite(np.median(midpoint)),
        "median_adjusted_upper": finite(np.median(upper + cutoff_budget)),
    }


def finite(value):
    return float(value) if isfinite(value) else None


def scenario_results(scenario, scenario_index, models, source_case, batches):
    rates = np.asarray(scenario["rates"], dtype=float)
    target, control = models
    observed = [observed_distribution(np.asarray(model["probabilities"]), rates) for model in models]
    context = {
        "scenario": scenario["name"], "lsb_0_to_1": rates[0], "lsb_1_to_0": rates[1],
        "msb_0_to_1": rates[2], "msb_1_to_0": rates[3],
        "raw_target_g2": g2(observed[0]), "raw_control_g2": g2(observed[1]),
    }
    plan_rows = []
    batch_rows = []
    estimates = {}
    for method, calibration_shots in METHODS:
        shots_overhead = 2 * calibration_shots
        cal_rng = np.random.default_rng(np.random.SeedSequence([SEED, scenario_index, calibration_shots, 0]))
        planning, realized, data_alpha, beta = probability_bounds(method, rates, calibration_shots, batches, cal_rng)
        plans = shot_plans(target, observed[0], planning, data_alpha, beta)
        costs = {}
        for goal, plan in plans.items():
            plan_rows.append({
                **context, "method": method, "goal": goal, **plan,
                "calibration_shots": shots_overhead, "total_shots": plan["science_shots"] + shots_overhead,
            })
            costs[goal] = (
                {"science_shots": plan["science_shots"], "total_shots": plan["science_shots"] + shots_overhead}
                if plan["plan_pass"] else None
            )

        if np.all(rates == 0) and method in ("raw", "known_matrix"):
            for goal in plans:
                assert plans[goal]["plan_pass"] and plans[goal]["science_shots"] == source_case[f"{goal}_shots_used"]

        budgets = {goal: plan["science_shots"] for goal, plan in plans.items()}
        budgets["fixed_ideal_decision"] = source_case["decision_shots_used"]
        decisions_at_ideal = {}
        for goal, science_shots in budgets.items():
            for index, (model, probabilities) in enumerate(zip((target, control), observed, strict=True), 1):
                rng = np.random.default_rng(np.random.SeedSequence([SEED, scenario_index, science_shots, index]))
                outcome = batch_outcome(model, probabilities, science_shots, realized, data_alpha, batches, rng)
                batch_rows.append({
                    "scenario": scenario["name"], "method": method, "goal": goal,
                    "case_id": model["case_id"], "science_shots": science_shots,
                    "calibration_shots": shots_overhead, "total_shots": science_shots + shots_overhead,
                    "plan_pass": plans[goal]["plan_pass"] if goal in plans else None, **outcome,
                })
                if goal == "fixed_ideal_decision":
                    decisions_at_ideal[model["case_id"]] = outcome["antibunching_calls"]

        ratio = (costs["precision"]["total_shots"] / costs["decision"]["total_shots"]
                 if costs["precision"] and costs["decision"] else None)
        estimates[method] = {
            **costs, "precision_to_decision_total_shot_ratio": ratio,
            "antibunching_calls_at_ideal_decision_budget": decisions_at_ideal,
        }
    return plan_rows, batch_rows, {**context, "estimates": estimates}


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, help="Output directory")
    parser.add_argument("--smoke", action="store_true", help="Run three noise conditions with 16 batches")
    args = parser.parse_args()
    source, target, control = source_cases()
    scenarios = modeled_scenarios(args.smoke)
    batches = 16 if args.smoke else 512
    folder = args.out or Path("photon_blockade_readout_smoke" if args.smoke else "photon_blockade_readout_results")
    folder.mkdir(parents=True, exist_ok=True)
    meta = {
        "source": source, "cases": [target, control], "scenarios": scenarios,
        "cutoff": 3, "seed": SEED, "batches": batches, "mode": "smoke" if args.smoke else "full",
        "alpha": ALPHA, "beta": BETA, "shot_grid": SHOT_GRID.tolist(),
        "methods": [{"name": name, "calibration_shots_per_prepared_state": per_state} for name, per_state in METHODS],
        "runtime": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__},
        "input_sha256": {name: sha256((HERE / name).read_bytes()).hexdigest() for name in
                         ("run_readout.py", "readout_intervals.py", "cavity.py", "sampling.py", POINT_FILE.name, RULE_FILE.name)},
    }
    plan_rows = []
    batch_rows = []
    summaries = []
    for index, scenario in enumerate(scenarios, 1):
        plans, checks, summary = scenario_results(scenario, index, (target, control), source["case"], batches)
        plan_rows.extend(plans)
        batch_rows.extend(checks)
        summaries.append(summary)
        print(f"Completed {index}/{len(scenarios)} noise conditions", flush=True)

    write_csv(folder / "plans.csv", plan_rows)
    write_csv(folder / "batches.csv", batch_rows)
    for name, data in (("manifest.json", meta), ("summary.json", summaries)):
        (folder / name).write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    archive = folder / ("Photon_Blockade_Readout_Smoke.zip" if args.smoke else RESULTS_ZIP)
    temp = archive.with_suffix(".part")
    with ZipFile(temp, "w", compression=ZIP_DEFLATED) as result:
        for name in ("manifest.json", "summary.json", "plans.csv", "batches.csv"):
            result.write(folder / name, name)
    temp.replace(archive)
    print(f"Results written to {archive.resolve()}", flush=True)


if __name__ == "__main__":
    main()
