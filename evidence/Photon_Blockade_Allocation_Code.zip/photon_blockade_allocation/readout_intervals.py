"""Readout probabilities and confidence bounds for a four-level photon register."""

from itertools import product

import numpy as np
from scipy.special import betaincinv
from scipy.stats import binom


LEVELS = np.arange(4)
LSB = LEVELS % 2
MSB = LEVELS // 2
ZERO_RATES = np.zeros(4)
RATE_CORNERS = np.array(list(product((False, True), repeat=4)))


def observed_distribution(probabilities, rates):
    """Map true levels to observed levels with independent bit assignment."""
    up0, down0, up1, down1 = rates
    low = np.array([[1 - up0, down0], [up0, 1 - down0]])
    high = np.array([[1 - up1, down1], [up1, 1 - down1]])
    observed = np.kron(high, low) @ probabilities
    return observed / observed.sum()


def g2(probabilities):
    mean = probabilities @ LEVELS
    return float((probabilities @ (LEVELS * (LEVELS - 1))) / mean**2)


def photon_tails(probabilities):
    return np.clip(np.cumsum(probabilities[:0:-1])[::-1], 0.0, 1.0)


def binomial_box(shots, counts_low, counts_high, alpha):
    """Simultaneous exact bounds across the supplied binomial count columns."""
    tail = alpha / (2 * counts_low.shape[-1])
    lower = np.where(
        counts_low == 0, 0.0,
        betaincinv(np.maximum(counts_low, 1), shots - counts_low + 1, tail),
    )
    upper = np.where(
        counts_high == shots, 1.0,
        betaincinv(counts_high + 1, np.maximum(shots - counts_high, 1), 1 - tail),
    )
    return lower, upper


def prospective_box(shots, probabilities, alpha, marginal_tail):
    """Enclose the confidence intervals produced by a likely band of counts."""
    shots = np.asarray(shots)[..., None]
    low_counts = binom.ppf(marginal_tail, shots, probabilities)
    high_counts = binom.ppf(1 - marginal_tail, shots, probabilities)
    return binomial_box(shots, low_counts, high_counts, alpha)


def corrected_weights(rates):
    """Unbiased moment weights for n and n(n-1) for given assignment rates."""
    up0, down0, up1, down1 = np.moveaxis(rates, -1, 0)
    gain0 = np.maximum(1 - up0 - down0, 1e-12)
    gain1 = np.maximum(1 - up1 - down1, 1e-12)
    x0 = (LSB - up0[..., None]) / gain0[..., None]
    x1 = (MSB - up1[..., None]) / gain1[..., None]
    return np.stack((x0 + 2 * x1, 2 * x1 + 4 * x0 * x1), axis=-2)


def g2_interval(tail_box, rate_box):
    """Bound the true cutoff correlation over observed tails and rate intervals."""
    tails_low, tails_high = tail_box
    rates_low, rates_high = rate_box
    corners = np.where(RATE_CORNERS, rates_high[..., None, :], rates_low[..., None, :])
    weights = corrected_weights(corners)
    increments = np.diff(weights, axis=-1)
    low = tails_low[..., None, None, :]
    high = tails_high[..., None, None, :]
    offsets = weights[..., 0]
    lower = offsets + (increments * np.where(increments >= 0, low, high)).sum(axis=-1)
    upper = offsets + (increments * np.where(increments >= 0, high, low)).sum(axis=-1)
    minima = np.maximum(lower.min(axis=-2), 0.0)
    maxima = np.minimum(upper.max(axis=-2), [3.0, 6.0])

    # A physically unconstrained interval is safe for singular or inconsistent boxes.
    usable = (rates_high[..., :2].sum(axis=-1) < 1) & (rates_high[..., 2:].sum(axis=-1) < 1)
    usable = usable & np.all(minima <= maxima, axis=-1)
    mean_low, pair_low = np.moveaxis(minima, -1, 0)
    mean_high, pair_high = np.moveaxis(maxima, -1, 0)
    bound_low = np.divide(pair_low, mean_high**2, out=np.zeros_like(mean_high), where=mean_high > 0)
    bound_high = np.divide(
        pair_high, mean_low**2, out=np.full_like(mean_low, np.inf), where=mean_low > 0,
    )
    return np.where(usable, bound_low, 0.0), np.where(usable, bound_high, np.inf)
