"""Steady states of a driven, lossy cavity with zero, one, or two emitters."""

from dataclasses import dataclass
from functools import reduce

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve


@dataclass(frozen=True)
class Case:
    case_id: str
    group: str
    pair_id: str
    drive: float
    cavity_detuning: float
    couplings: tuple[float, ...]
    emitter_detunings: tuple[float, ...]
    emitter_decays: tuple[float, ...]


@dataclass(frozen=True)
class SteadyState:
    probabilities: np.ndarray
    mean: float
    g2: float
    residual: float


def tensor(*operators):
    return reduce(lambda left, right: sparse.kron(left, right, format="csc"), operators)


def solve_steady_state(case: Case, cutoff: int) -> SteadyState:
    """Retain photon numbers 0 through cutoff. The cavity decay rate is one."""
    photon_dimension = cutoff + 1
    emitter_count = len(case.couplings)
    emitter_dimension = 2**emitter_count
    dimension = photon_dimension * emitter_dimension
    annihilate = sparse.diags(
        np.sqrt(np.arange(1, photon_dimension)), 1, format="csc"
    )
    a = tensor(annihilate, sparse.eye(emitter_dimension, format="csc"))
    a_dagger = a.getH()
    hamiltonian = (
        case.cavity_detuning * (a_dagger @ a) + case.drive * (a + a_dagger)
    )
    collapse_operators = [a]
    lower = sparse.csc_matrix([[0.0, 1.0], [0.0, 0.0]])
    for index, (g, detuning, decay) in enumerate(
        zip(case.couplings, case.emitter_detunings, case.emitter_decays, strict=True)
    ):
        sigma = tensor(
            sparse.eye(photon_dimension * 2**index, format="csc"),
            lower,
            sparse.eye(2 ** (emitter_count - index - 1), format="csc"),
        )
        sigma_dagger = sigma.getH()
        hamiltonian += detuning * (sigma_dagger @ sigma)
        hamiltonian += g * (a_dagger @ sigma + a @ sigma_dagger)
        collapse_operators.append(np.sqrt(decay) * sigma)

    identity = sparse.eye(dimension, format="csc")
    liouvillian = -1j * (
        tensor(identity, hamiltonian) - tensor(hamiltonian.T, identity)
    )
    for collapse in collapse_operators:
        rate_operator = collapse.getH() @ collapse
        liouvillian += tensor(collapse.conjugate(), collapse) - 0.5 * (
            tensor(identity, rate_operator) + tensor(rate_operator.T, identity)
        )

    system = liouvillian.tolil()
    trace_indices = np.arange(0, dimension**2, dimension + 1)
    system.rows[0] = trace_indices.tolist()
    system.data[0] = [1.0 + 0j] * dimension
    target = np.zeros(dimension**2, dtype=complex)
    target[0] = 1
    vector = spsolve(system.tocsc(), target)
    density = vector.reshape((dimension, dimension), order="F")
    residual = float(np.max(np.abs(liouvillian @ vector)))
    if (
        not np.all(np.isfinite(vector))
        or residual > 1e-10
        or abs(np.trace(density) - 1) > 1e-10
        or np.max(np.abs(density - density.conj().T)) > 1e-10
        or np.linalg.eigvalsh((density + density.conj().T) / 2)[0] < -1e-10
    ):
        raise ArithmeticError(f"Invalid steady state for {case.case_id} at cutoff {cutoff}")

    probabilities = density.diagonal().real.reshape(photon_dimension, -1).sum(axis=1)
    probabilities = np.maximum(probabilities, 0.0)
    probabilities /= probabilities.sum()
    numbers = np.arange(photon_dimension)
    mean = float(probabilities @ numbers)
    if mean <= 0:
        raise ArithmeticError(f"Undefined g2 for {case.case_id} at cutoff {cutoff}")
    g2 = float((probabilities @ (numbers * (numbers - 1))) / mean**2)
    return SteadyState(probabilities, mean, g2, residual)
