"""Finite-sample intervals and prospective shot counts for direct photon readout."""

import numpy as np
from scipy.special import betaincinv
from scipy.stats import binom


SHOT_GRID = np.unique(np.rint(np.geomspace(1_000, 100_000_000, 51)).astype(np.int64))
ALPHA = 0.05
BETA = 0.05
SHOT_TOLERANCE = 0.075
BATCHES = 256


def g2_bounds(counts_low, counts_high, shots):
    """Use simultaneous binomial confidence limits for all photon-number tails.

    Equal count arrays give the interval for an observed histogram. Distinct
    arrays give an interval enclosing all intervals for counts within the band.
    """
    cutoff = counts_low.shape[-1]
    tail_alpha = ALPHA / (2 * cutoff)
    lower = np.where(
        counts_low == 0,
        0.0,
        betaincinv(np.maximum(counts_low, 1), shots - counts_low + 1, tail_alpha),
    )
    upper = np.where(
        counts_high == shots,
        1.0,
        betaincinv(counts_high + 1, np.maximum(shots - counts_high, 1), 1 - tail_alpha),
    )
    weights = 2 * np.arange(cutoff)
    mean_lower = lower.sum(axis=-1)
    pair_lower = lower @ weights
    mean_upper = upper.sum(axis=-1)
    pair_upper = upper @ weights
    g2_lower = pair_lower / mean_upper**2
    g2_upper = np.divide(
        pair_upper,
        mean_lower**2,
        out=np.full_like(mean_lower, np.inf),
        where=mean_lower > 0,
    )
    return g2_lower, g2_upper


def plan_shots(probabilities, tolerance):
    """Find the first grid point with a 95%-probability upper bound on width."""
    tails = np.clip(np.cumsum(probabilities[:0:-1])[::-1], 0.0, 1.0)
    shots = SHOT_GRID[:, None]
    tail_beta = BETA / (2 * len(tails))
    counts_low = binom.ppf(tail_beta, shots, tails)
    counts_high = binom.ppf(1 - tail_beta, shots, tails)
    lower, upper = g2_bounds(counts_low, counts_high, shots)
    widths = upper - lower
    passed = np.flatnonzero(widths <= 2 * tolerance)
    index = int(passed[0]) if passed.size else len(SHOT_GRID) - 1
    return int(SHOT_GRID[index]), bool(passed.size), float(widths[index])


def evaluate_shots(probabilities, shots, rng, finite_g2, reference_g2, cutoff_budget, shot_budget):
    """Repeat independent fixed-size batches at the planned or capped shot count."""
    counts = rng.multinomial(shots, probabilities, size=BATCHES)
    tails = np.cumsum(counts[:, :0:-1], axis=-1)[:, ::-1]
    lower, upper = g2_bounds(tails, tails, shots)
    midpoint = lower + (upper - lower) / 2
    coverage = (lower <= finite_g2) & (finite_g2 <= upper)
    expanded_lower = np.maximum(0.0, lower - cutoff_budget)
    expanded_upper = upper + cutoff_budget
    physical_coverage = (expanded_lower <= reference_g2) & (reference_g2 <= expanded_upper)
    accurate = np.abs(midpoint - reference_g2) <= cutoff_budget + shot_budget
    precise = (upper - lower) <= 2 * shot_budget
    return {
        "batch_width_pass": int(precise.sum()),
        "batch_finite_coverage": int(coverage.sum()),
        "batch_reference_coverage": int(physical_coverage.sum()),
        "batch_total_error_pass": int(accurate.sum()),
        "batch_coverage_and_width_pass": int((coverage & precise).sum()),
        "batch_antibunching": int((expanded_upper < 1).sum()),
        "batch_bunching": int((expanded_lower > 1).sum()),
        "batch_zero_pairs": int((tails[:, 1] == 0).sum()),
    }
