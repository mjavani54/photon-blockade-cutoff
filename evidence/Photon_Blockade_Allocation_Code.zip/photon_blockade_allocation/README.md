# Joint calibration and science shot allocation

This simulation minimizes the total $K_{00}+K_{11}+N_{\rm sci}$ for the two-photon-qubit readout experiment. $K_{00}$ and $K_{11}$ are the calibration shots on the two prepared basis states, and $N_{\rm sci}$ is the number of photon-register measurements. The run optimizes that total separately for detecting antibunching and estimating $g^{(2)}(0)$ to the original precision.

## Run on macOS or Linux

Open Terminal in this folder. Use Python 3.10 or newer.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_allocation.py
```

Upload `photon_blockade_allocation_results/Photon_Blockade_Allocation_Results.zip` for analysis. The run uses the CPU and draws count histograms directly. An optional `python run_allocation.py --smoke` checks the original operating point at 2% error with 32 batches and writes to a separate folder.

## Operating points

The four-level photon distributions come from the frozen two-emitter follow-up. Each signal has a resonantly driven empty-cavity control matched to its finite-cutoff mean photon number. The physical empty-cavity reference has $g^{(2)}(0)=1$.

| Operating point | Converged $g^{(2)}(0)$ | Mean photons at cutoff 3 |
| --- | ---: | ---: |
| `polariton-027-equal` | 0.5450 | 0.15590 |
| `polariton-027-unequal` | 0.5235 | 0.14418 |
| `polariton-032-unequal` | 0.4925 | 0.06072 |
| `broad-015-unequal` | 0.9145 | 0.15154 |

The six modeled channels use independent assignment errors for the two binary photon bits. Five symmetric conditions use 0.5%, 1%, 2%, 3%, and 5% error in either direction per bit. The sixth is the asymmetric high-bit loss case from the readout study. All measurements use levels 0 through 3. The dim operating point uses the cutoff-3 populations from its follow-up trace. Its original two-qubit encoding also supported the cutoff-2 choice.

## Allocation and validation

| Policy | Calibration and science budget |
| --- | --- |
| Exact rates | Use the supplied assignment rates and search only the science shot grid |
| Fixed calibration | Use 100,000 shots per basis state and search the science shot grid |
| Optimized equal | Search for a common calibration budget for both basis states |
| Optimized separate | Search for both calibration budgets independently |

Each calibration grid has 49 sizes between 10,000 and 10,000,000 shots. The science grid uses the 51 sizes from $10^3$ to $10^8$ used in the original study. At each calibration pair, the optimizer tests every science size and takes the first passing value. It chooses the lowest total over the allowed pairs and breaks ties by fewer science shots, then fewer `00` calibration shots. The result is the minimum on the tested grid.

The decision goal requires the upper confidence limit plus the cutoff allowance of 0.025 to fall below 1. The precision goal requires a statistical interval of width at most 0.15. The optimization uses the existing simultaneous Clopper–Pearson intervals, the original split of confidence error between finite calibration and science measurements, and a joint count band with at least 95% probability under the planning model. The true simulated assignment rates and photon distributions supply that prospective model.

The validation samples 1,024 fresh batches for each selected plan. It estimates the assignment rates from independent calibration counts in each batch. The signal and its matched control have the same shot counts and share their simulated calibration draw. The total reported for a plan includes both calibration circuits and the signal measurements. The empty-control batches are a separate validation experiment.

## Result archive

| File | Contents |
| --- | --- |
| `manifest.json` | Operating points, matched controls, rates, grids, seed, and input hashes |
| `plans.csv` | Chosen allocations, total shots, and prospective bounds |
| `validation.csv` | Detection, false calls, interval coverage, and precision results |
| `allocation_grid.csv` | Smallest passing science count for each calibration pair and goal |

In the grid, an empty science count means the criterion stayed unmet through the science cap. In the plan table, `at_cap` identifies a benchmark evaluated at the cap with the criterion unmet. `grid_exhausted` means there was no passing allocation for that policy on the tested grid. The readout channel assumes ideal photon populations and ideal calibration-state preparation.
