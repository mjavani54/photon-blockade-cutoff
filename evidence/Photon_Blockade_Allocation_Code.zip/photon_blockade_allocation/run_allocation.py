"""Choose calibration and science shots jointly for photon blockade measurements."""

import argparse
from hashlib import sha256
import json
from math import sqrt
from pathlib import Path
import platform
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
import scipy
from scipy.optimize import brentq

from cavity import Case, solve_steady_state
from readout_intervals import (
    LEVELS, binomial_box, g2, g2_interval, observed_distribution, photon_tails, prospective_box,
)
from run_readout import ALPHA, BETA, SHOT_GRID, SHOT_TOLERANCE, batch_outcome, finite, shot_plans, write_csv


HERE = Path(__file__).resolve().parent
INPUTS = HERE / "allocation_inputs.json"
RULE = HERE / "pilot_rule.json"
CALIBRATION_GRID = np.unique(np.rint(np.geomspace(10_000, 10_000_000, 49)).astype(np.int64))
FIXED_CALIBRATION = 100_000
CALIBRATION_COUNTS_PER_RATE = np.array([0, 1, 0, 1])
SCIENCE_TAILS = 3
CALIBRATION_RATES = 4
CALIBRATED_ALPHA = ALPHA / 2
JOINT_TAIL = BETA / (2 * (SCIENCE_TAILS + CALIBRATION_RATES))
CHUNK_SIZE = 64
SEED = 2026111701


def matched_control(target, cutoff):
    """Find a resonantly driven empty cavity with the target's finite mean."""
    mean = target["finite_mean"]

    def state(drive):
        return solve_steady_state(Case("empty-matched", "control", "", drive, 0.0, (), (), ()), cutoff)

    drive = brentq(lambda d: state(d).mean - mean, 0.25 * sqrt(mean), sqrt(mean), xtol=1e-13)
    empty = state(drive)
    return {
        "case_id": f"empty-for-{target['case_id']}", "reference_g2": 1.0, "reference_mean": 4 * drive**2,
        "finite_mean": empty.mean, "finite_g2": empty.g2, "probabilities": empty.probabilities.tolist(),
        "drive": drive, "cavity_detuning": 0.0,
    }


def load_models(inputs, points):
    settings = json.loads(RULE.read_text(encoding="utf-8"))["settings"]
    if (settings["alpha"], settings["beta"], settings["shot_tolerance"], settings["shot_grid"]) != (
        ALPHA, BETA, SHOT_TOLERANCE, SHOT_GRID.tolist()
    ):
        raise ValueError("Confidence settings differ from the frozen pilot settings")
    cutoff = inputs["cutoff"]
    if cutoff != 3:
        raise ValueError("The readout model requires four photon levels, n=0 through n=3")

    pairs = []
    for point in points:
        target = dict(point)
        control = matched_control(target, cutoff)
        if abs(target["finite_mean"] - control["finite_mean"]) > 1e-12:
            raise ArithmeticError(f"Control intensity differs for {target['case_id']}")
        if target["case_id"] == inputs["points"][0]["case_id"]:
            reference = inputs["primary_control"]["probabilities"]
            if not np.allclose(control["probabilities"], reference, rtol=0, atol=1e-12):
                raise ArithmeticError("Primary control differs from the prior readout study")
        for model in (target, control):
            p = np.asarray(model["probabilities"])
            if (
                p.shape != (cutoff + 1,) or np.any(p < 0) or abs(p.sum() - 1) > 1e-12
                or abs(p @ LEVELS - model["finite_mean"]) > 1e-12
                or abs(g2(p) - model["finite_g2"]) > 1e-12
            ):
                raise ValueError(f"Invalid photon populations for {model['case_id']}")
            scale = max(1.0, model["finite_g2"])
            model.update(cutoff_budget=settings["cutoff_tolerance"] * scale, shot_tolerance=SHOT_TOLERANCE * scale)
            if abs(model["reference_g2"] - model["finite_g2"]) > model["cutoff_budget"]:
                raise ValueError(f"Cutoff error exceeds the allowance for {model['case_id']}")
        pairs.append((target, control))
    return pairs


def calibration_pairs(rates):
    """Combine prospective rate intervals from the 00 and 11 shot grids."""
    low, high = prospective_box(CALIBRATION_GRID, rates, CALIBRATED_ALPHA, JOINT_TAIL)
    pair_indices = np.indices((len(CALIBRATION_GRID), len(CALIBRATION_GRID))).reshape(2, -1).T
    per_rate_index = pair_indices[:, CALIBRATION_COUNTS_PER_RATE]
    rate_columns = np.arange(CALIBRATION_RATES)
    boxes = low[per_rate_index, rate_columns], high[per_rate_index, rate_columns]
    return CALIBRATION_GRID[pair_indices], boxes


def scan_science_budgets(target, observed, calibration_box):
    tails = photon_tails(observed)
    low, high = prospective_box(SHOT_GRID, tails, CALIBRATED_ALPHA, JOINT_TAIL)
    calibration_low, calibration_high = calibration_box
    shape = (len(calibration_low), len(SHOT_GRID))
    lower, upper = np.empty(shape), np.empty(shape)
    for start in range(0, shape[0], CHUNK_SIZE):
        rows = slice(start, start + CHUNK_SIZE)
        box = calibration_low[rows, None, :], calibration_high[rows, None, :]
        lower[rows], upper[rows] = g2_interval((low, high), box)
    adjusted_upper = upper + target["cutoff_budget"]
    width = upper - lower
    criteria = {
        "decision": adjusted_upper < 1,
        "precision": width <= 2 * target["shot_tolerance"],
    }
    stats = {}
    for goal, good in criteria.items():
        feasible = good.any(axis=1)
        index = np.where(feasible, good.argmax(axis=1), len(SHOT_GRID) - 1)
        rows = np.arange(shape[0])
        stats[goal] = {
            "feasible": feasible, "science": SHOT_GRID[index],
            "adjusted_upper": adjusted_upper[rows, index], "width": width[rows, index],
        }
    return stats


def select_plans(target, observed, rates, counts, stats):
    fixed = np.flatnonzero(np.all(counts == FIXED_CALIBRATION, axis=1)).item()
    equal = counts[:, 0] == counts[:, 1]
    known = shot_plans(target, observed, (rates, rates), ALPHA, BETA / (2 * SCIENCE_TAILS))
    rows = []
    for goal, s in stats.items():
        exact = known[goal]
        exact_upper = exact["planning_g2_upper"]
        rows.append({
            "policy": "exact_rates", "goal": goal, "status": "planned" if exact["plan_pass"] else "at_cap",
            "shots_00": 0, "shots_11": 0, "science_shots": exact["science_shots"],
            "total_shots": exact["science_shots"], "planning_width": exact["planning_width"],
            "planning_adjusted_upper": exact_upper + target["cutoff_budget"] if exact_upper is not None else None,
        })
        for name, mask in (("fixed_100000", None), ("optimized_equal", equal), ("optimized_separate", np.ones_like(equal))):
            if mask is None:
                best = fixed
            else:
                eligible = np.flatnonzero(mask & s["feasible"])
                if not eligible.size:
                    rows.append({
                        "policy": name, "goal": goal, "status": "grid_exhausted",
                        "shots_00": None, "shots_11": None, "science_shots": None,
                        "total_shots": None, "planning_width": None, "planning_adjusted_upper": None,
                    })
                    continue
                # Lowest total first. Ties use fewer science shots, then fewer 00 shots.
                total = counts[eligible].sum(axis=1) + s["science"][eligible]
                order = np.lexsort((counts[eligible, 0], s["science"][eligible], total))
                best = eligible[order[0]]
            shots_00, shots_11 = map(int, counts[best])
            science = int(s["science"][best])
            rows.append({
                "policy": name, "goal": goal, "status": "planned" if s["feasible"][best] else "at_cap",
                "shots_00": shots_00, "shots_11": shots_11, "science_shots": science,
                "total_shots": shots_00 + shots_11 + science,
                "planning_width": finite(s["width"][best]),
                "planning_adjusted_upper": finite(s["adjusted_upper"][best]),
            })
    return rows


def validate_plan(plan, models, observed, rates, batches, seed, indices):
    k0, k1, science = (plan[key] for key in ("shots_00", "shots_11", "science_shots"))
    if science is None:
        return []
    if k0:
        calibration_rng = np.random.default_rng(np.random.SeedSequence([seed, *indices, k0, k1, 0]))
        sizes = np.array([k0, k1])[CALIBRATION_COUNTS_PER_RATE]
        calibration = calibration_rng.binomial(sizes, rates, size=(batches, len(rates)))
        box = binomial_box(sizes, calibration, calibration, CALIBRATED_ALPHA)
        data_alpha = CALIBRATED_ALPHA
    else:
        box, data_alpha = (rates, rates), ALPHA
    rows = []
    for index, (model, q) in enumerate(zip(models, observed, strict=True), 1):
        rng = np.random.default_rng(np.random.SeedSequence([seed, *indices, science, index]))
        rows.append({
            **plan, "validated_case_id": model["case_id"], "reference_g2": model["reference_g2"],
            **batch_outcome(model, q, science, box, data_alpha, batches, rng),
        })
    return rows


def condition_results(models, scenario, counts, calibration_box, batches, seed, indices):
    rates = np.asarray(scenario["rates"], dtype=float)
    target = models[0]
    observed = [observed_distribution(np.asarray(model["probabilities"]), rates) for model in models]
    stats = scan_science_budgets(target, observed[0], calibration_box)
    context = {"case_id": target["case_id"], "scenario": scenario["name"]}
    plans = [{**context, **p} for p in select_plans(target, observed[0], rates, counts, stats)]
    validation = [row for p in plans for row in validate_plan(p, models, observed, rates, batches, seed, indices)]
    grid = [{
        **context, "shots_00": int(k0), "shots_11": int(k1),
        "decision_science_shots": int(stats["decision"]["science"][i]) if stats["decision"]["feasible"][i] else None,
        "precision_science_shots": int(stats["precision"]["science"][i]) if stats["precision"]["feasible"][i] else None,
    } for i, (k0, k1) in enumerate(counts)]
    return plans, validation, grid


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--smoke", action="store_true", help="Check the original operating point at 2 percent error")
    parser.add_argument("--out", type=Path, help="Output directory")
    args = parser.parse_args()
    inputs = json.loads(INPUTS.read_text(encoding="utf-8"))
    points = inputs["points"][:1] if args.smoke else inputs["points"]
    scenarios = [s for s in inputs["noise_scenarios"] if s["name"] == "symmetric_0.02"] if args.smoke else inputs["noise_scenarios"]
    models = load_models(inputs, points)
    batches = 32 if args.smoke else 1024
    seed = SEED + int(args.smoke)
    folder = args.out or Path("photon_blockade_allocation_smoke" if args.smoke else "photon_blockade_allocation_results")
    folder.mkdir(parents=True, exist_ok=True)
    combined = {"plans": [], "validation": [], "allocation_grid": []}
    for s_idx, scenario in enumerate(scenarios, 1):
        counts, intervals = calibration_pairs(np.asarray(scenario["rates"], dtype=float))
        for p_idx, pair in enumerate(models, 1):
            plans, validation, grid = condition_results(pair, scenario, counts, intervals, batches, seed, (s_idx, p_idx))
            combined["plans"].extend(plans)
            combined["validation"].extend(validation)
            combined["allocation_grid"].extend(grid)
            print(f"{pair[0]['case_id']} at {scenario['name']}", flush=True)
    for name, rows in combined.items():
        write_csv(folder / f"{name}.csv", rows)

    names = (
        "run_allocation.py", "run_readout.py", "cavity.py", "sampling.py",
        "readout_intervals.py", "followup_operating_point.json", INPUTS.name, RULE.name,
    )
    metadata = {
        "mode": "smoke" if args.smoke else "full", "cutoff": inputs["cutoff"],
        "cases_and_controls": models, "noise_scenarios": scenarios, "confidence": 1 - ALPHA,
        "planning_probability": 1 - BETA, "seed": seed, "validation_batches": batches,
        "source_archives": {k: v for k, v in inputs.items() if k.endswith("_archive_sha256")},
        "calibration_grid_per_state": CALIBRATION_GRID.tolist(), "science_grid": SHOT_GRID.tolist(),
        "fixed_calibration_shots_per_state": FIXED_CALIBRATION,
        "runtime": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__},
        "input_sha256": {name: sha256((HERE / name).read_bytes()).hexdigest() for name in names},
    }
    (folder / "manifest.json").write_text(json.dumps(metadata, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    filename = "Photon_Blockade_Allocation_Smoke.zip" if args.smoke else "Photon_Blockade_Allocation_Results.zip"
    archive = folder / filename
    staged = archive.with_suffix(".part")
    with ZipFile(staged, "w", compression=ZIP_DEFLATED) as output:
        for name in ("manifest.json", *(f"{name}.csv" for name in combined)):
            output.write(folder / name, name)
    staged.replace(archive)
    print(f"Results written to {archive.resolve()}", flush=True)


if __name__ == "__main__":
    main()
