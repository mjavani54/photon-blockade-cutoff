# Photon blockade follow-up

The run tests whether looking two photon levels ahead improves the frozen pilot cutoff rule, and whether deciding $g^{(2)}(0)<1$ takes fewer shots than estimating its value to the pilot precision. It uses the pilot's driven, lossy cavity Lindblad solver and ideal independent photon-number sampling.

## Run on macOS or Linux

Open a terminal in the extracted project directory. Use Python 3.10 or newer.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_followup.py --workers 4
```

Upload `photon_blockade_followup_results/Photon_Blockade_Followup_Results.zip` when the program finishes. No GPU or quantum hardware account is needed. Use `--workers 2` to reduce CPU and memory usage. If interrupted, rerun the same command to resume from per-case checkpoints. Use `--out another_directory` to start a fresh run.

For an optional quick check, run `python run_followup.py --smoke --workers 2`. This creates a separate output directory and checks 16 cases. Use the full run for the analysis.

## Test design

- The 192 new two-emitter cases come from 32 scrambled Sobol points in each of three families. Each point gives one identical-emitter cavity and one mismatched-emitter cavity with the same collective coupling, cavity detuning, and drive. The families cover a broad range, the one-photon polariton region, and strong drive near the pilot misses.
- Two known misses, `S037` and `M037`, are checked separately. Eight empty-cavity controls have an analytic reference of $g^{(2)}(0)=1$.
- The original rule measures the change from cutoff $m$ to $m+1$ and the contribution of level $m+1$ to $g^{(2)}(0)$. The two-level rule also checks the change to $m+2$ and the combined contribution of the two added photon levels. Both use the same frozen pilot multiplier and cutoff budget $0.025\max(1,g_m)$. The $m+1$ and $m+2$ solves are classical lookaheads. Only levels 0 through $m$ count toward the selected photon register.
- Each numerical reference requires two consecutive cutoff increments of two to agree within the frozen reference tolerance for $g^{(2)}(0)$ and mean photon number. The run records any numerical issue, including failure to converge by reference cutoff 28.

## Shot criteria

Both criteria use the same two-level rule's selected distribution, the pilot's shot grid from $10^3$ to $10^8$, and the pilot's simultaneous Clopper–Pearson intervals for the photon-number tails. The prospective interval bounds come from a joint count band with at least 95% probability under that distribution.

| Plan | Select the first shot count with |
| --- | --- |
| Precision | Prospective interval width at most $0.15\max(1,g_m)$ |
| Antibunching decision | Prospective upper limit plus $0.025\max(1,g_m)$ below 1 |

For each plan and case, draw 256 independent multinomial batches. For a case with no passing shot count, evaluate batches at the cap and record that the prospective criterion was unmet. The cutoff allowance applies to the reference correlation when the empirical cutoff error is within budget. The goal is to find out whether a detection-only experiment can use fewer shots and where the cutoff check adds a photon qubit.

## Result archive

| File | Content |
| --- | --- |
| `manifest.json` | Seeds, parameter ranges, versions, and input hashes |
| `summary.json` | Counts for cutoff accuracy, photon qubits, and shot plans |
| `cases.csv` | Operating points, converged references, selected cutoffs, and shot outcomes |
| `cutoff_trace.csv` | All solved photon populations, diagnostics, and stationary residuals |
| `pilot_rule.json` | Calibration frozen in the pilot |
| `pilot_known_misses.json` | Original parameters of the two known misses |

In `cases.csv`, the `pilot_*` columns refer to the original rule and the `guard_*` columns refer to the two-level lookahead. The planned or capped count is in `precision_shots_used` or `decision_shots_used`. The corresponding `*_shot_plan_pass` field identifies whether the count met the prospective criterion. Empty bounds indicate an infinite upper bound or an unavailable numerical result. Qubit counts refer to the photon register.
