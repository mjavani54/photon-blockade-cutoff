"""Test frozen photon cutoffs and compare precision and antibunching shot budgets."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
from dataclasses import asdict
import hashlib
from itertools import product
import json
from math import ceil, exp, isfinite, log2, sqrt
import os
from pathlib import Path
import platform
from statistics import median
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, ZipFile

for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(variable, "1")

import numpy as np
import scipy
from scipy.stats import binom, qmc

from cavity import Case, solve_steady_state
from sampling import ALPHA, BATCHES, BETA, SHOT_GRID, SHOT_TOLERANCE, evaluate_shots, g2_bounds


HERE = Path(__file__).resolve().parent
RULE_FILE = HERE / "pilot_rule.json"
KNOWN_FILE = HERE / "pilot_known_misses.json"
PILOT_RULE = json.loads(RULE_FILE.read_text(encoding="utf-8"))
CUTOFF_TOLERANCE = PILOT_RULE["settings"]["cutoff_tolerance"]
REFERENCE_TOLERANCE = PILOT_RULE["settings"]["reference_tolerance"]
MAX_CUTOFF = PILOT_RULE["settings"]["maximum_candidate_cutoff"]
MULTIPLIER = PILOT_RULE["proposal_multiplier"]
MAX_REFERENCE = 28
SEED = 870142
DRAW_POWER = 5
FULL_ZIP = "Photon_Blockade_Followup_Results.zip"
SMOKE_ZIP = "Photon_Blockade_Smoke_Results.zip"
FAMILY_RANGES = {
    "broad": {
        "collective_coupling": (0.75, 3.85),
        "base_decay": (0.09, 0.49),
        "drive": (0.025, 0.87),
        "relative_drive_detuning": (-0.35, 1.18),
        "coupling_weight": (0.55, 0.86),
        "offset1": (-0.36, 0.26),
        "offset2": (-0.24, 0.35),
        "decay_imbalance": (0.05, 0.28),
    },
    "polariton": {
        "collective_coupling": (1.8, 4.1),
        "base_decay": (0.08, 0.34),
        "drive": (0.027, 0.75),
        "relative_drive_detuning": (0.87, 1.09),
        "coupling_weight": (0.53, 0.75),
        "offset1": (-0.11, 0.04),
        "offset2": (-0.04, 0.11),
        "decay_imbalance": (0.02, 0.22),
    },
    "strong_drive": {
        "collective_coupling": (0.70, 1.15),
        "base_decay": (0.24, 0.50),
        "drive": (0.65, 0.95),
        "relative_drive_detuning": (-0.10, 0.10),
        "coupling_weight": (0.68, 0.82),
        "offset1": (-0.41, -0.18),
        "offset2": (0.15, 0.36),
        "decay_imbalance": (0.08, 0.27),
    },
}


def make_cases(smoke):
    cases = []
    for family_index, (family, ranges) in enumerate(FAMILY_RANGES.items(), 1):
        points = qmc.Sobol(d=len(ranges), scramble=True, seed=SEED + family_index)
        points = points.random_base2(DRAW_POWER)
        for index, point in enumerate(points[:2] if smoke else points, 1):
            draw = {
                name: low + coord * (high - low)
                for (name, (low, high)), coord in zip(ranges.items(), point, strict=True)
            }
            g = draw["collective_coupling"]
            gamma = draw["base_decay"]
            delta = g * draw["relative_drive_detuning"]
            drive = draw["drive"]
            if family != "strong_drive":
                low, high = ranges["drive"]
                drive = low * exp(point[2] * np.log(high / low))
            weight = draw["coupling_weight"]
            imbalance = draw["decay_imbalance"]
            pair = f"{family}-{index:03d}"
            cases.extend((
                Case(f"{pair}-equal", family, pair, drive, delta,
                     (g / sqrt(2),) * 2, (delta,) * 2, (gamma,) * 2),
                Case(f"{pair}-unequal", family, pair, drive, delta,
                     (sqrt(weight) * g, sqrt(1 - weight) * g),
                     (delta + draw["offset1"] * g, delta + draw["offset2"] * g),
                     (gamma * (1 - imbalance), gamma * (1 + imbalance))),
            ))

    known = json.loads(KNOWN_FILE.read_text(encoding="utf-8"))
    cases.extend(Case(group="known_miss", **record) for record in known["cases"])
    controls = list(product((0.025, 0.075, 0.30, 0.85), (0.0, 0.45)))
    for index, (drive, detuning) in enumerate(controls[::4] if smoke else controls, 1):
        cases.append(Case(f"empty-{index:02d}", "empty", "", drive, detuning, (), (), ()))
    return cases


def solve_reference(state_at, case):
    steps = []
    for cutoff in range(12, MAX_REFERENCE + 1, 2):
        current, previous = state_at(cutoff), state_at(cutoff - 2)
        g2_change = abs(current.g2 - previous.g2) / max(1.0, current.g2)
        mean_change = abs(current.mean - previous.mean) / current.mean
        steps.append(max(g2_change, mean_change))
        if len(steps) >= 2 and max(steps[-2:]) <= REFERENCE_TOLERANCE:
            if case.couplings:
                return cutoff, current.g2, current.mean, max(steps[-2:])
            mean = case.drive**2 / (0.25 + case.cavity_detuning**2)
            if max(abs(current.g2 - 1), abs(current.mean / mean - 1)) > REFERENCE_TOLERANCE:
                raise ArithmeticError("Analytic empty-cavity reference check failed")
            return cutoff, 1.0, mean, max(steps[-2:])
    raise ArithmeticError(f"Reference did not converge by cutoff {MAX_REFERENCE}")


def choose_cutoffs(state_at, trace):
    choices = {"pilot": None, "guard": None}
    for m in range(2, MAX_CUTOFF + 1):
        current, adjacent, extended = (state_at(m + shift) for shift in range(3))
        scale = max(1.0, current.g2)
        adjacent_change = abs(adjacent.g2 - current.g2)
        adjacent_weight = m * (m + 1) * adjacent.probabilities[-1] / adjacent.mean**2
        extended_change = abs(extended.g2 - current.g2)
        extended_weight = (
            m * (m + 1) * extended.probabilities[-2]
            + (m + 1) * (m + 2) * extended.probabilities[-1]
        ) / extended.mean**2
        metrics = {
            "pilot": max(adjacent_change, adjacent_weight) / scale,
            "guard": max(adjacent_change, adjacent_weight, extended_change, extended_weight) / scale,
        }
        trace[m] = {
            "next_g2_change": adjacent_change,
            "next_pair_weight": float(adjacent_weight),
            "two_level_g2_change": extended_change,
            "two_level_pair_weight": float(extended_weight),
        }
        for name, score in metrics.items():
            proxy = float(MULTIPLIER * (score + REFERENCE_TOLERANCE))
            trace[m][f"{name}_scaled_error_proxy"] = proxy
            if choices[name] is None and proxy <= CUTOFF_TOLERANCE:
                choices[name] = m
        if choices["guard"] is not None:
            break
    return choices


def compare_shot_plans(state, reference_g2, case_id):
    scale = max(1.0, state.g2)
    cutoff_budget = CUTOFF_TOLERANCE * scale
    shot_budget = SHOT_TOLERANCE * scale
    tails = np.clip(np.cumsum(state.probabilities[:0:-1])[::-1], 0.0, 1.0)
    shot_grid = SHOT_GRID[:, None]
    tail_beta = BETA / (2 * len(tails))
    counts_low = binom.ppf(tail_beta, shot_grid, tails)
    counts_high = binom.ppf(1 - tail_beta, shot_grid, tails)
    lower, upper = g2_bounds(counts_low, counts_high, shot_grid)
    width = upper - lower
    decision_upper = upper + cutoff_budget
    choices = {"precision": width <= 2 * shot_budget, "decision": decision_upper < 1}
    row = {"shot_batches_per_plan": BATCHES, "pair_probability": float(state.probabilities[2:].sum())}
    for index, (name, criterion) in enumerate(choices.items()):
        passed = np.flatnonzero(criterion)
        shot_index = int(passed[0]) if passed.size else len(SHOT_GRID) - 1
        shots = int(SHOT_GRID[shot_index])
        rng = np.random.default_rng(np.random.SeedSequence([SEED, index, *case_id.encode("ascii")]))
        batch = evaluate_shots(state.probabilities, shots, rng, state.g2, reference_g2, cutoff_budget, shot_budget)
        row.update({
            f"{name}_shot_plan_pass": bool(passed.size),
            f"{name}_shots_used": shots,
            f"{name}_upper_bound": float(decision_upper[shot_index]) if isfinite(decision_upper[shot_index]) else None,
            f"{name}_width_bound": float(width[shot_index]) if isfinite(width[shot_index]) else None,
            **{f"{name}_{key}": value for key, value in batch.items()},
        })
    return row


def analyze_case(case):
    states = {}
    trace = {}
    row = {
        **asdict(case),
        "configuration": "empty" if not case.couplings else (
            "identical" if case.couplings[0] == case.couplings[1] else "mismatched"
        ),
        "collective_coupling": sqrt(sum(g**2 for g in case.couplings)),
    }

    def state_at(cutoff):
        if cutoff not in states:
            states[cutoff] = solve_steady_state(case, cutoff)
        return states[cutoff]

    try:
        choices = choose_cutoffs(state_at, trace)
        cutoff, reference_g2, reference_mean, reference_change = solve_reference(state_at, case)
    except (ArithmeticError, np.linalg.LinAlgError) as error:
        row.update(status="numerical_issue", error=str(error))
    else:
        row.update(
            status="ok", reference_cutoff=cutoff, reference_g2=reference_g2,
            reference_mean=reference_mean, reference_convergence=reference_change,
        )
        for method, m in choices.items():
            row[f"{method}_cutoff"] = m
            if m is not None:
                finite = states[m]
                error = abs(finite.g2 - reference_g2) / max(1, finite.g2)
                row.update({
                    f"{method}_qubits": ceil(log2(m + 1)),
                    f"{method}_scaled_error": error,
                    f"{method}_cutoff_pass": error <= CUTOFF_TOLERANCE,
                })
        if choices["guard"] is not None:
            chosen = states[choices["guard"]]
            row.update(selected_g2=chosen.g2, selected_mean=chosen.mean)
            row.update(compare_shot_plans(chosen, reference_g2, case.case_id))

    cutoff_rows = [{
        "case_id": case.case_id, "cutoff": m, "g2": state.g2, "mean": state.mean,
        "stationary_residual": state.residual,
        "populations": state.probabilities.tolist(), **trace.get(m, {}),
    } for m, state in sorted(states.items())]
    return {"case": row, "cutoffs": cutoff_rows}


def summarize(rows):
    valid = [row for row in rows if row["status"] == "ok"]
    paired = [row for row in valid if row["guard_cutoff"] is not None]
    anti = [row for row in paired if row["reference_g2"] < 1]
    strong = [row for row in anti if row["reference_g2"] < 0.9]
    null = [row for row in paired if row["reference_g2"] >= 1]
    speedups = [
        row["precision_shots_used"] / row["decision_shots_used"] for row in anti
        if row["precision_shot_plan_pass"] and row["decision_shot_plan_pass"]
    ]
    return {
        "cases": len(rows),
        "reference_converged": len(valid),
        "cutoffs": {
            name: {
                "selected": len(selected),
                "within_error_budget": sum(row[f"{name}_cutoff_pass"] for row in selected),
                "worst_scaled_error": max((row[f"{name}_scaled_error"] for row in selected), default=None),
                "photon_qubit_histogram": {
                    str(qubits): sum(row[f"{name}_qubits"] == qubits for row in selected)
                    for qubits in (2, 3, 4)
                },
            }
            for name in ("pilot", "guard")
            for selected in [[row for row in valid if row[f"{name}_cutoff"] is not None]]
        },
        "additional_photon_qubit_cases": sum(row["guard_qubits"] > row["pilot_qubits"] for row in paired),
        "guard_recovers_cutoff_miss": sum(not row["pilot_cutoff_pass"] and row["guard_cutoff_pass"] for row in paired),
        "sampling": {
            "cases_with_guard_selected": len(paired),
            "reference_antibunched": len(anti),
            "reference_g2_lt_0p9": len(strong),
            "reference_antibunched_decision_plan_pass": sum(row["decision_shot_plan_pass"] for row in anti),
            "reference_antibunched_decision_plan_by_one_million": sum(
                row["decision_shot_plan_pass"] and row["decision_shots_used"] <= 1_000_000 for row in anti
            ),
            "reference_antibunched_precision_plan_pass": sum(row["precision_shot_plan_pass"] for row in anti),
            "precision_plan_pass_all_guard_cases": sum(row["precision_shot_plan_pass"] for row in paired),
            "strong_antibunching_called_in_95pct_of_decision_batches": sum(
                row["decision_batch_antibunching"] >= ceil(0.95 * BATCHES) for row in strong
            ),
            "false_antibunching_decision_batches": sum(row["decision_batch_antibunching"] for row in null),
            "reference_null_decision_batches": len(null) * BATCHES,
            "antibunched_cases_with_both_plans": len(speedups),
            "median_precision_to_decision_shot_ratio": median(speedups) if speedups else None,
        },
    }


def atomic_write(path, content):
    with NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, delete=False) as file:
        file.write(content)
        temporary = Path(file.name)
    temporary.replace(path)


def json_text(value):
    return json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"


def write_csv(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                key: json.dumps(value, separators=(",", ":")) if isinstance(value, (list, tuple)) else value
                for key, value in row.items()
            })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument("--smoke", action="store_true", help="Run a small end-to-end check")
    parser.add_argument("--out", type=Path, help="Directory for output and restart checkpoints")
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be at least 1")
    pilot_settings = PILOT_RULE["settings"]
    if (
        pilot_settings["alpha"] != ALPHA or pilot_settings["beta"] != BETA
        or pilot_settings["shot_tolerance"] != SHOT_TOLERANCE
        or pilot_settings["shot_grid"] != SHOT_GRID.tolist()
    ):
        raise ValueError("The bundled shot settings differ from the frozen pilot rule")

    cases = make_cases(args.smoke)
    folder = args.out or Path("photon_blockade_smoke" if args.smoke else "photon_blockade_followup_results")
    cache = folder / "case_cache"
    cache.mkdir(parents=True, exist_ok=True)
    manifest = {
        "mode": "smoke" if args.smoke else "full",
        "cases": len(cases),
        "case_parameters_sha256": hashlib.sha256(json_text([asdict(c) for c in cases]).encode()).hexdigest(),
        "input_sha256": {
            name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
            for name in ("run_followup.py", "cavity.py", "sampling.py", RULE_FILE.name, KNOWN_FILE.name)
        },
        "runtime": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__},
        "seed": SEED,
        "new_cohort_family_ranges": FAMILY_RANGES,
        "draws_per_family_before_pairing": 2**DRAW_POWER,
        "maximum_reference_cutoff": MAX_REFERENCE,
        "confidence": 1 - ALPHA,
        "planning_probability": 1 - BETA,
        "batches_per_shot_plan": BATCHES,
    }
    manifest_path = folder / "manifest.json"
    specification = json_text(manifest)
    if manifest_path.exists() and manifest_path.read_text(encoding="utf-8") != specification:
        raise ValueError("Output contains a different run. Choose a new directory with --out.")
    atomic_write(manifest_path, specification)

    checkpoints = {case.case_id: cache / f"{case.case_id}.json" for case in cases}
    pending = [case for case in cases if not checkpoints[case.case_id].exists()]
    done = len(cases) - len(pending)
    print(f"Loaded {done} completed cases. Running {len(pending)} cases.", flush=True)
    if pending:
        with ProcessPoolExecutor(max_workers=args.workers) as workers:
            for future in as_completed([workers.submit(analyze_case, case) for case in pending]):
                completed = future.result()
                case_id = completed["case"]["case_id"]
                atomic_write(checkpoints[case_id], json_text(completed))
                done += 1
                if done % 10 == 0 or done == len(cases):
                    print(f"Completed {done}/{len(cases)} cases", flush=True)

    completed = [json.loads(checkpoints[case.case_id].read_text(encoding="utf-8")) for case in cases]
    rows = [item["case"] for item in completed]
    cutoffs = [state for item in completed for state in item["cutoffs"]]
    groups = {group: summarize([r for r in rows if r["group"] == group]) for group in
              (*FAMILY_RANGES, "known_miss", "empty")}
    groups["all_new_two_emitter_cases"] = summarize([r for r in rows if r["group"] in FAMILY_RANGES])
    write_csv(folder / "cases.csv", rows)
    write_csv(folder / "cutoff_trace.csv", cutoffs)
    atomic_write(folder / "summary.json", json_text(groups))

    archive = folder / (SMOKE_ZIP if args.smoke else FULL_ZIP)
    staged = archive.with_suffix(".part")
    with ZipFile(staged, "w", compression=ZIP_DEFLATED) as zip_file:
        for name in ("manifest.json", "cases.csv", "cutoff_trace.csv", "summary.json"):
            zip_file.write(folder / name, arcname=name)
        zip_file.write(RULE_FILE, arcname=RULE_FILE.name)
        zip_file.write(KNOWN_FILE, arcname=KNOWN_FILE.name)
    staged.replace(archive)
    numerical_issues = sum(row["status"] != "ok" for row in rows)
    print(f"Finished with {numerical_issues} numerical issues. Results: {archive.resolve()}", flush=True)


if __name__ == "__main__":
    main()
