"""Offline audit of the frozen v2 result archive; never connects to IBM."""

import argparse
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def audit(archive, collector_code):
    collector_code = Path(collector_code).resolve()
    sys.path.insert(0, str(collector_code))
    from experiment import validate_schedule
    from run_allocation_validation import source_hashes
    from analyze_allocation_validation import analyze

    archive = Path(archive).resolve()
    with ZipFile(archive) as z:
        names = z.namelist()
        assert len(names) == len(set(names)) and z.testzip() is None
        hashes = json.loads(z.read("result_sha256.json"))
        assert set(hashes) == set(names) - {"result_sha256.json"}
        for name, want in hashes.items():
            assert sha256(z.read(name)).hexdigest() == want, name
        config = json.loads(z.read("collection_manifest.json"))
        schedule = json.loads(z.read("schedule.json"))
        summary = json.loads(z.read("analysis_manifest.json"))
        journal = json.loads(z.read("jobs.json"))["stages"]
        budgets = validate_schedule(schedule)
        assert not schedule["smoke"] and schedule["total_jobs"] == 32
        assert schedule["total_shots"] == 608256 and schedule["total_analysis_shots"] == 595968
        assert config["source_sha256"] == source_hashes()
        assert config["provenance"] == summary["provenance"] == "ibm_hardware"
        assert config["instance_plan"] == "open"
        assert config["backend"] == "ibm_marrakesh" and config["physical_qubits"] == [14, 55]
        assert config["schedule_sha256"] == summary["schedule_sha256"] == schedule["sha256"]
        arms = list(budgets)
        cal = {a: [[0] * 4 for _ in range(4)] for a in arms}
        heldout = {a: [[0] * 4 for _ in range(4)] for a in arms}
        sci = {a: {p: [0] * 4 for p in ("signal", "control")} for a in arms}
        ids, acquired, pubs_checked, chunks, usage = [], 0, 0, [], []
        for stage in schedule["stages"]:
            record = json.loads(z.read(f"stages/stage_{stage['stage_index']:03d}.json"))
            assert record["job_id"] == journal[stage["stage_id"]]["job_id"]
            ids.append(record["job_id"])
            spans = record["execution_windows"]
            indices = [i for w in spans for i in w["pub_indices"]]
            assert sorted(set(indices)) == list(range(len(stage["pubs"])))
            chunks.append(len(spans))
            usage.append(record["job_metrics"]["usage"])
            for pub, sample in zip(stage["pubs"], record["samples"], strict=True):
                assert sample["pub_index"] == pub["pub_index"]
                assert sample["pub_metadata"]["circuit_metadata"]["prepared_state"] == pub["prepared_state"]
                strings = sample["ordered_bitstrings"]
                assert len(strings) == pub["shots"] == 64
                assert all(len(s) == 2 and set(s) <= set("01") for s in strings)
                raw = Counter(int(s, 2) for s in strings)
                assert [raw[i] for i in range(4)] == sample["counts"]
                retained = Counter(int(s, 2) for s in strings[:pub["analysis_shots"]])
                arm, prepared = pub["arm"], pub["prepared_state"]
                for outcome, count in retained.items():
                    if pub["role"] == "calibration":
                        cal[arm][outcome][prepared] += count
                    elif pub["role"] == "science":
                        sci[arm][pub["population"]][outcome] += count
                        heldout[arm][outcome][prepared] += count
                acquired += len(strings)
                pubs_checked += 1
        assert len(set(ids)) == len(ids) == 32 and acquired == 608256
        assert cal == summary["calibration_counts"] and sci == summary["science_counts"]
        assert all(u["unit"] == "resource_units" for u in usage)
        ru = sum(u["value"] for u in usage)
        assert abs(ru - summary["physical_cost_totals"]["available_resource_units"]) < 1e-12
        with TemporaryDirectory(prefix="batched_hardware_offline_audit_") as tmp:
            folder = Path(tmp)
            for name in names:
                member = Path(name)
                assert not member.is_absolute() and ".." not in member.parts
                target = folder / member
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(name))
            analyze(folder)
            outputs = ["analysis_manifest.json", "report.md", "readout_results.csv", "arm_outcomes.csv",
                       "stage_timing.csv", "arm_costs.csv", "physical_job_costs.csv", "calibration_to_science_gaps.csv",
                       "calibration_and_heldout.csv", "science_blocks.csv", "result_sha256.json"]
            for name in outputs:
                assert (folder / name).read_bytes() == z.read(name), name
        widths = {(r["arm"], r["population"]): r["interval_upper"] - r["interval_lower"] for r in summary["results"]}
        ratios = {p: widths["selected_allocation", p] / widths["reference_allocation", p] for p in ("signal", "control")}
        diagnostics = []
        for arm in arms:
            for state in range(4):
                nc = sum(row[state] for row in cal[arm])
                nh = sum(row[state] for row in heldout[arm])
                pc = cal[arm][state][state] / nc
                ph = heldout[arm][state][state] / nh if nh else None
                diagnostics.append({"arm": arm, "input": f"{state:02b}", "calibration_shots": nc,
                                    "heldout_science_shots": nh, "calibration_correct_fraction": pc,
                                    "heldout_science_correct_fraction": ph,
                                    "science_minus_calibration_correct_percentage_points": 100 * (ph - pc) if ph is not None else None})
        gaps = [g["gap_seconds"] for g in summary["calibration_to_science_gaps"]]
        return {"status": "passed", "input_archive_sha256": sha256(archive.read_bytes()).hexdigest(),
                "archive_crc_and_all_hashes": "passed", "source_hashes_and_frozen_schedule": "passed",
                "raw_bitstrings_metadata_and_independent_aggregation": "passed",
                "all_analysis_outputs_reproduced_byte_for_byte": True,
                "distinct_hardware_job_ids": len(ids), "pubs_checked": pubs_checked,
                "acquired_shots": acquired, "analyzed_shots": schedule["total_analysis_shots"],
                "family_alpha": summary["family_alpha"], "all_four_targets_covered": all(r["target_covered"] for r in summary["results"]),
                "both_arms_joint_success": all(r["joint_success_this_pilot"] for r in summary["arm_outcomes"]),
                "recorded_ru": ru, "ru_pending_jobs": sum(u["status"] == "pending" for u in usage),
                "ru_complete_jobs": sum(u["status"] == "complete" for u in usage),
                "estimated_remaining_ru_if_no_other_usage": config["usage_snapshot_before"]["usage_remaining_ru"] - ru,
                "one_execution_chunk_per_job": all(n == 1 for n in chunks),
                "selected_to_reference_interval_width_ratio": ratios,
                "gap_range_seconds": [min(gaps), max(gaps)],
                "descriptive_assignment_diagnostics": diagnostics,
                "diagnostic_limits": "Pooled correct fractions are descriptive. Rare-label counts, different block weights, and unknown dependence prevent using agreement as proof of calibration/science response matching.",
                "actual_new_hardware_jobs_during_audit": 0}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--collector-code", type=Path, default=Path(__file__).parent / "frozen_collector")
    parser.add_argument("--out", type=Path, default=Path(__file__).parent / "audit_results.json")
    args = parser.parse_args()
    result = audit(args.archive, args.collector_code)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
