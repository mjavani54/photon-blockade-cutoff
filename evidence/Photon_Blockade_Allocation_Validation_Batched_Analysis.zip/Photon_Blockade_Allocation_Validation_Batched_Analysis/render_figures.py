"""Plot audited nominal-label results; requires matplotlib, uses no hardware."""

import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent


def main():
    with (HERE / "results.csv").open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42})
    fig, axes = plt.subplots(1, 2, figsize=(8.0, 3.5), sharey=True)
    colors = {"reference_allocation": "#3778A7", "selected_allocation": "#9B4F96"}
    for ax, population in zip(axes, ("signal", "control"), strict=True):
        target = next(float(r["target_g2"]) for r in rows if r["population"] == population)
        ax.axvline(1, color="#727272", linestyle="--", linewidth=1.1, label="Decision boundary")
        if population == "signal":
            ax.axvline(target, color="#519A69", linestyle=":", linewidth=1.5, label="Generating target")
        for arm, y in (("reference_allocation", 1), ("selected_allocation", 0)):
            r = next(r for r in rows if r["population"] == population and r["arm"] == arm)
            point, low, high = (float(r[k]) for k in ("corrected_g2", "interval_lower", "interval_upper"))
            ax.errorbar(point, y, xerr=[[point-low], [high-point]], fmt="o", color=colors[arm], markersize=6, capsize=5, linewidth=2)
        ax.set_title(population.title(), fontweight="semibold")
        ax.set_xlabel(r"Nominal-label $g^{(2)}$")
        ax.set_xlim(0.15, 1.7)
        ax.set_ylim(-.55, 1.55)
        ax.set_yticks([1, 0], ["Reference", "Selected"])
        ax.grid(axis="x", alpha=.18)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(.5, .91), ncol=2, fontsize=8, frameon=False)
    fig.suptitle("One paired hardware allocation pilot", fontsize=12, fontweight="semibold", y=.98)
    fig.text(.5, .025, "Conditional simultaneous 95% intervals; 304,128 acquired shots per arm.\nX-only number-label SPAM benchmark; no cavity dynamics.", ha="center", fontsize=8, color="#444444")
    fig.tight_layout(rect=(0,.13,1,.83))
    fig.savefig(HERE / "allocation_intervals.png", dpi=300, bbox_inches="tight")
    fig.savefig(HERE / "allocation_intervals.pdf", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
