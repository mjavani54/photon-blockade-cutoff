# Batched hardware allocation pilot: verified analysis

## Result

The submitted v2 archive contains a complete paired pilot on `ibm_marrakesh`, physical low/high bits 14 and 55. Both the reference and selected allocations met the predeclared joint criterion: a signal interval below one and a valid control interval containing one. All four intervals cover their specified generating targets.

| Allocation | Population | Target g2 | Corrected estimate | Nominal simultaneous interval | Outcome |
| --- | --- | ---: | ---: | --- | --- |
| Reference | Signal | 0.543768 | 0.562260 | [0.290996, 0.872614] | Upper bound below 1 |
| Selected | Signal | 0.543768 | 0.563828 | [0.383397, 0.807867] | Upper bound below 1 |
| Reference | Control | 1.000000 | 1.064778 | [0.763896, 1.453427] | Contains 1 |
| Selected | Control | 1.000000 | 1.039122 | [0.693590, 1.569906] | Contains 1 |

These are the frozen full-matrix LP intervals under a family error budget of 0.05, subject to the protocol's independence and calibration/science response-matching assumptions. They are not independent per-row 95% intervals. Point estimates use the original simplex-constrained least-squares method.

## Allocation tradeoff

| Quantity | Reference | Selected |
| --- | ---: | ---: |
| Acquired shots per arm | 304,128 | 304,128 |
| Analyzed calibration shots | 99,328 | 149,504 |
| Analyzed signal shots | 99,328 | 111,616 |
| Analyzed control shots | 99,328 | 36,864 |
| Signal interval width | 0.581618 | 0.424469 |
| Control interval width | 0.689531 | 0.876316 |
| Signal absolute point error | 0.018492 | 0.020060 |
| Control absolute point error | 0.064778 | 0.039122 |
| Joint criterion in this pilot | Met | Met |

The selected signal interval is **27.02% narrower**, while its control interval is **27.09% wider**. Both arms have the same observed joint outcome. The reference has the slightly smaller signal point error; the selected allocation has the smaller control point error. These observations do not establish uniform superiority or a hardware power advantage for the selected allocation. Interval widths are realized values in this one pilot, not estimates of their repeated-run averages.

This is a useful validation that the fixed protocol can yield the intended inference on fresh device records at the matched acquired-shot budget. It cannot establish detection probabilities, false-positive rates, expected resource savings, or a method-superiority p-value from one pair. The sixteen blocks and four histogram rows are not independent repetitions of the complete experiment.

## Integrity and accounting

The offline audit passed archive CRC checks, every supplied SHA-256 check, all delivered collector-source hashes, frozen schedule regeneration, distinct job IDs and journal matching, all 9,504 returned PUB indices/prepared-state metadata, raw bitstring histograms, exact per-arm acquisition/retention counts, and a separate aggregation of calibration and science counts. Every analysis output reproduced byte for byte using the frozen code. The audit submits no jobs and does not query IBM; hardware provenance and usage are those recorded in the submitted archive, not an independent remote attestation.

The complete archive accounts for **608,256 acquired shots**, **595,968 analyzed shots**, and **12,288 predeclared extra outcomes excluded independently of their measured values**. It contains **32 distinct physical job IDs**. Each job's execution metadata has one chunk covering all its PUB indices. Shared physical jobs and their charges are counted once. Both arms participate in the same jobs, so per-arm job memberships overlap and are not additive. RU charges are not apportioned between arms.

## Usage and timing

The recorded resource usage is **3.896784 RUs**. All 32 metrics have status `pending`; none is finalized in this archive. The prior empirical estimate was 3.896602 RUs, and the generic estimate was 4.614827 RUs. Agreement with the empirical estimate in this pilot does not make it a guaranteed ceiling for later runs.

The initial live balance was 5.029852 RUs. Subtracting this run's recorded provisional usage gives **1.133068 RUs**, assuming no other usage or later charge changes. This arithmetic is not a current dashboard balance. Summed integer-valued legacy charge-time fields are 256 seconds and should not replace the reported RU total or be treated as an exact conversion to it.

All physical stages are sequential in the recorded execution windows. Calibration ends before science begins in each block; the sixteen gaps range from **30.067 to 49.514 seconds**. Neither ordered execution nor short gaps proves response matching.

## Response diagnostics and limits

`assignment_diagnostics.csv` compares pooled calibration and held-out science correct-label fractions descriptively. For labels 00, 01, and 10 the absolute differences are at most 0.299 percentage points in the reference and 0.186 percentage points in the selected arm. Label 11 has only **16** held-out science outcomes in the reference and **11** in the selected arm, so its observed 100% correct fraction is weak evidence about stability. Pooled counts have different block weights, and matching diagonal fractions would not establish equality of the full assignment matrices. These diagnostics cannot prove conditional independence, calibration/science response matching, or absence of drift.

The circuits prepare X-only classical mixtures of nominal number labels. They do not implement cavity-Hamiltonian evolution. The measured nominal-label antibunching criterion is not a direct demonstration of physical photon blockade, a transfer test of physical cavity dynamics, or quantum advantage.

## Next scientific step

Preserve this pilot as the completed frozen comparison, including its tie on the joint endpoint. Further full-budget runs are not supported by the estimated remaining allowance. Use the existing records for offline planning of a preregistered repeated comparison: choose budgets and replication counts by a stated power/precision calculation, preserve matched acquired-shot budgets and control coverage requirements, and collect fresh independent runs when sufficient allowance is available. New planning or tuning on these records must not be presented as validation on held-out data. A smaller budget may make precision differences easier to assess, but it must be justified before new outcomes are observed.

## Reproduce this audit

The included `frozen_collector` contains the exact source files needed for the audit and original inference. From this analysis folder:

```bash
python -m pip install -r frozen_collector/requirements_local.txt
python audit_hardware.py /path/to/Photon_Blockade_Allocation_Validation_Batched_Results.zip
```

No API key, Qiskit installation, IBM connection, or RUs are required for this offline audit. Use ordinary Python execution; do not use `python -O`, which disables audit assertions.

`audit_results.json` records the independent checks and exact derived quantities. `allocation_comparison.csv` and `results.csv` provide numeric data. The PNG/PDF figures show the same primary intervals. `render_figures.py` recreates them when Matplotlib is installed. `SHA256SUMS` covers the contents of this analysis package. The original uploaded archive is preserved separately and is not modified or duplicated into this package.
