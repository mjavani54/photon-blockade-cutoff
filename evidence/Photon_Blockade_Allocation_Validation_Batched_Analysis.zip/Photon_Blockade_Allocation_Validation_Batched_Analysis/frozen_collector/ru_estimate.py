"""Approximate RU planning, never a billing cap or guarantee."""

EMPIRICAL_SOURCE = {
    "shots_a": 4096, "ru_a": .048467, "shots_b": 8576, "ru_b": .070489,
    "note": "Earlier same-device recorded job metrics; most were pending at collection. New larger shared jobs can have different overhead/chunking.",
}
IBM_USAGE_DOCUMENTATION = "https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/estimate-job-run-time"


def estimate_usage(shots, jobs):
    x = EMPIRICAL_SOURCE
    rate = (x["ru_b"] - x["ru_a"]) / (x["shots_b"] - x["shots_a"])
    overhead = x["ru_a"] - rate * x["shots_a"]
    return {"empirical_estimate_ru": jobs * overhead + shots * rate,
            "ibm_generic_estimate_ru": (2 * jobs + .00035 * shots) / 60,
            "physical_jobs": jobs, "acquired_shots": shots,
            "assumption": "One modeled preparation overhead per physical job. Extra server sub-jobs and changed timing can increase consumption.",
            "not_a_guaranteed_maximum": True}


def preflight_balance(estimates, live_remaining=None, declared_remaining=None, reserve=.20):
    values = [float(x) for x in (live_remaining, declared_remaining) if x is not None]
    if any(x < 0 for x in values) or reserve < 0:
        raise ValueError("Allowance and reserve must be nonnegative")
    available = min(values) if values else None
    requirement = estimates["ibm_generic_estimate_ru"] + reserve
    return {"available_ru_used_for_check": available, "estimated_requirement_with_reserve_ru": requirement,
            "reserve_ru": reserve, "estimated_headroom_ru": available - estimates["ibm_generic_estimate_ru"] if available is not None else None,
            "check_passed": available >= requirement if available is not None else None,
            "scope": "Initial advisory feasibility check, not a hard usage cap. Live and declared balances use the smaller value when both are available."}
