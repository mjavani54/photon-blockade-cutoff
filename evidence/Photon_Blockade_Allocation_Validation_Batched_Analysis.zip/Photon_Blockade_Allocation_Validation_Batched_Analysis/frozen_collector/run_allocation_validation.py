"""Batched allocation validation: one shared calibration/science job pair per block."""

import argparse
from datetime import datetime, timedelta, timezone
from hashlib import sha256
from importlib.metadata import version, PackageNotFoundError
import json
from pathlib import Path
import platform
from uuid import uuid4

import numpy as np

from experiment import HERE, DEFAULT_SEED, make_schedule, profile, validate_schedule
from runtime_io import atomic_json, collection_lock, connect_service, hardware_stage, prepare_sampler, validate_record, now
from ru_estimate import estimate_usage, preflight_balance

SOURCE_NAMES = ("experiment.py", "logical_schedule.py", "ru_estimate.py", "runtime_io.py", "run_allocation_validation.py", "analyze_allocation_validation.py",
                "intervals.py", "matrix_readout.py", "readout_intervals.py", "frozen_allocation.json", "planning_evidence.json")


def source_hashes():
    return {n: sha256((HERE / n).read_bytes()).hexdigest() for n in SOURCE_NAMES}


def check_sources(config):
    if source_hashes() != config["source_sha256"]:
        raise ValueError("Code or frozen inputs changed after this run began. Preserve its files and use the original version to resume.")


def demo_stage(stage, schedule, demo_profile):
    counts = np.asarray(profile()["pooled_calibration_counts"], dtype=float)
    base = counts / counts.sum(axis=0)
    block, blocks = stage["block_index"], schedule["blocks"]
    factor = 1.0
    if demo_profile == "linear_up":
        factor = .5 + (block + .5) / blocks
    elif demo_profile == "pulse" and blocks // 3 <= block < 2 * blocks // 3:
        factor = 2.0
    elif demo_profile == "local_drop" and stage["purpose"] == "science":
        factor = .75
    matrix = np.eye(4) + factor * (base - np.eye(4))
    rng = np.random.default_rng(np.random.SeedSequence([schedule["seed"], schedule["replicate"], 31, stage["stage_index"]]))
    samples = []
    for pub in stage["pubs"]:
        labels = rng.choice(4, size=pub["shots"], p=matrix[:, pub["prepared_state"]])
        samples.append({"pub_index": pub["pub_index"], "counts": np.bincount(labels, minlength=4).tolist(),
                        "ordered_bitstrings": [f"{int(x):02b}" for x in labels], "pub_metadata": {}})
    start = datetime(2026, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=10 * stage["stage_index"])
    stop = start + timedelta(seconds=1)
    return {"stage_id": stage["stage_id"], "stage_sha256": stage["sha256"], "provenance": "synthetic_demo",
            "job_id": None, "client_submitted": start.isoformat(), "client_retrieved": stop.isoformat(),
            "samples": samples, "execution_windows": [{"kind": "synthetic_demo", "start": start.isoformat(),
            "stop": stop.isoformat(), "pub_indices": list(range(len(samples)))}], "job_metrics": {},
            "result_metadata": {"synthetic_channel": matrix.tolist(), "demo_profile": demo_profile}}


def collect(args, folder, schedule):
    manifest_path = folder / "collection_manifest.json"
    config = json.loads(manifest_path.read_text()) if manifest_path.exists() else None
    provenance = "ibm_hardware" if args.ibm else "synthetic_demo"
    journal_path = folder / "jobs.json"
    journal = json.loads(journal_path.read_text()) if journal_path.exists() else {"stages": {}}
    if config:
        if config["schedule_sha256"] != schedule["sha256"] or config["provenance"] != provenance or config["demo_profile"] != (args.demo_profile if args.demo else None):
            raise ValueError("This output directory belongs to different settings or mode; use its original command or a new --out folder")
        check_sources(config)
        if args.ibm and (args.backend != config["backend"] or list(args.qubits) != config["physical_qubits"]):
            raise ValueError("Backend or physical qubits differ from this existing collection")
    complete = config is not None and all((folder / "stages" / f"stage_{s['stage_index']:03d}.json").exists() for s in schedule["stages"])
    service = sampler = circuits = None
    instance_digest = None
    account_snapshot = {}
    preflight = None
    if args.ibm and not complete:
        service, instance = connect_service(args.account, args.instance)
        instance_digest = sha256(instance.encode()).hexdigest()
        if config and instance_digest != config["instance_sha256"]:
            raise ValueError("Resume must use the same Open Plan instance as the original collection")
        backend, qubits, circuits, sampler = prepare_sampler(service, args.backend, args.qubits, instance)
        backend_name = backend.name
        try:
            usage = service.usage()
            account_snapshot = {k: v for k, v in usage.items() if k.startswith("usage_") and isinstance(v, (int, float))}
        except Exception as error:
            account_snapshot = {"unavailable": type(error).__name__}
        print("Verified Open Plan instance. Paid-plan fallback is disabled.", flush=True)
        if "usage_remaining_ru" in account_snapshot:
            print(f"Reported remaining allowance: {account_snapshot['usage_remaining_ru']} RUs. This is not a forecast of the run's usage.", flush=True)
        has_activity = any(e.get("submission_intent") or e.get("job_id") for e in journal["stages"].values()) or any((folder / "stages").glob("*.json"))
        if not has_activity:
            preflight = preflight_balance(estimate_usage(schedule["total_shots"], schedule["total_jobs"]),
                                          account_snapshot.get("usage_remaining_ru"), args.available_ru, args.reserve_ru)
            if preflight["check_passed"] is None:
                raise RuntimeError("Remaining RUs could not be read. Check your dashboard and pass --available-ru CURRENT_BALANCE. No jobs were submitted.")
            if not preflight["check_passed"]:
                raise RuntimeError(f"Estimated usage plus reserve needs {preflight['estimated_requirement_with_reserve_ru']:.3f} RUs, but the allowance used for this check is {preflight['available_ru_used_for_check']:.3f}. No jobs were submitted.")
            print(f"Initial allowance check passed; planning reserve {args.reserve_ru:.2f} RUs. Estimates are not a hard usage cap.", flush=True)
    elif config:
        backend_name, qubits = config["backend"], config["physical_qubits"]
    else:
        backend_name, qubits = "synthetic_demo", [0, 1]
    if config is None:
        packages = {}
        for name in ("numpy", "scipy", "qiskit", "qiskit-ibm-runtime"):
            try:
                packages[name] = version(name)
            except PackageNotFoundError:
                pass
        planned = profile()
        config = {"schema_version": 1, "run_id": uuid4().hex[:16], "created_utc": now(),
                  "protocol_id": schedule["protocol_id"], "provenance": provenance,
                  "allocation_source_protocol_id": planned["protocol_id"],
                  "purpose": "workflow_smoke" if args.smoke else "paired_batched_allocation_hardware_pilot",
                  "backend": backend_name, "physical_qubits": list(qubits),
                  "planning_device_match": backend_name == planned["planning_backend"] and list(qubits) == planned["planning_qubits"],
                  "schedule_sha256": schedule["sha256"], "frozen_profile_sha256": schedule["frozen_profile_sha256"],
                  "planned_shots": schedule["total_shots"], "planned_device_shots": schedule["total_shots"] if args.ibm else 0,
                  "family_alpha": .05, "instance_sha256": instance_digest, "instance_plan": "open" if args.ibm else None,
                  "usage_snapshot_before": account_snapshot, "demo_profile": args.demo_profile if args.demo else None,
                  "initial_ru_preflight": preflight,
                  "usage_estimates": estimate_usage(schedule["total_shots"], schedule["total_jobs"]),
                  "python": platform.python_version(), "packages": packages, "source_sha256": source_hashes(),
                  "timing_policy": "Within each block both arms have distinct PUBs in one shared calibration job, which finishes before the shared science job is submitted. PUB order is precommitted and mixed; physical arm order is not asserted.",
                  "preparation": "X-only nominal number-label mixtures. Source labels are reserved for diagnostics; the primary estimator uses calibration and science measurements only.",
                  "scope": "One paired allocation pilot; no cavity dynamics, hardware power rate, or general resource advantage is established."}
        atomic_json(manifest_path, config)
    for stage in schedule["stages"]:
        check_sources(config)
        path = folder / "stages" / f"stage_{stage['stage_index']:03d}.json"
        print(f"Physical job {stage['stage_index']+1}/{schedule['total_jobs']}: {stage['stage_id']}, {stage['shots']:,} acquired shots across both arms", flush=True)
        if path.exists():
            record = json.loads(path.read_text())
            validate_record(record, stage, provenance)
            if record.get("collector_source_sha256") != config["source_sha256"]:
                raise ValueError("Saved stage source provenance differs")
            print("  Reused saved data.", flush=True)
            continue
        record = hardware_stage(service, sampler, circuits, config, stage, journal, journal_path) if args.ibm else demo_stage(stage, schedule, args.demo_profile)
        validate_record(record, stage, provenance)
        record["collector_source_sha256"] = source_hashes()
        atomic_json(path, record)
    return config


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--plan", action="store_true", help="Show the frozen budget locally without an IBM connection")
    mode.add_argument("--demo", action="store_true", help="Run a synthetic local workflow without hardware")
    mode.add_argument("--ibm", action="store_true", help="Collect on a verified IBM Open Plan instance")
    parser.add_argument("--smoke", action="store_true", help="Use the small workflow-check allocation")
    parser.add_argument("--replicate", type=int, default=1, help="Fresh run number; change this for independent source samples and order")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--backend", default="ibm_marrakesh")
    parser.add_argument("--qubits", type=int, nargs=2, default=[14, 55], help="Physical low-bit and high-bit qubits")
    parser.add_argument("--account", help="Saved IBM account name")
    parser.add_argument("--instance", help="Open Plan instance CRN, otherwise environment or unique accessible Open instance")
    parser.add_argument("--out", type=Path)
    parser.add_argument("--available-ru", type=float, help="Current dashboard balance; fallback if live remaining RUs are unavailable")
    parser.add_argument("--reserve-ru", type=float, default=.20, help="Reserve for the initial estimate check; not a hard usage cap")
    parser.add_argument("--demo-profile", choices=["stationary", "linear_up", "pulse", "local_drop"], default="stationary")
    args = parser.parse_args()
    if args.reserve_ru < 0 or (args.available_ru is not None and args.available_ru < 0):
        parser.error("Allowance and reserve must be nonnegative")
    try:
        schedule = make_schedule(args.smoke, args.seed, args.replicate)
    except ValueError as error:
        parser.error(str(error))
    budgets = validate_schedule(schedule)
    estimates = estimate_usage(schedule["total_shots"], schedule["total_jobs"])
    print(f"{'Smoke' if args.smoke else 'Full'} v2 batched comparison: {schedule['total_shots']:,} acquired shots in {schedule['total_jobs']} physical jobs.", flush=True)
    print(f"Approximate total usage: {estimates['empirical_estimate_ru']:.2f} RUs from prior metrics; {estimates['ibm_generic_estimate_ru']:.2f} RUs from the generic formula. Not a guaranteed maximum.", flush=True)
    if args.plan:
        print(json.dumps({"replicate": args.replicate, "seed": args.seed, "arm_plans": schedule["arm_plans"], "arm_budgets": budgets,
                          "timing": schedule["grouping"], "new_hardware_shots": 0, "usage_estimates": estimates,
                          "declared_balance_check": preflight_balance(estimates, None, args.available_ru, args.reserve_ru)}, indent=2))
        return
    name = "allocation_validation_batched" + ("_demo" if args.demo else "") + ("_smoke" if args.smoke else "_results")
    if args.replicate != 1:
        name += f"_r{args.replicate:03d}"
    folder = args.out or HERE / name
    folder.mkdir(parents=True, exist_ok=True)
    with collection_lock(folder):
        plan_path = folder / "schedule.json"
        if plan_path.exists() and json.loads(plan_path.read_text()) != schedule:
            raise ValueError("This directory has a different frozen schedule; use the original command or a new --out folder")
        if not plan_path.exists():
            atomic_json(plan_path, schedule)
        collect(args, folder, schedule)
        from analyze_allocation_validation import analyze
        archive = analyze(folder)
    print(f"Finished. Upload {archive.resolve()}", flush=True)


if __name__ == "__main__":
    main()
