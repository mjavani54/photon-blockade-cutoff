"""Full assignment-matrix confidence bounds for a four-level photon register."""

import warnings

import numpy as np
from scipy.optimize import OptimizeWarning, linprog

from readout_intervals import binomial_box, g2_interval


LEVELS = np.arange(4)
PAIR_WEIGHTS = LEVELS * (LEVELS - 1)
TRUE_MARGINAL = np.tile(np.eye(4), 4)
MOMENTS = (np.tile(LEVELS, 4), np.tile(PAIR_WEIGHTS, 4))
OBSERVED_TAIL = np.stack([
    np.repeat(LEVELS >= threshold, 4).astype(float) for threshold in (1, 2, 3)
])
ALPHA_PER_PART = 0.025
SOLVER_OPTIONS = {
    "threads": 1,
    "primal_feasibility_tolerance": 1e-9,
    "dual_feasibility_tolerance": 1e-9,
}


def assignment_matrix(error, joint_excess=0.0):
    """Use symmetric marginals with a specified excess joint bit-flip probability."""
    flip_probabilities = np.array([
        (1 - error)**2 + joint_excess,
        error * (1 - error) - joint_excess,
        error * (1 - error) - joint_excess,
        error**2 + joint_excess,
    ])
    if np.any(flip_probabilities < 0):
        raise ValueError("The correlated assignment probabilities are negative")
    matrix = flip_probabilities[np.bitwise_xor(LEVELS[:, None], LEVELS[None, :])]
    if not np.allclose(matrix.sum(axis=0), 1):
        raise ValueError("Assignment matrix columns must sum to one")
    return matrix


def marginal_errors(histogram_00, histogram_11):
    return np.array([
        histogram_00[1] + histogram_00[3],
        histogram_11[0] + histogram_11[2],
        histogram_00[2] + histogram_00[3],
        histogram_11[0] + histogram_11[1],
    ], dtype=np.int64)


def science_box(histogram):
    counts = np.cumsum(histogram[:0:-1])[::-1]
    return binomial_box(int(histogram.sum()), counts, counts, ALPHA_PER_PART)


def independent_interval(histograms, science):
    sizes = histograms.sum(axis=0)
    rates = marginal_errors(histograms[:, 0], histograms[:, 3])
    rate_sizes = np.array([sizes[0], sizes[3], sizes[0], sizes[3]])
    rate_box = binomial_box(rate_sizes, rates, rates, ALPHA_PER_PART)
    lower, upper = g2_interval(science_box(science), rate_box)
    return float(lower), float(upper), "ok"


def full_matrix_interval(matrix_box, tail_box):
    """Bound moments over all states and assignment matrices in both boxes.

    z[y, x] = A[y, x] p[x]. Column sums are the unknown true populations.
    """
    low_matrix, high_matrix = matrix_box
    low_tail, high_tail = tail_box
    if any(np.shape(m) != (4, 4) for m in matrix_box):
        raise ValueError("The assignment interval must contain two 4 by 4 matrices")
    identity = np.eye(16)
    column_sums = np.tile(TRUE_MARGINAL, (4, 1))
    constraints = np.vstack((
        identity - high_matrix.reshape(-1, 1) * column_sums,
        low_matrix.reshape(-1, 1) * column_sums - identity,
        OBSERVED_TAIL, -OBSERVED_TAIL,
    ))
    bounds = np.concatenate((np.zeros(32), high_tail, -low_tail))
    moment_limits = []
    # SciPy forwards the single-thread setting to its HiGHS backend.
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Unrecognized options detected:.*threads", category=OptimizeWarning)
        for weights in MOMENTS:
            minimum = linprog(
                weights, A_ub=constraints, b_ub=bounds,
                A_eq=np.ones((1, 16)), b_eq=[1.0], bounds=(0, None),
                method="highs", options=SOLVER_OPTIONS,
            )
            maximum = linprog(
                -weights, A_ub=constraints, b_ub=bounds,
                A_eq=np.ones((1, 16)), b_eq=[1.0], bounds=(0, None),
                method="highs", options=SOLVER_OPTIONS,
            )
            if not minimum.success or not maximum.success:
                status = "infeasible" if 2 in (minimum.status, maximum.status) else "numerical_issue"
                return 0.0, np.inf, status
            moment_limits.append((max(float(minimum.fun), 0.0), max(float(-maximum.fun), 0.0)))
    (mean_low, mean_high), (pair_low, pair_high) = moment_limits
    lower = pair_low / mean_high**2 if mean_high > 0 else 0.0
    upper = pair_high / mean_low**2 if mean_low > 1e-14 else np.inf
    return lower, upper, "ok"


def full_interval(histograms, science):
    sizes = np.tile(histograms.sum(axis=0), 4)
    counts = histograms.ravel()
    low, high = binomial_box(sizes, counts, counts, ALPHA_PER_PART)
    return full_matrix_interval((low.reshape(4, 4), high.reshape(4, 4)), science_box(science))
