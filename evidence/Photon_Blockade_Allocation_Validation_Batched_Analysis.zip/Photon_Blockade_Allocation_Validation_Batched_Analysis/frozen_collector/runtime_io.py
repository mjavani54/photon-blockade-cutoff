"""IBM Runtime I/O, hidden local credentials, and resumable job retrieval."""

from contextlib import contextmanager
from datetime import datetime, timezone
from getpass import getpass
from hashlib import sha256
import json
import os
from pathlib import Path
import sys

import numpy as np


def now():
    return datetime.now(timezone.utc).isoformat()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix+".part")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    temporary.replace(path)


def safe_json(value):
    try:
        from qiskit_ibm_runtime import RuntimeEncoder
        return json.loads(json.dumps(value, cls=RuntimeEncoder, allow_nan=False))
    except (ImportError, TypeError, ValueError):
        return {"type": type(value).__name__, "representation": str(value)}


@contextmanager
def collection_lock(folder):
    with (Path(folder)/"collector.lock").open("a+b") as lock:
        if os.name == "nt":
            import msvcrt
            lock.seek(0); lock.write(b"0"); lock.flush(); lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            if os.name == "nt":
                lock.seek(0); msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def select_open_instance(instances, requested=None):
    if requested:
        matches = [r for r in instances if requested in (r.get("crn"), r.get("name"))]
        if len(matches) != 1:
            raise RuntimeError("The requested instance was not uniquely found. Use its CRN and the matching IBM Cloud account.")
    else:
        matches = [r for r in instances if str(r.get("plan", "")).lower() == "open"]
        if len(matches) != 1:
            raise RuntimeError("Specify --instance CRN for an accessible Open Plan instance; no unique free instance was found.")
    chosen = matches[0]
    if str(chosen.get("plan", "")).lower() != "open" or not chosen.get("crn"):
        raise RuntimeError("This collector requires a verified Open Plan instance. No hardware job was submitted.")
    return chosen["crn"]


def connect_service(account=None, instance=None):
    from qiskit_ibm_runtime import QiskitRuntimeService
    from qiskit_ibm_runtime.accounts.exceptions import AccountNotFoundError
    from qiskit_ibm_runtime.exceptions import IBMInputValueError
    token = os.environ.get("QISKIT_IBM_TOKEN")
    instance = instance or os.environ.get("QISKIT_IBM_INSTANCE")
    kwargs = {"channel": "ibm_quantum_platform", "plans_preference": ["open"]}
    kwargs.update({"name": account} if account else ({"token": token} if token else {}))
    if instance:
        kwargs["instance"] = instance
    try:
        try:
            service = QiskitRuntimeService(**kwargs)
        except AccountNotFoundError:
            if account:
                raise RuntimeError(f"Saved IBM account {account!r} was not found") from None
            if not sys.stdin.isatty():
                raise RuntimeError("Set QISKIT_IBM_TOKEN and QISKIT_IBM_INSTANCE locally, or use a saved IBM account") from None
            token = getpass("IBM Quantum API key (hidden input): ").strip()
            if not token:
                raise RuntimeError("An API key or saved IBM account is required")
            kwargs["token"] = token
            service = QiskitRuntimeService(**kwargs)
        chosen = select_open_instance(service.instances(), instance)
        # The backend is also explicitly bound to this verified CRN. Automatic
        # selection can never route a submission to an additional paid instance.
        return service, chosen
    except IBMInputValueError as error:
        if "No matching instances" in str(error):
            raise RuntimeError("IBM found no accessible instance. Copy your instance CRN from IBM Quantum Instances and pass --instance CRN. Use an API key belonging to that IBM Cloud account.") from error
        raise


def basis_circuits():
    from qiskit import ClassicalRegister, QuantumCircuit, QuantumRegister
    circuits = []
    for state in range(4):
        q, c = QuantumRegister(2, "q"), ClassicalRegister(2, "photon")
        circuit = QuantumCircuit(q, c, name=f"number_label_{state:02b}")
        for bit in range(2):
            if (state >> bit) & 1:
                circuit.x(bit)
        circuit.measure(q, c)
        circuit.metadata = {"prepared_state": state}
        circuits.append(circuit)
    return circuits


def prepare_sampler(service, backend_name, qubits, instance=None):
    from qiskit.transpiler import generate_preset_pass_manager
    from qiskit_ibm_runtime.executor_sampler import Sampler
    if backend_name == "auto":
        raise ValueError("Choose an explicit backend for this frozen allocation test")
    backend = service.backend(backend_name, instance=instance)
    if backend.name.startswith(("mock", "fake")) or backend.configuration().simulator:
        raise ValueError("The --ibm mode requires an actual hardware backend")
    if not backend.status().operational:
        raise RuntimeError(f"Backend {backend.name} is not currently operational")
    properties = backend.properties()
    if qubits is None:
        qubits = [14, 55] if backend.name == "ibm_marrakesh" else sorted(
            [q for q in range(backend.num_qubits) if properties.is_qubit_operational(q)],
            key=properties.readout_error)[:2]
    qubits = list(qubits)
    if len(qubits) != 2 or len(set(qubits)) != 2 or min(qubits) < 0 or max(qubits) >= backend.num_qubits:
        raise ValueError("Choose two distinct physical qubits on this backend")
    for q in qubits:
        if not properties.is_qubit_operational(q):
            raise ValueError(f"Physical qubit {q} is not operational")
        if not all(backend.target.instruction_supported(gate, (q,)) for gate in ("x", "measure")):
            raise ValueError(f"Physical qubit {q} must support X and measurement")
    pm = generate_preset_pass_manager(backend=backend, initial_layout=qubits,
        optimization_level=0, seed_transpiler=26111831)
    circuits = pm.run(basis_circuits())
    sampler = Sampler(mode=backend, options={
        "twirling": {"enable_gates": False, "enable_measure": False},
        "dynamical_decoupling": {"enable": False}, "execution": {"init_qubits": True},
    })
    return backend, qubits, circuits, sampler


def samples_from_result(result, stage):
    if len(result) != len(stage["pubs"]):
        raise ValueError("The result has a different number of PUBs than the saved stage plan")
    samples = []
    for i, pub in enumerate(stage["pubs"]):
        bits = result[i].data.photon
        if bits.num_bits != 2:
            raise ValueError("The photon register must contain exactly two measured bits")
        strings = bits.get_bitstrings()
        if len(strings) != pub["shots"] or any(len(s) != 2 or set(s)-set("01") for s in strings):
            raise ValueError("Unexpected bitstring size or shot count")
        counts = np.bincount([int(s, 2) for s in strings], minlength=4)
        metadata = result[i].metadata
        declared = metadata.get("circuit_metadata", {}).get("prepared_state")
        if declared is not None and declared != pub["prepared_state"]:
            raise ValueError("Returned circuit metadata disagrees with the scheduled state")
        samples.append({"pub_index": i, "counts": counts.tolist(), "ordered_bitstrings": strings,
            "pub_metadata": safe_json(metadata)})
    return samples


def execution_windows(metadata, pub_count):
    windows = []
    executor = metadata.get("executor")
    chunks = executor.get("chunk_timing") if isinstance(executor, dict) else getattr(executor, "chunk_timing", None)
    def read(obj, key):
        return obj.get(key) if isinstance(obj, dict) else getattr(obj, key, None)
    for chunk in chunks or []:
        indices = [int(read(p, "idx_item")) for p in (read(chunk, "parts") or [])]
        if any(not 0 <= i < pub_count for i in indices):
            raise ValueError("Executor timing metadata refers to an unknown PUB")
        windows.append({"kind": "executor_chunk", "start": str(read(chunk, "start")),
            "stop": str(read(chunk, "stop")), "pub_indices": indices})
    spans = metadata.get("execution", {}).get("execution_spans")
    for span in spans or []:
        indices = []
        for i in range(pub_count):
            try:
                if np.any(span.mask(i)):
                    indices.append(i)
            except (KeyError, IndexError, ValueError):
                pass
        windows.append({"kind": "legacy_execution_span", "start": span.start.isoformat(),
            "stop": span.stop.isoformat(), "pub_indices": indices})
    return windows


def hardware_stage(service, sampler, circuits, config, stage, journal, journal_path):
    if len({p["shots"] for p in stage["pubs"]}) != 1:
        raise ValueError("The Runtime client requires uniform acquired shots within a job")
    key = stage["stage_id"]
    entry = journal["stages"].get(key)
    if entry is None:
        entry = {"tag": f"photon-alloc-batched-{config['run_id']}-{stage['stage_index']:03d}",
            "stage_sha256": stage["sha256"], "job_id": None, "submission_intent": False}
        journal["stages"][key] = entry
        atomic_json(journal_path, journal)
    if entry["stage_sha256"] != stage["sha256"]:
        raise ValueError("The outstanding job was created for a different stage plan")
    if entry["job_id"]:
        try:
            job = service.job(entry["job_id"])
        except Exception as error:
            if type(error).__name__ == "RuntimeJobNotFound":
                raise RuntimeError(f"Saved job {entry['job_id']} cannot be found, possibly because it was deleted. The journal was preserved and no replacement was submitted. Use a new --out folder for a new smoke run; preserve incomplete full runs for review.") from error
            raise
    elif entry["submission_intent"]:
        matches = service.jobs(limit=2, job_tags=[entry["tag"]])
        if len(matches) != 1:
            raise RuntimeError(f"An interrupted submission is unresolved. Check IBM Workloads for tag {entry['tag']}, then rerun. Another job was not submitted.")
        job = matches[0]
        entry["job_id"] = job.job_id()
        atomic_json(journal_path, journal)
    else:
        entry.update(submission_intent=True, client_submitted=now())
        atomic_json(journal_path, journal)
        sampler.options.environment.job_tags = ["photon-allocation-batched", entry["tag"]]
        pubs = [(circuits[p["prepared_state"]], None, p["shots"]) for p in stage["pubs"]]
        job = sampler.run(pubs)
        entry["job_id"] = job.job_id()
        atomic_json(journal_path, journal)
    print(f"  Waiting for {entry['job_id']}", flush=True)
    try:
        result = job.result()
    except Exception as error:
        raise RuntimeError(f"Job {entry['job_id']} did not return a completed result: {error}. Its ID was preserved; no replacement job was submitted.") from error
    retrieved = now()
    samples = samples_from_result(result, stage)
    windows = execution_windows(result.metadata, len(stage["pubs"]))
    try:
        metrics = safe_json(job.metrics())
    except Exception as error:
        metrics = {"metrics_unavailable": type(error).__name__}
    return {"stage_id": key, "stage_sha256": stage["sha256"], "provenance": "ibm_hardware",
        "job_id": entry["job_id"], "client_submitted": entry.get("client_submitted"),
        "client_retrieved": retrieved, "samples": samples, "execution_windows": windows,
        "job_metrics": metrics, "result_metadata": safe_json(result.metadata)}


def validate_record(record, stage, provenance):
    if record["stage_id"] != stage["stage_id"] or record["stage_sha256"] != stage["sha256"] or record["provenance"] != provenance:
        raise ValueError("Saved data do not match this stage plan or collection mode")
    if len(record["samples"]) != len(stage["pubs"]):
        raise ValueError("A saved stage is missing PUB results")
    for pub, sample in zip(stage["pubs"], record["samples"], strict=True):
        if pub["pub_index"] != sample["pub_index"]:
            raise ValueError("Saved PUB order differs from the plan")
        strings = sample["ordered_bitstrings"]
        if len(strings) != pub["shots"] or any(len(s) != 2 or set(s)-set("01") for s in strings):
            raise ValueError("Saved bitstrings do not match the requested shots")
        counts = np.bincount([int(s, 2) for s in strings], minlength=4)
        if not np.array_equal(counts, sample["counts"]):
            raise ValueError("Saved raw bitstrings and aggregate counts differ")
    if provenance == "ibm_hardware" and not record.get("job_id"):
        raise ValueError("A hardware record is missing its IBM job identifier")
    return True
