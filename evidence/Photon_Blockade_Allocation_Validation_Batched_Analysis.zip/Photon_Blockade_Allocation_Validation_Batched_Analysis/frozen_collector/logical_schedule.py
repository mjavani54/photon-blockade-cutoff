"""Frozen allocation comparison: both arms use local distributed calibration."""

from hashlib import sha256
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ARMS = ("reference_allocation", "selected_allocation")
POPULATIONS = ("signal", "control")
DEFAULT_SEED = 26111917
LEVELS = np.arange(4)


def checksum(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def g2(probabilities):
    p = np.asarray(probabilities, dtype=float)
    mean = p @ LEVELS
    return float(p @ (LEVELS * (LEVELS - 1)) / mean**2) if mean > 0 else np.inf


def profile():
    result = json.loads((HERE / "frozen_allocation.json").read_text())
    expected = {
        "reference_allocation": ([1600, 1536, 1536, 1536], {"signal": 6208, "control": 6208}),
        "selected_allocation": ([5568, 3520, 192, 64], {"signal": 6976, "control": 2304}),
    }
    if result["blocks"] != 16 or result["microbatch"] != 64 or not result["model_goals_met"]:
        raise ValueError("The frozen planning profile differs from the validated design")
    for arm, (calibration, science) in expected.items():
        if result["arms"][arm]["calibration_shots_per_state_per_block"] != calibration or result["arms"][arm]["science_shots_per_population_per_block"] != science:
            raise ValueError("The frozen allocation was modified")
    return result


def make_schedule(smoke=False, seed=DEFAULT_SEED, replicate=1):
    if seed < 0 or replicate < 1:
        raise ValueError("Use a nonnegative seed and a replicate number of at least one")
    frozen = profile()
    blocks, chunk = (2 if smoke else 16), 64
    plans = {}
    for arm in ARMS:
        plans[arm] = {"calibration": frozen["arms"][arm]["calibration_shots_per_state_per_block"],
                      "science": frozen["arms"][arm]["science_shots_per_population_per_block"]}
    if smoke:
        plans = {
            "reference_allocation": {"calibration": [128] * 4, "science": {"signal": 512, "control": 512}},
            "selected_allocation": {"calibration": [384, 256, 64, 64], "science": {"signal": 576, "control": 192}},
        }
    order_rng = np.random.default_rng(np.random.SeedSequence([seed, replicate, 0]))
    selected_first = order_rng.permutation([0, 1] * (blocks // 2)).tolist()
    stages = []
    for block in range(blocks):
        order = ARMS[::-1] if selected_first[block] else ARMS
        for arm in order:
            arm_index = ARMS.index(arm)
            for purpose in ("calibration", "science"):
                rng = np.random.default_rng(np.random.SeedSequence([seed, replicate, block, arm_index, 1 if purpose == "calibration" else 2]))
                pubs = []
                if purpose == "calibration":
                    for state, shots in enumerate(plans[arm]["calibration"]):
                        for _ in range(shots // chunk):
                            pubs.append({"role": "calibration", "population": None, "prepared_state": state, "shots": chunk, "analysis_shots": chunk})
                else:
                    for pop in POPULATIONS:
                        labels = rng.multinomial(plans[arm]["science"][pop], frozen["targets"][pop]["probabilities"])
                        for state, count in enumerate(labels):
                            remaining = int(count)
                            while remaining:
                                kept = min(remaining, chunk)
                                pubs.append({"role": "science", "population": pop, "prepared_state": state, "shots": chunk, "analysis_shots": kept})
                                remaining -= kept
                    pub_budget = sum(n // chunk + 3 for n in plans[arm]["science"].values())
                    while len(pubs) < pub_budget:
                        pubs.append({"role": "padding", "population": None, "prepared_state": len(pubs) % 4, "shots": chunk, "analysis_shots": 0})
                    if len(pubs) != pub_budget:
                        raise ValueError("Science packing exceeded its predeclared acquired budget")
                rng.shuffle(pubs)
                for index, pub in enumerate(pubs):
                    pub["pub_index"] = index
                stage = {"stage_id": f"block_{block:03d}_{arm}_{purpose}", "stage_index": len(stages),
                         "arm": arm, "purpose": purpose, "block_index": block, "pubs": pubs,
                         "shots": sum(p["shots"] for p in pubs), "analysis_shots": sum(p["analysis_shots"] for p in pubs)}
                stage["sha256"] = checksum(stage)
                stages.append(stage)
    schedule = {"schema_version": 1, "protocol_id": frozen["protocol_id"],
                "frozen_profile_sha256": sha256((HERE / "frozen_allocation.json").read_bytes()).hexdigest(),
                "smoke": smoke, "seed": seed, "replicate": replicate, "blocks": blocks, "microbatch": chunk,
                "targets": frozen["targets"], "arm_plans": plans, "selected_first_by_block": selected_first,
                "total_jobs": len(stages), "total_shots": sum(s["shots"] for s in stages),
                "total_analysis_shots": sum(s["analysis_shots"] for s in stages), "stages": stages}
    schedule["sha256"] = checksum(schedule)
    return schedule


def validate_schedule(schedule):
    if schedule != make_schedule(schedule["smoke"], schedule["seed"], schedule["replicate"]):
        raise ValueError("The precommitted schedule differs from the frozen protocol")
    totals = {a: {"calibration": 0, "calibration_by_state": [0] * 4, "signal": 0, "control": 0,
                  "acquired_shots": 0, "analyzed_shots": 0, "discarded_shots": 0, "jobs": 0} for a in ARMS}
    for i in range(0, len(schedule["stages"]), 2):
        cal, sci = schedule["stages"][i:i + 2]
        if cal["purpose"] != "calibration" or sci["purpose"] != "science" or (cal["arm"], cal["block_index"]) != (sci["arm"], sci["block_index"]):
            raise ValueError("Each science stage must immediately follow its own calibration stage")
    for stage in schedule["stages"]:
        t = totals[stage["arm"]]
        t["jobs"] += 1
        for pub in stage["pubs"]:
            if pub["shots"] != 64 or not 0 <= pub["analysis_shots"] <= 64:
                raise ValueError("PUB shots or predeclared retained counts changed")
            t["acquired_shots"] += pub["shots"]
            t["analyzed_shots"] += pub["analysis_shots"]
            t["discarded_shots"] += pub["shots"] - pub["analysis_shots"]
            if pub["role"] == "calibration":
                t["calibration"] += pub["analysis_shots"]
                t["calibration_by_state"][pub["prepared_state"]] += pub["analysis_shots"]
            elif pub["role"] == "science":
                t[pub["population"]] += pub["analysis_shots"]
    for arm in ARMS:
        plan = schedule["arm_plans"][arm]
        if totals[arm]["calibration_by_state"] != [schedule["blocks"] * k for k in plan["calibration"]]:
            raise ValueError("Per-state calibration budget differs")
        for pop in POPULATIONS:
            if totals[arm][pop] != schedule["blocks"] * plan["science"][pop]:
                raise ValueError("Per-population science budget differs")
    for field in ("acquired_shots", "analyzed_shots", "discarded_shots", "jobs"):
        if totals[ARMS[0]][field] != totals[ARMS[1]][field]:
            raise ValueError(f"Arm budgets differ for {field}")
    if not schedule["smoke"] and (schedule["total_shots"] != 608256 or schedule["total_jobs"] != 64):
        raise ValueError("Full-run cost differs from the frozen profile")
    return totals
