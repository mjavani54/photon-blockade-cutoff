"""Version 2: same logical allocation, two shared physical jobs per block."""

from hashlib import sha256

import numpy as np

from logical_schedule import (ARMS, POPULATIONS, DEFAULT_SEED, HERE, checksum,
                              g2, profile, make_schedule as logical_schedule,
                              validate_schedule as validate_logical_schedule)

PROTOCOL_ID = "allocation-validation-v2-batched"


def make_schedule(smoke=False, seed=DEFAULT_SEED, replicate=1):
    logical = logical_schedule(smoke, seed, replicate)
    validate_logical_schedule(logical)
    stages = []
    for block in range(logical["blocks"]):
        for purpose in ("calibration", "science"):
            pubs = []
            logical_ids = []
            for arm in ARMS:
                source = next(s for s in logical["stages"] if s["arm"] == arm and s["block_index"] == block and s["purpose"] == purpose)
                logical_ids.append(source["stage_id"])
                for pub in source["pubs"]:
                    pubs.append({**pub, "arm": arm, "logical_stage_id": source["stage_id"], "logical_pub_index": pub["pub_index"]})
            rng = np.random.default_rng(np.random.SeedSequence([seed, replicate, 47, block, 0 if purpose == "calibration" else 1]))
            rng.shuffle(pubs)
            for i, pub in enumerate(pubs):
                pub["pub_index"] = i
            stage = {"stage_id": f"block_{block:03d}_shared_{purpose}", "stage_index": len(stages),
                     "arm": "shared", "arms": list(ARMS), "purpose": purpose, "block_index": block,
                     "logical_stage_ids": logical_ids, "pubs": pubs,
                     "shots": sum(p["shots"] for p in pubs), "analysis_shots": sum(p["analysis_shots"] for p in pubs),
                     "shots_by_arm": {a: sum(p["shots"] for p in pubs if p["arm"] == a) for a in ARMS}}
            stage["sha256"] = checksum(stage)
            stages.append(stage)
    schedule = {"schema_version": 2, "protocol_id": PROTOCOL_ID,
                "allocation_source_protocol_id": logical["protocol_id"],
                "frozen_profile_sha256": logical["frozen_profile_sha256"],
                "logical_schedule_sha256": logical["sha256"], "logical_source_schedule_preserved": True,
                "smoke": smoke, "seed": seed, "replicate": replicate,
                "blocks": logical["blocks"], "microbatch": 64, "targets": logical["targets"],
                "arm_plans": logical["arm_plans"], "total_jobs": len(stages),
                "logical_stage_memberships": logical["total_jobs"],
                "total_shots": sum(s["shots"] for s in stages),
                "total_analysis_shots": sum(s["analysis_shots"] for s in stages),
                "grouping": "One joint calibration job followed by one joint science job per block; distinct PUBs for each arm.",
                "pub_order": "Predeclared joint PUB permutation; physical per-shot execution order is not claimed.",
                "stages": stages}
    schedule["sha256"] = checksum(schedule)
    return schedule


def validate_schedule(schedule):
    if schedule != make_schedule(schedule["smoke"], schedule["seed"], schedule["replicate"]):
        raise ValueError("The schedule differs from the v2 batched protocol; do not reuse v1 output directories")
    logical = logical_schedule(schedule["smoke"], schedule["seed"], schedule["replicate"])
    original = validate_logical_schedule(logical)
    source_pubs = {(s["stage_id"], p["pub_index"]): p for s in logical["stages"] for p in s["pubs"]}
    seen = set()
    totals = {a: {"calibration": 0, "calibration_by_state": [0] * 4, "signal": 0, "control": 0,
                  "acquired_shots": 0, "analyzed_shots": 0, "discarded_shots": 0, "shared_job_memberships": 0} for a in ARMS}
    for i in range(0, len(schedule["stages"]), 2):
        cal, sci = schedule["stages"][i:i + 2]
        if (cal["purpose"], sci["purpose"]) != ("calibration", "science") or cal["block_index"] != sci["block_index"]:
            raise ValueError("Every joint science job must immediately follow its joint calibration job")
    for stage in schedule["stages"]:
        if {p["arm"] for p in stage["pubs"]} != set(ARMS):
            raise ValueError("Both arms must have distinct PUBs in each physical job")
        if stage["shots"] >= 10000000:
            raise ValueError("A shared job exceeds the sampler execution limit")
        for a in ARMS:
            totals[a]["shared_job_memberships"] += 1
        for pub in stage["pubs"]:
            key = pub["logical_stage_id"], pub["logical_pub_index"]
            if key in seen or key not in source_pubs:
                raise ValueError("A logical PUB was duplicated or lost during batching")
            seen.add(key)
            original_pub = source_pubs[key]
            for field in ("role", "population", "prepared_state", "shots", "analysis_shots"):
                if pub[field] != original_pub[field]:
                    raise ValueError("Batching changed source labels, counts, or the retention rule")
            if pub["shots"] != 64 or not 0 <= pub["analysis_shots"] <= 64:
                raise ValueError("Every acquired PUB must use exactly 64 shots")
            t = totals[pub["arm"]]
            t["acquired_shots"] += pub["shots"]
            t["analyzed_shots"] += pub["analysis_shots"]
            t["discarded_shots"] += pub["shots"] - pub["analysis_shots"]
            if pub["role"] == "calibration":
                t["calibration"] += pub["analysis_shots"]
                t["calibration_by_state"][pub["prepared_state"]] += pub["analysis_shots"]
            elif pub["role"] == "science":
                t[pub["population"]] += pub["analysis_shots"]
    if len(seen) != len(source_pubs):
        raise ValueError("A logical PUB is missing")
    for a in ARMS:
        for field in ("calibration", "calibration_by_state", "signal", "control", "acquired_shots", "analyzed_shots", "discarded_shots"):
            if totals[a][field] != original[a][field]:
                raise ValueError("Batched accounting differs from the original frozen allocation")
    if schedule["total_shots"] != logical["total_shots"] or schedule["total_analysis_shots"] != logical["total_analysis_shots"] or schedule["total_jobs"] * 2 != logical["total_jobs"]:
        raise ValueError("Batching failed to halve jobs while preserving observations")
    return totals
