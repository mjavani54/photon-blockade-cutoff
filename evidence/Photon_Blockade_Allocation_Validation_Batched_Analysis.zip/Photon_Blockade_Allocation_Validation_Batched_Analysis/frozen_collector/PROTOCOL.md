# Paired allocation pilot: execution amendment v2

## Question and scope

Does the allocation selected by the 1.5x offline study provide useful nominal-number-label g2 inference compared with its same-shot-budget reference on fresh hardware? Both arms use distributed calibration. This allocation comparison is separate from the earlier before-only versus distributed timing comparison.

The device prepares classical mixtures of labels 0 through 3 using X gates and measurement. Calibration includes preparation and readout error. The signal is the frozen cutoff-3 population from the earlier cavity calculation; the constructed control has the same mean and exactly g2=1. No cavity Hamiltonian is evolved. This is a SPAM benchmark, not direct evidence of physical photon blockade or quantum advantage.

## Amendment made before acquisition

The original logical design requested four jobs per block: a separate calibration/science pair for each arm, with balanced arm-first ordering. V2 combines the arms' distinct calibration PUBs into one physical job, then their distinct science PUBs into one physical job. The calibration job finishes before the science job is submitted. There are 16 blocks and **32 physical jobs**, rather than 64. Separate arm-first ordering is removed. The requested mixed PUB permutation does not establish physical per-shot ordering.

All source-label samples, original logical PUB identities, 64-shot PUB sizes, analyzed counts, and value-independent padding exclusions are preserved. Each shared PUB carries its arm, original stage identity, and original PUB index. Global physical-job PUB indices route returned results to the correct arm. Calibration measurements remain disjoint between arms, with no pooling. The confidence implementation is byte-identical to v1.

`logical_schedule.py`, `frozen_allocation.json`, and `planning_evidence.json` preserve the original allocation evidence, including its historical 64-job schedule. `experiment.py` and the v2 `schedule.json` define the new physical grouping. V1 result folders cannot resume into v2.

## Frozen counts

Per block, reference calibration counts are [1600,1536,1536,1536] and signal/control counts [6208,6208]. Selected calibration counts are [5568,3520,192,64] and signal/control counts [6976,2304]. Each arm also acquires 384 predeclared extra science outcomes per block. Per-input calibration counts and per-population science counts remain constant across blocks within each arm.

Across sixteen blocks each arm acquires 304,128 outcomes, analyzes 297,984, and excludes 6,144 predeclared extras. Total acquisition remains **608,256 shots**, with **595,968 analyzed**. Every acquired outcome enters the resource budget. Physical calibration jobs each have 243 PUBs and 15,552 shots; science jobs each have 351 PUBs and 22,464 shots. Both arms participate in the same 32 physical jobs, whose costs are counted once. No per-arm RU apportionment is inferred.

For each population the nominal source labels were drawn multinomially using the frozen seed and replicate. Packing and retention do not condition on measured outcomes: only the first predeclared analysis count in each PUB is retained. Tail/dummy outcomes remain saved. Changing the replicate changes source samples and requested PUB permutation while keeping allocations and inference fixed. There is no outcome-dependent continuation, extra sampling, or repeated-run selection.

## Inference and endpoints

The existing KL/Chernoff probability boxes and full assignment-matrix LP moment bounds are unchanged. Family alpha is 0.05: alpha/4 for each of two calibration matrices and alpha/8 for each of four science histograms. Each arm's actual unequal sample sizes enter its bounds. Point estimates use the existing simplex-constrained least-squares fit, not a multinomial maximum-likelihood fit.

Primary fitting uses only measured calibration counts and marginal science histograms. Known nominal labels do not fit the primary correction or interval. They are used for target-error assessment and separate held-out response diagnostics. No physical photon-cutoff allowance is added: this benchmark's target is the specified finite four-label distribution.

A signal call requires a feasible interval whose upper bound is strictly below one. A control call is a false declaration for its known target of one. Joint success requires a signal call, no control call, and a valid control interval containing one. Invalid or unbounded signal intervals cannot produce a call. Invalid intervals do not cover the target. Null and inconclusive results remain reportable.

Report both populations in both arms, all intervals and target coverage, joint outcomes, calibration/science gaps, raw outcomes, source hashes, and all physical resources. The four rows and sixteen blocks belong to one paired experiment; they do not give independent full-experiment repetitions. No empirical detection probability, false-positive rate, superiority p-value, or general resource advantage is inferred from one pair.

## Conditions for interpretation

Coverage assumes independent outcomes conditional on the response path and matching effective per-input response between each arm's calibration and its following science measurements in each block. Constant within-arm block counts preserve the required block-averaging weights. Sharing a physical job does not itself establish these assumptions.

Under the working model of a response fixed within each block, repacking independent observations preserves each arm's calibration/science count distribution and therefore the modeled inference distribution. This conditional statement does not prove unchanged physical power. Queue delays, changing within-job response, preparation history, cross-arm context, or correlations can violate the model. The earlier simulated powers retain their model qualifications and do not become empirical hardware rates.

There is one shared calibration-to-science timing gap per block. Execution metadata is used where available; job timestamps or client submission/retrieval windows are labeled fallbacks. Client windows include queuing. Long gaps are recorded and resuming does not restore response matching automatically. Incomplete collections are not scored.

## Runtime and cost handling

Hardware mode accepts only a verified Open Plan instance and pins the backend to its CRN. Defaults remain `ibm_marrakesh` and physical low/high bits 14 and 55. Device changes are recorded; no automatic backend or paid-instance fallback occurs. Job IDs, submission-intent tags, raw bitstrings, schedule/source hashes, and stage fingerprints are saved atomically and checked on resume. Deleted, cancelled, failed, or ambiguous submissions are not silently replaced. A complete collection can be analyzed without IBM access.

The API key is entered locally when necessary and is not saved by the collector. An instance hash locks resume to the same instance. IBM-provided metadata is retained for provenance. Demo data are explicitly synthetic, with zero actual hardware shots, jobs, or RUs.

An initial balance check compares the generic RU estimate plus a configurable planning reserve to available RUs. It is an advisory feasibility check, not a hard consumption cap, and is not repeated as a full-run check when retrieving/resuming existing activity. See `RU_ESTIMATE.md`. Each physical job's available RU metric is counted once, with completeness/pending status retained. Missing usage does not mean zero cost. Independent later hardware runs are needed to assess reproducibility and any general resource advantage.
