"""Analyze only measured outcomes of a completed fixed paired experiment."""

import argparse
import csv
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np

from experiment import ARMS, POPULATIONS, g2, validate_schedule
from intervals import assignment_box, corrected_interval, corrected_point
from runtime_io import atomic_json, validate_record


def stamp(value):
    if isinstance(value, dict):
        value = value.get("__value__")
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed.astimezone(timezone.utc)
    except ValueError:
        return None


def window(record):
    spans = [(stamp(r["start"]), stamp(r["stop"])) for r in record.get("execution_windows", [])]
    spans = [(a,b) for a,b in spans if a and b and a <= b]
    if spans:
        return min(a for a,b in spans), max(b for a,b in spans), "execution_window"
    times = record.get("job_metrics", {}).get("timestamps", {})
    a,b = stamp(times.get("running")), stamp(times.get("finished"))
    if a and b and a <= b:
        return a,b,"job_running_finished"
    a,b = stamp(record.get("client_submitted")), stamp(record.get("client_retrieved"))
    if a and b and a <= b:
        return a,b,"client_window_including_queue"
    raise ValueError("A stage has no usable timing window")


def finite(value):
    return float(value) if value is not None and np.isfinite(value) else None


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def analyze(folder):
    folder = Path(folder)
    config = json.loads((folder / "collection_manifest.json").read_text())
    schedule = json.loads((folder / "schedule.json").read_text())
    budgets = validate_schedule(schedule)
    if config["protocol_id"] != schedule["protocol_id"] or config["schedule_sha256"] != schedule["sha256"] or config["family_alpha"] != .05:
        raise ValueError("Protocol, schedule, or confidence rule differs from the frozen v2 design")
    for name in ("experiment.py", "logical_schedule.py", "intervals.py", "matrix_readout.py", "readout_intervals.py", "frozen_allocation.json"):
        if sha256((Path(__file__).parent / name).read_bytes()).hexdigest() != config["source_sha256"][name]:
            raise ValueError(f"Frozen inference source changed: {name}")
    hardware = config["provenance"] == "ibm_hardware"
    journal = json.loads((folder / "jobs.json").read_text())["stages"] if hardware else {}
    calibration = {a: np.zeros((4, 4), dtype=np.int64) for a in ARMS}
    science = {(a, p): np.zeros(4, dtype=np.int64) for a in ARMS for p in POPULATIONS}
    labels = {key: np.zeros(4, dtype=np.int64) for key in science}
    heldout = {a: np.zeros((4, 4), dtype=np.int64) for a in ARMS}
    costs = {a: {"acquired_shots": 0, "actual_device_shots": 0, "analyzed_shots": 0,
                 "shared_job_memberships": 0, "hardware_job_memberships": 0,
                 "ru_attribution": "Not apportioned: these jobs are shared by both arms."} for a in ARMS}
    per_block, hashes, ids, timing, job_costs = {}, {}, [], [], []
    for stage in schedule["stages"]:
        name = f"stages/stage_{stage['stage_index']:03d}.json"
        path = folder / name
        if not path.exists():
            raise RuntimeError("Collection is incomplete. Resume the same v2 command; partial collections are not scored.")
        record = json.loads(path.read_text())
        validate_record(record, stage, config["provenance"])
        if record.get("collector_source_sha256") != config["source_sha256"]:
            raise ValueError("Stage source provenance differs")
        if hardware:
            if journal.get(stage["stage_id"], {}).get("job_id") != record["job_id"]:
                raise ValueError("Job journal and saved record disagree")
            ids.append(record["job_id"])
        hashes[name] = sha256(path.read_bytes()).hexdigest()
        start, stop, kind = window(record)
        timing.append({"physical_stage": stage["stage_index"], "purpose": stage["purpose"], "block": stage["block_index"],
                       "arms": "both", "acquired_shots": stage["shots"], "pubs": len(stage["pubs"]),
                       "start_utc": start.isoformat(), "stop_utc": stop.isoformat(), "timing_kind": kind, "job_id": record["job_id"]})
        usage = record.get("job_metrics", {}).get("usage", {})
        ru = usage.get("value") if usage.get("unit") == "resource_units" and isinstance(usage.get("value"), (float, int)) else None
        seconds = usage.get("qpu_charge_time_seconds")
        if not isinstance(seconds, (int, float)):
            seconds = None
        job_costs.append({"physical_stage": stage["stage_index"], "block": stage["block_index"], "purpose": stage["purpose"],
                          "job_id": record["job_id"], "shared_by": "both_arms", "acquired_shots": stage["shots"],
                          "actual_device_shots": stage["shots"] if hardware else 0,
                          "available_resource_units": ru, "ru_status": usage.get("status", "unavailable"),
                          "available_qpu_charge_seconds": seconds})
        for arm in ARMS:
            costs[arm]["shared_job_memberships"] += 1
            costs[arm]["hardware_job_memberships"] += int(hardware)
        for pub, sample in zip(stage["pubs"], record["samples"], strict=True):
            arm = pub["arm"]
            kept = pub["analysis_shots"]
            retained = np.bincount([int(s, 2) for s in sample["ordered_bitstrings"][:kept]], minlength=4)
            costs[arm]["acquired_shots"] += pub["shots"]
            costs[arm]["actual_device_shots"] += pub["shots"] if hardware else 0
            costs[arm]["analyzed_shots"] += kept
            if pub["role"] == "calibration":
                calibration[arm][:, pub["prepared_state"]] += retained
            elif pub["role"] == "science":
                key = arm, pub["population"]
                science[key] += retained
                labels[key][pub["prepared_state"]] += kept
                heldout[arm][:, pub["prepared_state"]] += retained
                block_key = arm, stage["block_index"], pub["population"]
                per_block.setdefault(block_key, np.zeros(4, dtype=np.int64))
                per_block[block_key] += retained
    if hardware and len(set(ids)) != schedule["total_jobs"]:
        raise ValueError("Every physical stage must have one distinct hardware job ID")
    ordered = all(stamp(timing[i]["start_utc"]) >= stamp(timing[i - 1]["stop_utc"]) for i in range(1, len(timing)))
    if not ordered:
        raise ValueError("Physical timing contradicts sequential calibration-before-science collection")
    for arm in ARMS:
        if calibration[arm].sum(axis=0).tolist() != budgets[arm]["calibration_by_state"]:
            raise ValueError("An arm's per-state calibration data differ from its preserved allocation")
        if costs[arm]["acquired_shots"] != budgets[arm]["acquired_shots"] or costs[arm]["analyzed_shots"] != budgets[arm]["analyzed_shots"]:
            raise ValueError("An arm's acquired or analyzed accounting differs")
        for pop in POPULATIONS:
            if int(science[arm, pop].sum()) != budgets[arm][pop]:
                raise ValueError("An arm/population science total differs")
    available_ru = [r["available_resource_units"] for r in job_costs if r["available_resource_units"] is not None]
    available_seconds = [r["available_qpu_charge_seconds"] for r in job_costs if r["available_qpu_charge_seconds"] is not None]
    physical_cost_totals = {"recorded_physical_stages": len(job_costs), "actual_hardware_jobs": len(ids),
                            "acquired_shots": sum(r["acquired_shots"] for r in job_costs),
                            "actual_device_shots": sum(r["actual_device_shots"] for r in job_costs),
                            "available_resource_units": sum(available_ru) if available_ru else None,
                            "jobs_with_ru_metric": len(available_ru),
                            "jobs_ru_pending": sum(r["ru_status"] == "pending" for r in job_costs),
                            "jobs_ru_complete": sum(r["ru_status"] == "complete" for r in job_costs),
                            "available_qpu_charge_seconds": sum(available_seconds) if available_seconds else None,
                            "jobs_with_charge_metric": len(available_seconds),
                            "accounting": "Each physical job and its usage appears once. Arm job memberships overlap and are not additive."}

    results = []
    for arm in ARMS:
        for pop in POPULATIONS:
            target = schedule["targets"][pop]
            h = science[arm, pop]
            low, high, status = corrected_interval(calibration[arm], h, .05)
            point = corrected_point(calibration[arm], h)
            estimate = point["g2"]
            results.append({"arm": arm, "population": pop, "target_g2": target["target_g2"],
                            "target_mean": target["target_mean"], "science_shots": int(h.sum()),
                            "shared_arm_calibration_shots": int(calibration[arm].sum()),
                            "total_arm_acquired_shots": costs[arm]["acquired_shots"],
                            "raw_g2": finite(g2(h / h.sum())), "corrected_g2": estimate,
                            "absolute_error": finite(abs(estimate - target["target_g2"])) if estimate is not None else None,
                            "interval_lower": finite(low), "interval_upper": finite(high), "interval_status": status,
                            "upper_is_unbounded": int(not np.isfinite(high)),
                            "number_label_antibunching_call": int(status == "ok" and high < 1),
                            "target_covered": int(status == "ok" and low <= target["target_g2"] <= high),
                            "point_estimate_status": point["status"],
                            "realized_source_labels_g2": finite(g2(labels[arm, pop] / labels[arm, pop].sum()))})
    arm_results = []
    for arm in ARMS:
        sig = next(r for r in results if r["arm"] == arm and r["population"] == "signal")
        con = next(r for r in results if r["arm"] == arm and r["population"] == "control")
        arm_results.append({"arm": arm, "signal_call": sig["number_label_antibunching_call"],
                            "control_false_call": con["number_label_antibunching_call"],
                            "control_target_covered": con["target_covered"],
                            "joint_success_this_pilot": int(sig["number_label_antibunching_call"] and not con["number_label_antibunching_call"] and con["target_covered"]),
                            "signal_absolute_error": sig["absolute_error"], "control_absolute_error": con["absolute_error"]})
    gaps = []
    for block in range(schedule["blocks"]):
        cal = next(t for t in timing if t["block"] == block and t["purpose"] == "calibration")
        sci = next(t for t in timing if t["block"] == block and t["purpose"] == "science")
        gaps.append({"block": block, "applies_to": "both_arms", "calibration_job_id": cal["job_id"], "science_job_id": sci["job_id"],
                     "calibration_stop_utc": cal["stop_utc"], "science_start_utc": sci["start_utc"],
                     "gap_seconds": (stamp(sci["start_utc"]) - stamp(cal["stop_utc"])).total_seconds(),
                     "calibration_timing_kind": cal["timing_kind"], "science_timing_kind": sci["timing_kind"]})
    cal_rows = []
    for arm in ARMS:
        lo, hi = assignment_box(calibration[arm], .05 / 4)
        for state in range(4):
            n, nh = int(calibration[arm][:, state].sum()), int(heldout[arm][:, state].sum())
            for outcome in range(4):
                cal_rows.append({"arm": arm, "prepared_state": f"{state:02b}", "observed_state": f"{outcome:02b}",
                                 "calibration_count": int(calibration[arm][outcome, state]), "calibration_shots": n,
                                 "assignment_estimate": float(calibration[arm][outcome, state] / n),
                                 "assignment_lower": float(lo[outcome, state]), "assignment_upper": float(hi[outcome, state]),
                                 "heldout_science_count": int(heldout[arm][outcome, state]), "heldout_science_shots": nh,
                                 "heldout_science_assignment": float(heldout[arm][outcome, state] / nh) if nh else None})
    block_rows = [{"arm": a, "block": b, "population": p, "shots": int(h.sum()),
                   **{f"observed_{j:02b}": int(h[j]) for j in range(4)}, "raw_g2": finite(g2(h / h.sum()))}
                  for (a, b, p), h in sorted(per_block.items())]
    for name, rows in [("readout_results.csv", results), ("arm_outcomes.csv", arm_results), ("stage_timing.csv", timing),
                       ("arm_costs.csv", [{"arm": a, **costs[a]} for a in ARMS]), ("physical_job_costs.csv", job_costs),
                       ("calibration_to_science_gaps.csv", gaps), ("calibration_and_heldout.csv", cal_rows), ("science_blocks.csv", block_rows)]:
        write_csv(folder / name, rows)
    summary = {"schema_version": 2, "protocol_id": config["protocol_id"], "provenance": config["provenance"],
               "purpose": config["purpose"], "backend": config["backend"], "physical_qubits": config["physical_qubits"],
               "planning_device_match": config["planning_device_match"], "actual_device_shots": physical_cost_totals["actual_device_shots"],
               "actual_hardware_jobs": len(ids), "recorded_physical_stages": len(job_costs), "recorded_shots": schedule["total_shots"],
               "analyzed_shots": schedule["total_analysis_shots"], "predeclared_discarded_shots": schedule["total_shots"] - schedule["total_analysis_shots"],
               "family_alpha": .05, "schedule_sha256": schedule["sha256"], "frozen_profile_sha256": schedule["frozen_profile_sha256"],
               "logical_schedule_sha256": schedule["logical_schedule_sha256"], "logical_source_schedule_preserved": True,
               "arm_budgets": budgets, "arm_shared_cost_accounting": costs, "physical_cost_totals": physical_cost_totals,
               "results": results, "arm_outcomes": arm_results, "stages_time_ordered": ordered, "calibration_to_science_gaps": gaps,
               "calibration_counts": {a: calibration[a].tolist() for a in ARMS},
               "science_counts": {a: {p: science[a, p].tolist() for p in POPULATIONS} for a in ARMS},
               "realized_source_label_counts": {a: {p: labels[a, p].tolist() for p in POPULATIONS} for a in ARMS},
               "record_sha256": hashes,
               "analysis_source_sha256": {n: sha256((Path(__file__).parent / n).read_bytes()).hexdigest() for n in
                                          ("analyze_allocation_validation.py", "experiment.py", "logical_schedule.py", "intervals.py", "matrix_readout.py", "readout_intervals.py")},
               "interpretation": "One new paired allocation pilot with shared physical jobs. Arm outcomes are distinct; shared job memberships and costs are not independent repetitions or additive jobs.",
               "confidence_assumptions": ["Independent outcomes conditional on the response path.", "Each arm's calibration and science response match within a block despite grouping and preparation history.", "Per-input calibration counts and each population's science counts remain constant across blocks.", "Within-job physical arm or shot ordering is not asserted."],
               "scope": "Number-label SPAM benchmark; no physical cavity dynamics, empirical hardware power/FPR rate, or general resource advantage is established."}
    atomic_json(folder / "analysis_manifest.json", summary)
    table = []
    for r in results:
        high = f"{r['interval_upper']:.4f}" if r["interval_upper"] is not None else "unbounded"
        point = f"{r['corrected_g2']:.4f}" if r["corrected_g2"] is not None else "undefined"
        table.append(f"| {r['arm']} | {r['population']} | {r['target_g2']:.4f} | {point} | [{r['interval_lower']:.4f}, {high}] | {r['number_label_antibunching_call']} | {r['target_covered']} |")
    mode_note = "Actual hardware records." if hardware else "**Synthetic local demo: zero actual hardware shots, jobs, and RUs.**"
    report = f"""# Batched allocation comparison, protocol v2

{mode_note} {'Small workflow smoke; inconclusive intervals are expected.' if schedule['smoke'] else 'One paired hardware pilot; retain null and inconclusive outcomes.'}

Recorded shots: {schedule['total_shots']:,}; analyzed: {schedule['total_analysis_shots']:,}; predeclared extra outcomes excluded: {summary['predeclared_discarded_shots']:,}. Actual device shots: {summary['actual_device_shots']:,}; actual hardware jobs: {summary['actual_hardware_jobs']}. Backend `{config['backend']}`, physical qubits {config['physical_qubits']}; planning-device match {config['planning_device_match']}.

Each block uses one physical job containing distinct calibration PUBs for both arms, then one physical job containing distinct science PUBs for both arms. Both logical source schedules, per-input/per-population shot counts, 64-shot PUBs, and value-independent retention counts are preserved from the original allocation protocol. Requested PUBs are mixed by a predeclared permutation. There is no claim about physical per-shot arm order, and the former arm-first/arm-second timing policy no longer applies.

| Arm | Population | Known g2 | Corrected g2 | Nominal simultaneous interval | Upper below one | Target covered |
| --- | --- | ---: | ---: | --- | ---: | ---: |
{chr(10).join(table)}

The primary correction and nominal family alpha=0.05 are unchanged: two calibration matrices receive alpha/4 each, four science histograms alpha/8 each. Each arm's actual unequal sample sizes enter the existing KL/Chernoff boxes and full-matrix LP bounds. Primary fitting uses measured calibration and marginal science counts only; known source labels are reserved for diagnostics. The joint outcome requires a signal call and a valid control interval containing one. These four rows and sixteen blocks are not independent full-experiment repetitions, and no hardware success percentage, superiority p-value, or general resource advantage is inferred from one pair.

Shared jobs are counted **once** in `physical_job_costs.csv` and `physical_cost_totals`. Each arm participates in the same {schedule['total_jobs']} physical jobs; its memberships overlap the other arm's and must not be summed. Per-arm acquired counts are separately validated, but physical RU charges are not apportioned between arms. Available RU totals may be partial or provisional; missing metrics mean unavailable, not zero.

There is one shared calibration-to-science gap per block, ranging from {min(g['gap_seconds'] for g in gaps):.3f} to {max(g['gap_seconds'] for g in gaps):.3f} seconds. Client-window fallbacks include queuing and are not physical execution windows. Combining jobs preserves the nominal inference argument only when conditional outcome independence and the relevant calibration/science response-matching assumptions hold for each arm. Grouping may change real preparation history, within-job response, or timing; this is a documented execution-protocol amendment made before acquisition, not proof that actual hardware power is unchanged.

For a response fixed within each modeled block, regrouping independent observations into shared jobs leaves each arm's calibration/science count distribution unchanged. That conditional fact does not transfer the prior simulation powers to unmodeled physical history effects. All original model-based power qualifications remain. This is an X-only nominal-number-label SPAM benchmark, not cavity-Hamiltonian evolution or a direct physical photon-blockade demonstration.
"""
    (folder / "report.md").write_text(report, encoding="utf-8")
    suffix = "Smoke" if schedule["smoke"] else "Results"
    archive = folder / f"Photon_Blockade_Allocation_Validation_Batched_{'' if hardware else 'Demo_'}{suffix}.zip"
    names = ["collection_manifest.json", "schedule.json", "readout_results.csv", "arm_outcomes.csv", "stage_timing.csv", "arm_costs.csv",
             "physical_job_costs.csv", "calibration_to_science_gaps.csv", "calibration_and_heldout.csv", "science_blocks.csv", "analysis_manifest.json", "report.md"]
    if hardware:
        names.append("jobs.json")
    atomic_json(folder / "result_sha256.json", {n: sha256((folder / n).read_bytes()).hexdigest() for n in names + list(hashes)})
    temporary = archive.with_suffix(".part")
    with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as z:
        for name in names + list(hashes) + ["result_sha256.json"]:
            z.write(folder / name, name)
    temporary.replace(archive)
    return archive


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    args = parser.parse_args()
    print(analyze(args.folder).resolve())
