"""Confidence bounds for averages of independent, possibly unequal Bernoulli probabilities."""

import numpy as np
from scipy.optimize import brentq
from scipy.special import rel_entr
from matrix_readout import full_matrix_interval
from experiment import g2


def bernoulli_kl(q, p):
    return float(rel_entr(q, p)+rel_entr(1-q, 1-p))


def kl_box(shots, counts, alpha):
    counts = np.asarray(counts, dtype=float)
    sizes = np.broadcast_to(np.asarray(shots, dtype=float), counts.shape)
    if not 0 < alpha < 1 or np.any(counts < 0) or np.any(counts > sizes) or np.any(sizes < 0):
        raise ValueError("Invalid confidence-bound counts, shot sizes, or alpha")
    low, high = np.zeros_like(counts), np.ones_like(counts)
    log_threshold = np.log(2*counts.size/alpha)
    for index in np.ndindex(counts.shape):
        n, x = sizes[index], counts[index]
        if not n:
            continue
        q = x/n
        function = lambda p: n*bernoulli_kl(q, p)-log_threshold
        if x:
            low[index] = brentq(function, 0., q, xtol=5e-16, rtol=1e-12)
        if x < n:
            high[index] = brentq(function, q, 1., xtol=5e-16, rtol=1e-12)
    return low, high


def assignment_box(calibration, alpha):
    histogram = np.asarray(calibration)
    sizes = np.tile(histogram.sum(axis=0), 4)
    low, high = kl_box(sizes, histogram.ravel(), alpha)
    return low.reshape(4, 4), high.reshape(4, 4)


def measured_tail_box(histogram, alpha):
    histogram = np.asarray(histogram)
    tails = np.cumsum(histogram[:0:-1])[::-1]
    return kl_box(histogram.sum(), tails, alpha)


def corrected_interval(calibration, science, family_alpha=.05):
    # Two calibration matrices share alpha/2; four science histograms share alpha/2.
    return full_matrix_interval(assignment_box(calibration, family_alpha/4),
        measured_tail_box(science, family_alpha/8))


def corrected_point(calibration, science):
    """Simplex-constrained least squares, independent of the known input targets.

    Enumerating all 15 nonempty faces avoids iterative boundary failures for
    the rare/zero populations that matter to factorial moments.
    """
    calibration, science = np.asarray(calibration), np.asarray(science)
    sizes = calibration.sum(axis=0)
    if np.any(sizes <= 0) or science.sum() <= 0:
        return {"status": "missing_counts", "probabilities": None, "g2": None}
    matrix = calibration/sizes
    measured = science/science.sum()
    condition=float(np.linalg.cond(matrix))
    if not np.isfinite(condition) or condition > 1e12:
        return {"status":"non_identifiable_assignment","probabilities":None,"g2":None}
    best_loss,best_probabilities=np.inf,None
    for mask in range(1,16):
        support=[i for i in range(4) if (mask>>i)&1]
        design=matrix[:,support]
        size=len(support)
        kkt=np.zeros((size+1,size+1))
        kkt[:size,:size]=design.T@design
        kkt[:size,size]=1.; kkt[size,:size]=1.
        rhs=np.r_[design.T@measured,1.]
        fitted=np.linalg.lstsq(kkt,rhs,rcond=None)[0][:size]
        if np.any(fitted < -1e-10):
            continue
        candidate=np.zeros(4); candidate[support]=np.maximum(fitted,0.)
        candidate/=candidate.sum()
        loss=float(np.sum((matrix@candidate-measured)**2))
        if loss < best_loss:
            best_loss,best_probabilities=loss,candidate
    if best_probabilities is None:
        return {"status":"numerical_issue","probabilities":None,"g2":None}
    probabilities=best_probabilities
    value = g2(probabilities)
    return {"status": "ok", "probabilities": probabilities.tolist(),
        "g2": value if np.isfinite(value) else None, "assignment_condition_number": condition,
        "method":"simplex_constrained_least_squares"}
