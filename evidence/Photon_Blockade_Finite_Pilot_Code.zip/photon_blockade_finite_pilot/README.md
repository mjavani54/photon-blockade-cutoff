# Planning from finite pilot measurements

This two-stage simulation chooses calibration and science budgets using a pilot run. The pilot estimates the four bit-assignment rates from prepared states `00` and `11` and the observed photon-label frequencies from the signal. All pilot shots count toward the total cost.

## Run on macOS or Linux

Open Terminal in this directory and use Python 3.10 or newer.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_finite_pilot.py --workers 4
```

Upload `photon_blockade_finite_pilot_results/Photon_Blockade_Finite_Pilot_Results.zip`. The default run uses 64 independent pilots per size and condition. Use `--workers 2` to reduce CPU usage or `--trials N` to change the number of independent pilots. Measurements are simulated by binomial and multinomial counts, so large shot budgets do not generate arrays of individual shots.

The optional `python run_finite_pilot.py --smoke` runs the original operating point at 2 percent error with four pilot repetitions per size. It writes a separate smoke archive.

## Frozen settings

The run uses the four photon distributions, their matched empty-cavity controls, and the six readout channels from the completed allocation study. These models generate simulated counts and provide the reference values for validation. The planner receives only the observed pilot histograms and the predefined thresholds.

| Pilot size | `00` calibration | `11` calibration | Signal science | Total |
| --- | ---: | ---: | ---: | ---: |
| Small | 20,000 | 5,000 | 50,000 | 75,000 |
| Medium | 100,000 | 20,000 | 250,000 | 370,000 |
| Large | 2,000,000 | 200,000 | 5,000,000 | 7,200,000 |

## Two planning methods

- **Plug-in.** Forecast the main counts from the pilot frequencies with a half-count added to each category. Use the same main-stage confidence procedure as the allocation run.
- **Robust.** Build a simultaneous 95 percent pilot confidence box for the four assignment rates and three photon-tail probabilities. Forecast the extreme main-stage count bounds over that box. A pilot box containing the true probabilities makes the main forecast valid with at least 95 percent probability for the chosen fixed budget.

Both methods minimize $K_{00}+K_{11}+N_{\rm sci}$ separately for detection and precision. They each search an equal-calibration policy and a policy with separate calibration budgets. The search uses 13 calibration sizes from the original grid at each basis state and all 51 original science sizes. The truth-informed comparison uses exactly that reduced grid. The result archive also includes the previous 49-size oracle for context.

The detection criterion requires the forecast upper bound plus the fixed 0.025 photon-cutoff allowance to fall below 1. The precision criterion requires forecast width at most 0.15. The confidence split and binomial interval construction match the original allocation run.

## Validation

For each pilot and each selected budget, draw independent main-stage calibration and science counts. The signal and mean-matched control use the same main-stage calibration draw and the same science shot count. Each pilot trial is paired across planner policies, and policies choosing the same budget share that trial's main counts. The control uses the plan selected for the signal.

The main confidence intervals have pointwise 95 percent coverage for the finite-cutoff correlation under the simulated assignment model. The additional cutoff allowance applies to the four verified signal and control pairs. Pilot data choose the budget, and the main confidence intervals use fresh counts. A detected signal has an adjusted upper limit below 1. A successful precision trial meets the width target, covers the reference after adding the cutoff allowance, and has a midpoint within 0.10 of the reference.

A pilot with no feasible plan incurs the pilot cost and contributes a zero to the end-to-end success rate. The reported shot totals count the pilot and main measurements for the signal, including both calibration states. The matched-control measurements are a separate validation experiment.

## Result archive

| File | Contents |
| --- | --- |
| `manifest.json` | Models, grids, pilot sizes, confidence settings, and hashes |
| `pilot_counts.csv` | Four calibration error counts and the photon-label histogram for each pilot |
| `trials.csv` | Chosen budgets, total spent, decision and precision outcomes, and controls |
| `summary.csv` | Plan rates, end-to-end and conditional success, false calls, and shot costs |
| `oracle.csv` | Truth-informed equal and separate allocations on the same reduced grid |
| `previous_full_grid_oracle.csv` | Separate allocations from the prior full grid |
