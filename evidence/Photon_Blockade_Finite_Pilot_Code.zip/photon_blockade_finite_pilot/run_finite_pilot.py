"""Plan photon-blockade measurement budgets using finite pilot counts."""

import argparse
from concurrent.futures import ProcessPoolExecutor
import csv
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import platform
from statistics import median
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
import scipy
from scipy.stats import binom

from readout_intervals import binomial_box, g2_interval, observed_distribution, photon_tails
from sampling import ALPHA, BETA, SHOT_GRID, SHOT_TOLERANCE


HERE = Path(__file__).resolve().parent
INPUT_PATH = HERE / "finite_pilot_inputs.json"
CUTOFF_ALLOWANCE = 0.025
PILOT_ALPHA = 0.05
MEASUREMENT_ALPHA = ALPHA / 2
COUNT_TAIL = BETA / 14
SEED = 720266
RATE_STATE_INDEX = np.array([0, 1, 0, 1])
PILOT_BUDGETS = (
    ("small", 20_000, 5_000, 50_000),
    ("medium", 100_000, 20_000, 250_000),
    ("large", 2_000_000, 200_000, 5_000_000),
)


def count_tails(histogram):
    return np.cumsum(histogram[:0:-1])[::-1]


def prospective_box(shots, probability_box):
    """Enclose main-stage intervals over the assumed probability ranges."""
    size = np.asarray(shots)[..., None]
    low, high = probability_box
    low_counts = binom.ppf(COUNT_TAIL, size, low)
    high_counts = binom.ppf(1 - COUNT_TAIL, size, high)
    return binomial_box(size, low_counts, high_counts, MEASUREMENT_ALPHA)


def pilot_probability_boxes(rate_counts, photon_counts, shots_00, shots_11):
    """Create point and interval forecasts from the same pilot observations."""
    calibration_sizes = np.array([shots_00, shots_11])[RATE_STATE_INDEX]
    science_size = int(photon_counts.sum())
    rates = (rate_counts + 0.5) / (calibration_sizes + 1)
    tails = photon_tails((photon_counts + 0.5) / (science_size + 2))
    tail_counts = count_tails(photon_counts)
    return {
        "plugin": ((rates, rates), (tails, tails)),
        "robust": (
            binomial_box(calibration_sizes, rate_counts, rate_counts, PILOT_ALPHA / 2),
            binomial_box(science_size, tail_counts, tail_counts, PILOT_ALPHA / 2),
        ),
    }


def allocation_grid(calibration_sizes):
    indices = np.indices((len(calibration_sizes), len(calibration_sizes))).reshape(2, -1).T
    return calibration_sizes[indices], indices[:, RATE_STATE_INDEX]


def choose_allocations(rate_box, tail_box, calibration_sizes, pairs, rate_indices):
    """Return the least total cost on the grid under each calibration policy."""
    cal_low, cal_high = prospective_box(calibration_sizes, rate_box)
    columns = np.arange(4)
    all_rate_boxes = (
        cal_low[rate_indices, columns][:, None, :],
        cal_high[rate_indices, columns][:, None, :],
    )
    lower, upper = g2_interval(prospective_box(SHOT_GRID, tail_box), all_rate_boxes)
    adjusted_upper = upper + CUTOFF_ALLOWANCE
    width = upper - lower
    criteria = {
        "decision": adjusted_upper < 1,
        "precision": width <= 2 * SHOT_TOLERANCE,
    }
    choices = {}
    equal = pairs[:, 0] == pairs[:, 1]
    for goal, passes in criteria.items():
        feasible = passes.any(axis=1)
        first = passes.argmax(axis=1)
        science = SHOT_GRID[first]
        for policy, allowed in (("equal", feasible & equal), ("separate", feasible)):
            candidates = np.flatnonzero(allowed)
            if not len(candidates):
                choices[policy, goal] = None
                continue
            total = pairs[candidates].sum(axis=1) + science[candidates]
            order = np.lexsort((pairs[candidates, 0], science[candidates], total))
            selected = candidates[order[0]]
            budgets = tuple(map(int, (*pairs[selected], science[selected])))
            choices[policy, goal] = {
                "budget": budgets,
                "forecast_adjusted_upper": number(adjusted_upper[selected, first[selected]]),
                "forecast_width": number(width[selected, first[selected]]),
            }
    return choices


def number(value):
    return float(value) if math.isfinite(value) else None


def confidence_interval(shot_count, counts, rate_box):
    tails = count_tails(counts)
    return g2_interval(binomial_box(shot_count, tails, tails, MEASUREMENT_ALPHA), rate_box)


def validate_budget(budget, model_probabilities, true_rates, reference_g2, indices):
    """Evaluate a fixed budget on new calibration, signal, and control data."""
    k0, k1, science = budget
    sizes = np.array([k0, k1])[RATE_STATE_INDEX]
    calibration_rng = np.random.default_rng(np.random.SeedSequence([SEED, *indices, 1, k0, k1]))
    counts = calibration_rng.binomial(sizes, true_rates)
    rate_box = binomial_box(sizes, counts, counts, MEASUREMENT_ALPHA)
    intervals = []
    for model_index, probabilities in enumerate(model_probabilities):
        rng = np.random.default_rng(np.random.SeedSequence([SEED, *indices, 2, model_index, science]))
        intervals.append(confidence_interval(science, rng.multinomial(science, probabilities), rate_box))
    low, high = intervals[0]
    midpoint = low + (high - low) / 2
    covered = low - CUTOFF_ALLOWANCE <= reference_g2 <= high + CUTOFF_ALLOWANCE
    narrow = high - low <= 2 * SHOT_TOLERANCE
    accurate = abs(midpoint - reference_g2) <= CUTOFF_ALLOWANCE + SHOT_TOLERANCE
    return {
        "signal_call": int(high + CUTOFF_ALLOWANCE < 1),
        "control_false_call": int(intervals[1][1] + CUTOFF_ALLOWANCE < 1),
        "reference_covered": int(covered),
        "width_met": int(narrow),
        "absolute_error_met": int(accurate),
        "precision_success": int(covered and narrow and accurate),
        "signal_interval_lower": number(low),
        "signal_adjusted_upper": number(high + CUTOFF_ALLOWANCE),
        "control_adjusted_upper": number(intervals[1][1] + CUTOFF_ALLOWANCE),
    }


def contains(box, truth):
    return bool(np.all((box[0] <= truth) & (truth <= box[1])))


def run_condition(task):
    case_index, scenario_index, models, scenario, calibration_sizes, trial_count, seed_mode = task
    target, control = models
    true_rates = np.asarray(scenario["rates"], dtype=float)
    probabilities = tuple(
        observed_distribution(np.asarray(model["probabilities"]), true_rates) for model in models
    )
    true_tails = photon_tails(probabilities[0])
    pairs, rate_indices = allocation_grid(calibration_sizes)
    context = {"case_id": target["case_id"], "scenario": scenario["name"]}
    oracle = choose_allocations((true_rates, true_rates), (true_tails, true_tails), calibration_sizes, pairs, rate_indices)
    oracle_rows = []
    pilot_rows = []
    trial_rows = []
    for (policy, goal), plan in oracle.items():
        budget = plan["budget"] if plan else (None, None, None)
        oracle_rows.append({
            **context, "policy": policy, "goal": goal, "shots_00": budget[0],
            "shots_11": budget[1], "science_shots": budget[2], "total_shots": sum(budget) if plan else None,
        })
    for pilot_index, (pilot, k0, k1, science) in enumerate(PILOT_BUDGETS):
        sizes = np.array([k0, k1])[RATE_STATE_INDEX]
        pilot_total = k0 + k1 + science
        for trial in range(trial_count):
            indices = (seed_mode, case_index, scenario_index, pilot_index, trial)
            rng = np.random.default_rng(np.random.SeedSequence([SEED, *indices, 0]))
            error_counts = rng.binomial(sizes, true_rates)
            science_counts = rng.multinomial(science, probabilities[0])
            forecasts = pilot_probability_boxes(error_counts, science_counts, k0, k1)
            case_trial = {**context, "pilot": pilot, "trial": trial}
            robust_rates, robust_tails = forecasts["robust"]
            pilot_rows.append({
                **case_trial, "pilot_00": k0, "pilot_11": k1, "pilot_science": science,
                **{name: int(count) for name, count in zip(
                    ("lsb_0_to_1", "lsb_1_to_0", "msb_0_to_1", "msb_1_to_0"), error_counts, strict=True
                )},
                **{f"count_{i}": int(count) for i, count in enumerate(science_counts)},
                "joint_box_contains_truth": int(contains(robust_rates, true_rates) and contains(robust_tails, true_tails)),
            })
            validations = {}
            for method, (rate_box, tail_box) in forecasts.items():
                choices = choose_allocations(rate_box, tail_box, calibration_sizes, pairs, rate_indices)
                for (policy, goal), plan in choices.items():
                    row = {
                        **case_trial, "method": method, "policy": policy, "goal": goal,
                        "plan_found": int(plan is not None), "pilot_total": pilot_total,
                        "shots_00": None, "shots_11": None, "science_shots": None,
                        "total_spent": pilot_total, "forecast_adjusted_upper": None, "forecast_width": None,
                        "signal_call": None, "control_false_call": None, "reference_covered": None,
                        "width_met": None, "absolute_error_met": None, "precision_success": None,
                        "signal_interval_lower": None, "signal_adjusted_upper": None, "control_adjusted_upper": None,
                        "goal_met": 0,
                    }
                    if plan is not None:
                        budget = plan["budget"]
                        if budget not in validations:
                            validations[budget] = validate_budget(budget, probabilities, true_rates, target["reference_g2"], indices)
                        result = validations[budget]
                        row.update(
                            shots_00=budget[0], shots_11=budget[1], science_shots=budget[2],
                            total_spent=pilot_total + sum(budget),
                            forecast_adjusted_upper=plan["forecast_adjusted_upper"],
                            forecast_width=plan["forecast_width"], **result,
                            goal_met=result["signal_call"] if goal == "decision" else result["precision_success"],
                        )
                    trial_rows.append(row)
    print(f"{target['case_id']} at {scenario['name']}", flush=True)
    return oracle_rows, pilot_rows, trial_rows


def summarize(trials, oracle):
    group_columns = ("case_id", "scenario", "pilot", "method", "policy", "goal")
    by_group = {}
    by_oracle = {(r["case_id"], r["scenario"], r["policy"], r["goal"]): r["total_shots"] for r in oracle}
    for row in trials:
        key = tuple(row[k] for k in group_columns)
        by_group.setdefault(key, []).append(row)
    summary = []
    for key, rows in by_group.items():
        case_id, scenario, _, _, policy, goal = key
        planned = [r for r in rows if r["plan_found"]]
        successful = [r for r in planned if r["goal_met"]]
        successful_cost = median(r["total_spent"] for r in successful) if successful else None
        oracle_total = by_oracle[case_id, scenario, policy, goal]
        summary.append({
            **dict(zip(group_columns, key, strict=True)), "trials": len(rows),
            "plans": len(planned), "goal_successes": len(successful),
            "goal_success_rate_all_pilots": len(successful) / len(rows),
            "goal_success_rate_given_plan": len(successful) / len(planned) if planned else None,
            "control_false_calls": sum(r["control_false_call"] for r in planned),
            "signal_reference_covered": sum(r["reference_covered"] for r in planned),
            "mean_spent_all_pilots": sum(r["total_spent"] for r in rows) / len(rows),
            "median_total_given_plan": median(r["total_spent"] for r in planned) if planned else None,
            "median_total_given_success": successful_cost, "same_grid_oracle_total": oracle_total,
            "median_successful_cost_to_oracle": successful_cost / oracle_total if successful_cost and oracle_total else None,
        })
    return summary


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def validate_inputs(inputs):
    if inputs["cutoff"] != 3 or inputs["science_grid"] != SHOT_GRID.tolist():
        raise ValueError("The frozen four-level photon model or science grid differs")
    for pair in inputs["models"]:
        for model in pair:
            p = np.asarray(model["probabilities"])
            if (
                p.shape != (4,) or np.any(p < 0) or abs(p.sum() - 1) > 1e-12
                or abs(model["reference_g2"] - model["finite_g2"]) > CUTOFF_ALLOWANCE
                or model["shot_tolerance"] != SHOT_TOLERANCE
            ):
                raise ValueError(f"Invalid frozen model for {model['case_id']}")
    for scenario in inputs["scenarios"]:
        rates = np.asarray(scenario["rates"])
        if rates.shape != (4,) or np.any(rates < 0) or np.any(rates.reshape(2, 2).sum(axis=1) >= 1):
            raise ValueError(f"Invalid assignment rates for {scenario['name']}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=min(4, os.cpu_count() or 1), help="CPU workers")
    parser.add_argument("--trials", type=int, help="Independent pilots per size and condition")
    parser.add_argument("--smoke", action="store_true", help="Check the original operating point at 2 percent error")
    parser.add_argument("--out", type=Path, help="Directory for the result archive")
    args = parser.parse_args()
    trials = (4 if args.smoke else 64) if args.trials is None else args.trials
    if trials < 1 or args.workers < 1:
        parser.error("trials and workers must be positive")
    inputs = json.loads(INPUT_PATH.read_text(encoding="utf-8"))
    validate_inputs(inputs)
    calibration_sizes = np.asarray(inputs["previous_calibration_grid"][::4], dtype=int)
    models = inputs["models"][:1] if args.smoke else inputs["models"]
    scenarios = [s for s in inputs["scenarios"] if s["name"] == "symmetric_0.02"] if args.smoke else inputs["scenarios"]
    tasks = [(i, j, pair, scenario, calibration_sizes, trials, int(args.smoke))
             for i, pair in enumerate(models) for j, scenario in enumerate(scenarios)]
    oracle_rows, pilot_rows, trial_rows = [], [], []
    with ProcessPoolExecutor(max_workers=min(args.workers, len(tasks))) as workers:
        for oracle, pilots, validation in workers.map(run_condition, tasks):
            oracle_rows.extend(oracle)
            pilot_rows.extend(pilots)
            trial_rows.extend(validation)

    folder = args.out or Path("photon_blockade_finite_pilot_smoke" if args.smoke else "photon_blockade_finite_pilot_results")
    folder.mkdir(parents=True, exist_ok=True)
    tables = {
        "oracle": oracle_rows, "pilot_counts": pilot_rows,
        "trials": trial_rows, "summary": summarize(trial_rows, oracle_rows),
    }
    for name, rows in tables.items():
        write_csv(folder / f"{name}.csv", rows)
    prior_oracle = [r for r in inputs["full_grid_oracle"]
                    if any(r["case_id"] == p[0]["case_id"] for p in models)
                    and any(r["scenario"] == s["name"] for s in scenarios)]
    write_csv(folder / "previous_full_grid_oracle.csv", prior_oracle)
    metadata = {
        "mode": "smoke" if args.smoke else "full", "trials_per_pilot_size_and_condition": trials,
        "seed": SEED, "cutoff": inputs["cutoff"], "models": models, "scenarios": scenarios,
        "cutoff_allowance": CUTOFF_ALLOWANCE, "shot_tolerance": SHOT_TOLERANCE,
        "main_confidence": 1 - ALPHA, "pilot_box_confidence": 1 - PILOT_ALPHA,
        "prospective_count_probability": 1 - BETA,
        "allocation_archive_sha256": inputs["allocation_archive_sha256"],
        "calibration_grid_per_state": calibration_sizes.tolist(), "science_grid": SHOT_GRID.tolist(),
        "pilot_sizes": [
            {"name": name, "shots_00": k0, "shots_11": k1, "science_shots": n} for name, k0, k1, n in PILOT_BUDGETS
        ],
        "runtime": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__},
        "input_sha256": {name: sha256((HERE / name).read_bytes()).hexdigest() for name in
                         ("run_finite_pilot.py", "readout_intervals.py", "sampling.py", INPUT_PATH.name)},
    }
    (folder / "manifest.json").write_text(json.dumps(metadata, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    filename = "Photon_Blockade_Finite_Pilot_Smoke.zip" if args.smoke else "Photon_Blockade_Finite_Pilot_Results.zip"
    archive = folder / filename
    temporary = archive.with_suffix(".part")
    with ZipFile(temporary, "w", compression=ZIP_DEFLATED) as result:
        for name in ("manifest.json", "previous_full_grid_oracle.csv", *(f"{n}.csv" for n in tables)):
            result.write(folder / name, name)
    temporary.replace(archive)
    print(f"Results written to {archive.resolve()}", flush=True)


if __name__ == "__main__":
    main()
