# Batched allocation comparison, protocol v2

Actual hardware records. One paired hardware pilot; retain null and inconclusive outcomes.

Recorded shots: 608,256; analyzed: 595,968; predeclared extra outcomes excluded: 12,288. Actual device shots: 608,256; actual hardware jobs: 32. Backend `ibm_marrakesh`, physical qubits [14, 55]; planning-device match True.

Each block uses one physical job containing distinct calibration PUBs for both arms, then one physical job containing distinct science PUBs for both arms. Both logical source schedules, per-input/per-population shot counts, 64-shot PUBs, and value-independent retention counts are preserved from the original allocation protocol. Requested PUBs are mixed by a predeclared permutation. There is no claim about physical per-shot arm order, and the former arm-first/arm-second timing policy no longer applies.

| Arm | Population | Known g2 | Corrected g2 | Nominal simultaneous interval | Upper below one | Target covered |
| --- | --- | ---: | ---: | --- | ---: | ---: |
| reference_allocation | signal | 0.5438 | 0.5623 | [0.2910, 0.8726] | 1 | 1 |
| reference_allocation | control | 1.0000 | 1.0648 | [0.7639, 1.4534] | 0 | 1 |
| selected_allocation | signal | 0.5438 | 0.5638 | [0.3834, 0.8079] | 1 | 1 |
| selected_allocation | control | 1.0000 | 1.0391 | [0.6936, 1.5699] | 0 | 1 |

The primary correction and nominal family alpha=0.05 are unchanged: two calibration matrices receive alpha/4 each, four science histograms alpha/8 each. Each arm's actual unequal sample sizes enter the existing KL/Chernoff boxes and full-matrix LP bounds. Primary fitting uses measured calibration and marginal science counts only; known source labels are reserved for diagnostics. The joint outcome requires a signal call and a valid control interval containing one. These four rows and sixteen blocks are not independent full-experiment repetitions, and no hardware success percentage, superiority p-value, or general resource advantage is inferred from one pair.

Shared jobs are counted **once** in `physical_job_costs.csv` and `physical_cost_totals`. Each arm participates in the same 32 physical jobs; its memberships overlap the other arm's and must not be summed. Per-arm acquired counts are separately validated, but physical RU charges are not apportioned between arms. Available RU totals may be partial or provisional; missing metrics mean unavailable, not zero.

There is one shared calibration-to-science gap per block, ranging from 30.067 to 49.514 seconds. Client-window fallbacks include queuing and are not physical execution windows. Combining jobs preserves the nominal inference argument only when conditional outcome independence and the relevant calibration/science response-matching assumptions hold for each arm. Grouping may change real preparation history, within-job response, or timing; this is a documented execution-protocol amendment made before acquisition, not proof that actual hardware power is unchanged.

For a response fixed within each modeled block, regrouping independent observations into shared jobs leaves each arm's calibration/science count distribution unchanged. That conditional fact does not transfer the prior simulation powers to unmodeled physical history effects. All original model-based power qualifications remain. This is an X-only nominal-number-label SPAM benchmark, not cavity-Hamiltonian evolution or a direct physical photon-blockade demonstration.
