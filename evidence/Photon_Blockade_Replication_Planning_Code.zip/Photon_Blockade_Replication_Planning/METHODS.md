# Methods and limits

## Data and allocation

The input archive SHA-256 is `98291d4ff4075ba4da9ca0a10d4b15ea019863f49c6db0a2246191ac08c5ee11`. It contains the completed `allocation-validation-v2-batched` pilot on `ibm_marrakesh`, qubits 14 and 55. Startup verifies all stored hashes, source fingerprints, raw PUB metadata/bitstrings, per-arm counts, and original output reproduction. Hardware provenance and usage are recorded metadata; the program makes no remote verification call.

The common assignment matrix is fitted from the pooled measured calibration counts only. Science source labels do not fit it. Pooling is a working common-response model, not proof that all blocks or arms have the same physical response. The allocations retain their original six-category ratios: four calibration inputs, signal science, and control science. Original analyzed vectors are reference [1600,1536,1536,1536,6208,6208] and selected [5568,3520,192,64,6976,2304].

For B blocks, chunk size 64, and requested budget scale s, the acquired units per arm/block are rounded half up from 304128*s/(B*64). Six units are reserved for the original value-independent maximum science padding convention. Remaining analyzed units are apportioned to the six categories using largest deficits from the normalized original weights, with at least one unit per category. This reproduces the original vectors exactly for s=1 and B=16. Every acquired and excluded shot enters the resource budget. Per-arm acquired/retained counts match exactly within a candidate; different B values can produce slightly different rounding and padding totals.

## Conditional observation models

Observed calibration columns and marginal science histograms are sampled independently within a fixed block response. For a population p and response A, its n retained science outcomes have multinomial probability vector A*p. This is the exact marginal law of independently sampled source labels and independent measurement outcomes under a block-fixed response. It integrates over the source-label draw and does not condition on a hand-picked realized source histogram. Discarded padding outcomes are not simulated because they never enter inference; their acquired costs are retained.

Stationary, linear increasing/decreasing, 1.5x high-error, and pulse cases scale off-diagonal errors. Linear factors run from approximately 0.5 to 1.5 across normalized block centers. Pulse height is uniform on [1.5,2.5] and shared by both arms in a paired experiment, over the middle third of block centers. Fresh pulse draws occur independently across simulated future pairs. This is a declared physical-path stress model, not a fitted drift process.

Two sensitivity cases draw each response column from Dirichlet(pooled calibration counts + 1/2). Each draw is made once and held fixed for the entire case, across all designs and all planning/validation trials. Thus unknown response parameters persist across repetitions; epistemic uncertainty is not redrawn independently for each future experiment or each block. These finite posterior sensitivity cases are neither a credible-region optimization nor a frequentist confidence guarantee for all possible response matrices.

For every matched case, calibration and science use the same effective response in each block. Per-category counts are constant across blocks within an arm, preserving the averaging weights required by the existing interval argument. A separate diagnostic mismatch case scales science errors by 0.75 while leaving calibration unchanged. It is excluded from selection, primary goals, and nominal coverage certification. Real timing/history and correlated outcome effects are not automatically captured by any case.

Independent observation streams are keyed by the complete source/input/config fingerprint, phase, case, design, trial, and arm. A shared physical-path stream omits design and arm. Planning and validation have disjoint phase namespaces. Persistent response sensitivity cases remain the same across phases because they represent fixed nuisance alternatives. Reproducibility of the same stream is not new independent evidence.

## Per-pair endpoint

The three confidence-code files are copied unchanged from the validated collector. Nominal family alpha is 0.05 across the two arm calibration matrices and four arm/population science histograms. Each calibration matrix receives alpha/4; each science histogram receives alpha/8. KL/Chernoff bounds for independent possibly unequal Bernoulli probabilities and full assignment-matrix LP bounds determine the g2 interval. A signal call requires a feasible interval with upper endpoint strictly below one. A joint success requires a signal call, no control call, and a valid control interval containing one. This endpoint is computed separately for each complete paired experiment.

The per-pair confidence budget, coverage goal, and false-control probability cap do not provide a familywise guarantee over every interval/control call in an N-pair future series. The alpha=0.05 allocation-comparison test is a separate single study-level inference about the binary paired outcomes.

## Future comparison and exact power

The future primary null is that selected-arm joint-success probability is no higher than reference-arm joint-success probability. For fixed N independently generated paired experiments, let W count selected-only joint successes and L count reference-only successes. The one-sided exact paired p-value is

    Pr[Binomial(W+L, 1/2) >= W],

or 1 when W+L=0. Reject when p<=0.05. The future N is fixed before collection. Blocks and histogram rows are not repetitions of this test. There is no interim stopping or retesting until significance.

Write a=Pr(selected-only), b=Pr(reference-only), and D=W+L. Under iid paired outcomes D~Binomial(N,a+b), and W conditional on D=d is Binomial(d,a/(a+b)). The exact power is the finite sum over d of the probability of d discordances times its conditional rejection probability. If a+b=0, power is zero. The code checks this result against independent enumeration of all trinomial (W,L,N-W-L) counts and checks that equal-discordance null power never exceeds alpha on the verification grid.

Official references for the exact-binomial paired construction and its directional implementation:

- https://www.statsmodels.org/stable/generated/statsmodels.stats.contingency_tables.mcnemar.html
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.binomtest.html

The code uses the predeclared one-sided direction through SciPy's binomial tail; it does not substitute the default two-sided statsmodels p-value. The repeated-study power calculation assumes iid complete pairs within a given model case. Fixed persistent response alternatives are analyzed separately; common unknown-parameter draws are not averaged as if they were independent future hardware pairs.

## Monte Carlo uncertainty, selection, and independent validation

For K matched cases, each endpoint receives one-sided error delta=0.05/(8*K). The eight endpoints per case are lower/upper bounds for a and b (four), false-control probability upper bounds for both arms (two), selected-arm joint-success lower bound (one), and paired family-target-coverage lower bound (one). Each endpoint uses an exact one-sided Clopper-Pearson bound from simulated complete pairs. A union bound gives at least 95% simultaneous coverage of these probability endpoints for a fixed validation design under the simulated models. It does not give 95% coverage over physical model misspecification or every unexamined channel.

The repeated-study rejection region increases with W and decreases with L. Its power is therefore increasing in a and decreasing in b. Evaluating power at (a_lower,min(b_upper,1-a_lower)) gives a conservative lower bound; evaluating at (min(a_upper,1-b_lower),b_lower) gives an upper bound. These simplex adjustments retain the componentwise ordering of every feasible true probability pair. These are uncertainty bounds for model-based test power, not hardware confidence intervals.

Planning searches the finite budget/block/pair-count grid. An eligible candidate has lower-bounded repeated-study power at least 80% and selected per-pair joint success at least 80% in every case, with planning point-rate screens for false controls at most 1% and paired family coverage at least 95%. The eligible candidate with lowest estimated total RUs is selected; ties prefer fewer repetitions then ID. Planning scores are selection criteria, not selection-adjusted statistical guarantees.

The exact candidate and N, all planning data hashes, and the config fingerprint are written to `selection_frozen.json` before validation. Independent validation uses 1,024 new simulated pairs per matched case and applies the simultaneous endpoint bounds to all four goals. Selection is never revised based on validation outcomes. If no planning candidate is eligible, there is no recommendation and no confirmatory validation of a forced winner. A smoke-only forced diagnostic choice is explicitly labeled and cannot pass model goals.

This is one proposed future test for one predeclared chosen design. Testing multiple budgets or redesigning after seeing fresh hardware outcomes would require a new inferential plan. Reusing the current development hardware pilot as confirmatory data would invalidate the claimed prospective separation.

## RU planning

The completed pilot reported 0.104787 RUs for 15,552-shot calibration jobs and 0.138762 RUs for 22,464-shot science jobs; all metrics were pending. A linear shot-plus-job-overhead fit reproduces the recorded full-pair 3.896784 RUs. The generic estimate is (2*physical_jobs + 0.00035*shots)/60, assuming one modeled preparation overhead per submitted job. Per-pair planning cost is the larger estimate, and series cost is N times that value. Shared-job costs are counted once, never once per arm.

The generic timing source is https://quantum.cloud.ibm.com/docs/en/ibm-quantum-compute/estimate-job-run-time (consulted during the preceding collector revision). Neither estimate is a validated upper bound. Server chunking, changed timing, correlations, backend changes, and plan multipliers can alter actual usage. The 10-RU series target is a user-editable planning assumption, not a current account balance or hardware authorization. A successful model design still needs a concrete hardware schedule and resource review. This code never connects or submits.

## Scientific scope

The existing measurements and proposed simulations concern X-only nominal-number-label SPAM inference. They do not evolve a cavity Hamiltonian or demonstrate physical photon blockade, quantum advantage, general resource savings, or transfer of physical dynamics between one- and two-emitter cavities. Any photon-cutoff conclusions require the separate cavity simulations and truncation analysis. The new exercise plans replication of an allocation comparison; it does not turn one successful hardware pair into a measured power estimate.
