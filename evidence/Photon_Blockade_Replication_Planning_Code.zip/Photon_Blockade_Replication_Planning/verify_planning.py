"""Independent finite-sum, resource, model, and cache checks; no IBM access."""

from copy import deepcopy
import json
from math import comb
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
from scipy.stats import binomtest

from paired_statistics import paired_pvalue, paired_test_power, study_power_bounds
from planning_model import (HERE, ARMS, apportion, digest, load_pilot, make_design,
                            model_cases, run_batch, simulate_pair, execution_source_hashes)
from run_replication_planning import freeze_selection


def brute_power(win, loss, pairs):
    value = 0.0
    for w in range(pairs + 1):
        for l in range(pairs - w + 1):
            if w + l and binomtest(w, w + l, .5, alternative="greater").pvalue <= .05:
                value += comb(pairs, w) * comb(pairs - w, l) * win**w * loss**l * (1-win-loss)**(pairs-w-l)
    return value


def statistics_checks():
    for w in range(12):
        for l in range(12):
            expected = 1.0 if w+l == 0 else binomtest(w,w+l,.5,alternative="greater").pvalue
            assert paired_pvalue(w,l) == expected
    for n in (1,4,5,8,12):
        for w,l in ((.0,.0),(.3,.05),(.1,.1),(.6,.1),(.5,.5),(.0,.5)):
            assert abs(paired_test_power(w,l,n)-brute_power(w,l,n)) < 1e-12
    for n in (5,8,16,32,64,128,256):
        for p in (0,.01,.05,.1,.25,.5):
            assert paired_test_power(p,p,n) <= .05+1e-12
    assert paired_pvalue(4,0) > .05 and paired_pvalue(5,0) <= .05
    cells={"both_fail":20,"selected_only":65,"reference_only":5,"both_success":10}
    bounds=study_power_bounds(cells,24,.001)
    assert bounds['study_power_lower_bound'] <= bounds['study_power_plugin'] <= bounds['study_power_upper_bound']
    zero=study_power_bounds({"both_fail":0,"selected_only":0,"reference_only":0,"both_success":100},256,.001)
    assert zero['study_power_lower_bound'] == 0
    return {"directional_pvalues_match_scipy_exact_binomial":"passed",
            "study_power_matches_independent_trinomial_enumeration":"passed",
            "exact_null_rejection_probability_not_above_alpha":"passed",
            "finite_mc_bounds_and_zero_discordance_no_power":"passed"}


def design_checks(pilot):
    full=make_design(pilot,1,16)
    for arm in ARMS:
        vector=full['arms'][arm]['calibration']+list(full['arms'][arm]['science'].values())
        assert vector==pilot['original_allocation_vectors'][arm]
    assert full['acquired_shots_per_pair']==608256 and full['physical_jobs_per_pair']==32
    assert abs(full['usage_estimates_per_pair']['empirical_ru']-3.896784) < 1e-12
    for scale in (.25,.375,.5,.625,.75,.875,1):
        for b in (4,8,16):
            d=make_design(pilot,scale,b)
            for arm in ARMS:
                vector=d['arms'][arm]['calibration']+list(d['arms'][arm]['science'].values())
                assert all(n>=64 and n%64==0 for n in vector)
                assert sum(vector)*b==d['analyzed_shots_per_arm']
                assert d['analyzed_shots_per_arm']+d['predeclared_padding_per_arm']==d['acquired_shots_per_arm']
            assert 2*d['acquired_shots_per_arm']==d['acquired_shots_per_pair']
            assert d['physical_jobs_per_pair']==2*b
    for total in (6,12,73,291):
        assert int(apportion(total,[87,55,3,1,109,36]).sum())==total
    return {"full_budget_reproduces_exact_frozen_allocations":"passed",
            "all_grid_budgets_rounding_minimum_counts_and_padding":"passed",
            "empirical_ru_fit_reproduces_recorded_shared_cost":"passed"}


def simulation_checks(pilot):
    cases=model_cases(pilot,26111953,2)
    assert cases==model_cases(pilot,26111953,2)
    case=next(c for c in cases if c['id']=='persistent_uncertainty_01')
    before=deepcopy(case)
    d=make_design(pilot,.5,4)
    trial=simulate_pair(pilot,d,case,'verification','planning',0)
    assert trial==simulate_pair(pilot,d,case,'verification','planning',0)
    independent=simulate_pair(pilot,d,case,'verification','validation',0)
    assert trial['arms']!=independent['arms'] and case==before
    pulse=next(c for c in cases if c['id']=='pulse')
    other=make_design(pilot,.75,4)
    a=simulate_pair(pilot,d,pulse,'verification','planning',2)
    b=simulate_pair(pilot,other,pulse,'verification','planning',2)
    assert a['world_sha256']==b['world_sha256']
    for arm in ARMS:
        cal=np.asarray(trial['arms'][arm]['calibration_counts'])
        assert cal.sum(axis=0).tolist()==[d['blocks']*n for n in d['arms'][arm]['calibration']]
        for pop,n in d['arms'][arm]['science'].items():
            assert sum(trial['arms'][arm]['populations'][pop]['counts'])==d['blocks']*n
    with TemporaryDirectory(prefix='replication_cache_check_') as tmp:
        task={'path':str(Path(tmp)/'batch.json'),'pilot':pilot,'config_sha256':'verification',
              'source_sha256':execution_source_hashes(),
              'phase':'planning','case':case,'design':d,'start':0,'count':1}
        assert not run_batch(task)['reused']
        assert run_batch(task)['reused']
        changed=deepcopy(task);changed['source_sha256']={}
        try: run_batch(changed)
        except ValueError: pass
        else: raise AssertionError('Changed source fingerprint accepted')
        path=Path(task['path']);cached=json.loads(path.read_text());cached['trials'][0]['arms'][ARMS[0]]['joint_success']=not cached['trials'][0]['arms'][ARMS[0]]['joint_success'];path.write_text(json.dumps(cached))
        try: run_batch(task)
        except ValueError: pass
        else: raise AssertionError('Damaged cached batch accepted')
    return {"persistent_calibration_worlds_fixed_across_phases":"passed",
            "shared_physical_path_independent_arm_observations_and_exact_counts":"passed",
            "planning_validation_streams_separate_and_reproducible":"passed",
            "cache_resume_source_guard_and_tamper_rejection":"passed"}


def selection_checks(pilot):
    designs=[make_design(pilot,.25,4),make_design(pilot,.5,4)]
    cases=model_cases(pilot,1,0)[:1]
    config={'smoke':False,'pair_grid':[8,16],'test_alpha':.05,'power_goal':.8,'selected_joint_goal':.8,'false_control_cap':.01,'coverage_goal':.95,'resource_target_ru':10}
    rows=[]
    for d in designs:
        rows.append({'design':d['id'],'both_fail':0,'selected_only':900,'reference_only':0,'both_success':100,'mc_pairs':1000,
                     'selected_control_false_rate':0,'reference_control_false_rate':0,'family_coverage_rate':1,'selected_joint_lower_bound':.95,'mc_tail_alpha_per_endpoint':.001})
    with TemporaryDirectory(prefix='planning_selection_check_') as tmp:
        folder=Path(tmp)
        chosen=freeze_selection(folder,config,cases,designs,rows)
        assert chosen['status']=='selected_on_planning_simulations_only' and chosen['choice']['design']==designs[0]['id']
        assert chosen['choice']['hardware_pairs']==8 and not chosen['selection_uses_validation']
        (folder/'validation_summary.json').write_text('{"unrelated_validation_outcome":"changed"}')
        assert chosen==freeze_selection(folder,config,cases,designs,rows)
    for r in rows:r.update(both_success=1000,selected_only=0,reference_only=0)
    with TemporaryDirectory(prefix='planning_no_choice_check_') as tmp:
        result=freeze_selection(Path(tmp),config,cases,designs,rows)
        assert result['choice'] is None and result['status']=='no_eligible_design_no_recommendation'
    return {"selection_uses_only_planning_and_freezes_pair_count":"passed","no_eligible_design_retained_as_valid_outcome":"passed"}


if __name__=='__main__':
    pilot=load_pilot(HERE/'input'/'Photon_Blockade_Allocation_Validation_Batched_Results.zip')
    result={**statistics_checks(),**design_checks(pilot),**simulation_checks(pilot),**selection_checks(pilot),'status':'passed','actual_new_hardware_jobs':0}
    (HERE/'verification_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
