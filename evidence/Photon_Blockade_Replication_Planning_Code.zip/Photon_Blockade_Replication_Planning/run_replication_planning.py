"""Plan a repeated paired allocation comparison locally. Zero IBM jobs or RUs."""

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import csv
from datetime import datetime, timezone
from hashlib import sha256
from importlib.metadata import version
import json
import multiprocessing
import os
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

import numpy as np

from planning_model import (HERE, ARMS, atomic_json, digest, load_pilot, make_design,
                            model_cases, run_batch, execution_source_hashes)
from paired_statistics import cell_counts, lower_binomial, upper_binomial, study_power_bounds
from runtime_io import collection_lock


def source_hashes():
    return execution_source_hashes()


def write_csv(path, rows):
    if not rows:
        path.write_text("no_rows\n", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def batch_paths(folder, phase, case, design):
    return sorted((folder / "batches" / phase / case / design).glob("*.json"))


def tasks_for(folder, config, pilot, phase, cases, designs):
    count = config["planning_trials"] if phase == "planning" else config["validation_trials"]
    tasks = []
    for case in cases:
        for design in designs:
            for start in range(0, count, config["batch_size"]):
                tasks.append({"path": str(folder / "batches" / phase / case["id"] / design["id"] / f"batch_{start:06d}.json"),
                              "config_sha256": digest(config), "pilot": pilot, "phase": phase,
                              "source_sha256": config["source_sha256"],
                              "case": case, "design": design, "start": start,
                              "count": min(config["batch_size"], count - start)})
    return tasks


def run_tasks(tasks, workers):
    if workers == 1:
        for i, task in enumerate(tasks, 1):
            result = run_batch(task)
            if i == 1 or i % 16 == 0 or i == len(tasks):
                print(f"  Batches {i}/{len(tasks)}; last {'reused' if result['reused'] else 'completed'}", flush=True)
        return
    context = multiprocessing.get_context("spawn")
    with ProcessPoolExecutor(max_workers=workers, mp_context=context) as pool:
        futures = [pool.submit(run_batch, task) for task in tasks]
        for i, future in enumerate(as_completed(futures), 1):
            result = future.result()
            if i == 1 or i % 16 == 0 or i == len(tasks):
                print(f"  Batches {i}/{len(tasks)}; last {'reused' if result['reused'] else 'completed'}", flush=True)


def aggregate(folder, config, phase, case, design):
    expected = config["planning_trials"] if phase == "planning" else config["validation_trials"]
    trials = []
    for path in batch_paths(folder, phase, case["id"], design["id"]):
        data = json.loads(path.read_text())
        if data["config_sha256"] != digest(config) or data["phase"] != phase or data["case"] != case or data["design"] != design:
            raise ValueError(f"Unexpected cached batch specification: {path}")
        if digest({k: v for k, v in data.items() if k != "result_sha256"}) != data["result_sha256"]:
            raise ValueError(f"Cached result hash mismatch: {path}")
        trials.extend(data["trials"])
    trials.sort(key=lambda r: r["trial"])
    if [r["trial"] for r in trials] != list(range(expected)):
        raise ValueError("Simulated pair IDs are missing or duplicated")
    cells = cell_counts(trials)
    alpha = config["mc_alpha"] / (8 * len(config["selection_cases"]))
    row = {"phase": phase, "case": case["id"], "design": design["id"], "mc_pairs": expected, **cells,
           "selected_joint_rate": (cells["both_success"] + cells["selected_only"]) / expected,
           "reference_joint_rate": (cells["both_success"] + cells["reference_only"]) / expected,
           "selected_joint_lower_bound": lower_binomial(cells["both_success"] + cells["selected_only"], expected, alpha)}
    for arm in ARMS:
        short = "selected" if arm == "selected_allocation" else "reference"
        false = sum(t["arms"][arm]["control_false_call"] for t in trials)
        row[f"{short}_control_false_calls"] = false
        row[f"{short}_control_false_rate"] = false / expected
        row[f"{short}_control_false_upper_bound"] = upper_binomial(false, expected, alpha)
    covered = sum(t["family_all_targets_covered"] for t in trials)
    row.update(family_coverage_count=covered, family_coverage_rate=covered / expected,
               family_coverage_lower_bound=lower_binomial(covered, expected, alpha),
               mc_tail_alpha_per_endpoint=alpha)
    return row


def powers_for(row, config, pairs):
    cells = {k: row[k] for k in ("both_fail", "selected_only", "reference_only", "both_success")}
    return study_power_bounds(cells, pairs, row["mc_tail_alpha_per_endpoint"], config["test_alpha"])


def freeze_selection(folder, config, cases, designs, summaries):
    grid_rows = []
    for design in designs:
        model_rows = [r for r in summaries if r["design"] == design["id"]]
        for pairs in config["pair_grid"]:
            power = [powers_for(r, config, pairs) for r in model_rows]
            worst_lower = min(p["study_power_lower_bound"] for p in power)
            worst_plugin = min(p["study_power_plugin"] for p in power)
            # These two rates are planning screens. The independent validation
            # applies simultaneous confidence bounds, rather than these rates.
            false_rate = max(max(r["selected_control_false_rate"], r["reference_control_false_rate"]) for r in model_rows)
            coverage = min(r["family_coverage_rate"] for r in model_rows)
            joint_lower = min(r["selected_joint_lower_bound"] for r in model_rows)
            cost = design["usage_estimates_per_pair"]["planning_ru"] * pairs
            eligible = (worst_lower >= config["power_goal"] and joint_lower >= config["selected_joint_goal"]
                        and false_rate <= config["false_control_cap"] and coverage >= config["coverage_goal"])
            grid_rows.append({"design": design["id"], "hardware_pairs": pairs,
                              "worst_model_power_plugin": worst_plugin, "worst_model_power_lower_bound": worst_lower,
                              "largest_planning_false_control_rate": false_rate, "smallest_planning_family_coverage_rate": coverage,
                              "smallest_planning_selected_joint_lower_bound": joint_lower,
                              "planning_total_ru": cost, "within_ru_target": cost <= config["resource_target_ru"],
                              "eligible_model_screen": eligible})
    eligible = [r for r in grid_rows if r["eligible_model_screen"]]
    if config["smoke"]:
        chosen = next(r for r in grid_rows if r["design"] == designs[-1]["id"] and r["hardware_pairs"] == config["pair_grid"][0])
        status = "workflow_only_forced_choice_not_a_recommendation"
    elif eligible:
        chosen = min(eligible, key=lambda r: (r["planning_total_ru"], r["hardware_pairs"], r["design"]))
        status = "selected_on_planning_simulations_only"
    else:
        chosen, status = None, "no_eligible_design_no_recommendation"
    records = [{"file": p.relative_to(folder).as_posix(), "sha256": sha256(p.read_bytes()).hexdigest()}
               for p in sorted((folder / "batches" / "planning").rglob("*.json"))]
    selection = {"config_sha256": digest(config), "status": status, "choice": chosen,
                 "choice_design": next((d for d in designs if chosen and d["id"] == chosen["design"]), None),
                 "planning_batch_hashes": records, "selection_uses_validation": False,
                 "rule": "Among designs meeting the stated worst-model power lower-bound and planning point-rate screens, minimize total planning RUs; break ties by pair count then ID. No eligible design is a valid outcome. Cost-target feasibility is reported separately."}
    path = folder / "selection_frozen.json"
    if path.exists():
        previous = json.loads(path.read_text())
        if {k: v for k, v in previous.items() if k != "frozen_utc"} != selection:
            raise ValueError("Frozen selection differs; use the original files or a new output directory")
        selection = previous
    else:
        selection["frozen_utc"] = datetime.now(timezone.utc).isoformat()
        atomic_json(path, selection)  # must exist before any validation task
    write_csv(folder / "planning_study_grid.csv", grid_rows)
    return selection


def summarize(folder, config, pilot, selection, planning_rows, validation_rows, mismatch_rows):
    chosen = selection["choice"]
    validation_power = []
    if chosen:
        for row in validation_rows:
            validation_power.append({"case": row["case"], **powers_for(row, config, chosen["hardware_pairs"])})
    minimum_power = min((r["study_power_lower_bound"] for r in validation_power), default=None)
    maximum_false = max((max(r["selected_control_false_upper_bound"], r["reference_control_false_upper_bound"]) for r in validation_rows), default=None)
    minimum_coverage = min((r["family_coverage_lower_bound"] for r in validation_rows), default=None)
    minimum_joint = min((r["selected_joint_lower_bound"] for r in validation_rows), default=None)
    passes = bool(not config["smoke"] and chosen and minimum_power >= config["power_goal"]
                  and minimum_joint >= config["selected_joint_goal"] and maximum_false <= config["false_control_cap"]
                  and minimum_coverage >= config["coverage_goal"])
    cost = chosen["planning_total_ru"] if chosen else None
    status = {"schema_version": 1, "provenance": "synthetic_offline", "config_sha256": digest(config),
              "smoke": config["smoke"], "selection_status": selection["status"],
              "independent_validation_performed": bool(chosen), "matched_model_goals_met": passes,
              "minimum_validation_study_power_lower_bound": minimum_power,
              "maximum_validation_control_false_upper_bound": maximum_false,
              "minimum_validation_family_coverage_lower_bound": minimum_coverage,
              "minimum_validation_selected_joint_lower_bound": minimum_joint,
              "chosen_design": selection["choice_design"], "planned_hardware_pairs": chosen["hardware_pairs"] if chosen else None,
              "estimated_confirmatory_series_ru": cost, "resource_target_ru": config["resource_target_ru"],
              "within_resource_target": bool(cost is not None and cost <= config["resource_target_ru"]),
              "fits_previous_estimated_remaining_ru": bool(cost is not None and cost <= pilot["input_audit"]["estimated_remaining_ru_if_no_other_usage"]),
              "ready_for_hardware_schedule_review": bool(passes and cost <= config["resource_target_ru"]),
              "actual_new_hardware_jobs": 0, "actual_new_hardware_shots": 0, "actual_resource_units_used": 0,
              "scope": "Conditional design for iid paired full experiments in the listed response models. Not empirical hardware power, a hard RU cap, or a ready-to-submit collector."}
    atomic_json(folder / "validation_summary.json", status)
    write_csv(folder / "simulation_summary.csv", planning_rows + validation_rows + mismatch_rows)
    write_csv(folder / "validation_study_power.csv", validation_power)
    choice_text = "No eligible candidate was found in the predeclared grid. No hardware design is recommended."
    if chosen:
        design = selection["choice_design"]
        choice_text = f"Frozen candidate `{design['id']}` uses {design['acquired_shots_per_pair']:,} acquired shots and {design['physical_jobs_per_pair']} shared physical jobs per paired experiment, repeated {chosen['hardware_pairs']} times. Estimated series usage is {cost:.3f} RUs, using the larger of the two per-pair planning estimates. Cost-target fit: {status['within_resource_target']} (target {config['resource_target_ru']:.2f} RUs). This is not a hard usage cap."
    text = f"""# Offline replication planning

**{'Workflow smoke only; the forced choice is not a recommendation.' if config['smoke'] else 'Model-based planning only; no IBM jobs or RUs were used.'}**

The prior hardware pilot was used as development input. Its two successful arms are not counted as new confirmatory replications. The common response model uses pooled calibration counts only; the allocation fractions and generating distributions stay frozen. Model changes, shot budgets, block counts, and future independent replication are being planned, not retrospectively validated on that hardware pilot.

## Candidate

{choice_text}

Selection status: `{selection['status']}`. Independent validation uses new observation and physical-path streams after the choice, including the replication count, is frozen. Matched-model goals met: **{passes}**. Worst validation lower bound for full-study test power: {minimum_power}. Smallest validation lower bound for the selected arm's per-pair joint success: {minimum_joint}. Largest validation upper bound for either arm's false-control probability: {maximum_false}. Smallest validation lower bound for simultaneous target coverage in a paired experiment: {minimum_coverage}.

## Statistical target

The primary future test is one directional exact McNemar test at alpha={config['test_alpha']}: the selected allocation has higher joint-success probability than the reference. One observation is a complete independently randomized paired allocation experiment, not a block or histogram row. The future pair count is fixed before collection; there is no repeated testing or outcome-dependent stopping. Full-study comparison power must be at least {config['power_goal']:.2f}; the selected arm's per-pair joint-success probability must also be at least {config['selected_joint_goal']:.2f}. The false-control cap per arm is {config['false_control_cap']:.3f}, and paired family-coverage goal is {config['coverage_goal']:.2f} in every listed matched model.

Repeated-study rejection probabilities are computed exactly from simulated discordance probabilities. The code uses conservative one-sided exact binomial bounds for Monte Carlo uncertainty. For a fixed validation choice, four discordance bounds (lower/upper endpoints for both probabilities), two control-call bounds, one selected-joint-success bound, and one family-coverage bound per matched case share total Monte Carlo error {config['mc_alpha']:.2f} by a union bound. This is simulation uncertainty conditional on the models, not coverage over unknown physical response models. The minimum/maximum across the specified cases is not a guarantee over every possible channel.

## Model and resource limits

The calibration-derived posterior sensitivity matrices are drawn once per case and remain fixed across all designs, phases, trials, and future repetitions within that case. They are persistent unknown-response alternatives, not independent per-block drift or fresh epistemic draws for each future repetition. Finite sensitivity draws do not exhaust calibration uncertainty. Explicit linear/high-error/pulse paths are stress assumptions, not measured drift. The pulse height varies jointly for both arms across simulated pairs by a predeclared physical-path model. Calibration/science matching holds within each modeled block; the separate mismatch case is diagnostic and never selects a winner or certifies coverage.

Each future pair models two distinct calibration datasets and two populations per arm in one shared calibration/science job pair per block. Arm observations are independent conditional on the shared response path. Acquisition costs include 64-shot rounding, at least one unit per analyzed category, and six padding PUBs per arm/block. Changing block counts changes calibration cadence; the old 16-block hardware schedule cannot execute these designs unchanged. Timing/history effects beyond these models are not included. The nominal marginal count simulation is exact for the stated block-fixed independent mixture model; padding is charged without simulating its discarded outcomes.

Empirical RU estimates extrapolate this pilot's pending metrics; generic estimates assume one preparation overhead per physical job. Neither accounts for every server chunk, future timing change, or plan multiplier. RUs of shared jobs are counted once. The {config['resource_target_ru']:.2f}-RU resource target is an editable planning assumption, not a verified balance or reserved allowance. Any hardware collection needs a separately reviewed schedule and an actual current balance.

The primary interval code is unchanged and reuses family alpha=0.05 within each pair. That is separate from alpha={config['test_alpha']} for the future between-allocation comparison. A nominal type-I guarantee for comparing the binary recorded outcomes does not prove physical cutoff accuracy or calibration response matching. The benchmark uses X-only nominal number labels and does not implement cavity dynamics.

## Files

`candidate_designs.csv` gives exact counts and per-pair costs; `planning_study_grid.csv` gives every candidate/pair-count score. `selection_frozen.json` records the choice and planning hashes before validation. `simulation_summary.csv`, `validation_study_power.csv`, and `validation_summary.json` record results, including null/ineligible outcomes. `batches/` preserves all simulated counts and decisions with integrity hashes and independent phase/trial keys. `config.json` and `pilot_model.json` retain the full input/source/config fingerprint and verified model inputs.
"""
    (folder / "report.md").write_text(text, encoding="utf-8")
    return status


def run(args):
    pilot = load_pilot(args.input)
    scales = args.scales or ([.5, 1.0] if args.smoke else [.25, .375, .5, .625, .75, .875, 1.0])
    block_grid = args.blocks or ([4, 16] if args.smoke else [4, 8, 16])
    designs = [make_design(pilot, scale, blocks) for scale in scales for blocks in block_grid]
    designs = list({d["id"]: d for d in designs}.values())
    cases = model_cases(pilot, args.seed, 2)
    if args.smoke:
        designs = [make_design(pilot, .5, 4), make_design(pilot, 1.0, 16)]
        cases = [c for c in cases if c["id"] in ("stationary", "pulse", "persistent_uncertainty_01")]
    config = {"schema_version": 1, "protocol_id": "offline-replication-planning-v1", "smoke": args.smoke,
              "seed": args.seed, "input_sha256": pilot["input_sha256"], "source_sha256": source_hashes(),
              "scientific_packages": {n: version(n) for n in ("numpy", "scipy")},
              "planning_trials": args.planning_trials or (4 if args.smoke else 256),
              "validation_trials": args.validation_trials or (8 if args.smoke else 1024),
              "batch_size": 32, "designs": designs, "selection_cases": cases,
              "pair_grid": args.pairs or ([8, 16] if args.smoke else [8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256]),
              "power_goal": .80, "selected_joint_goal": .80, "false_control_cap": .01, "coverage_goal": .95,
              "test_alpha": .05, "mc_alpha": .05, "resource_target_ru": args.resource_target_ru,
              "primary_test": "one_sided_exact_McNemar_selected_joint_success_greater",
              "seed_policy": "Whole config/source/input fingerprint keys observations and shared physical paths; planning and validation are separate. Persistent calibration cases are fixed across phases."}
    folder = args.out or HERE / ("replication_planning_smoke" if args.smoke else "replication_planning_results")
    folder.mkdir(parents=True, exist_ok=True)
    with collection_lock(folder):
        path = folder / "config.json"
        if path.exists() and json.loads(path.read_text()) != config:
            raise ValueError("This folder has different source, input, or settings; resume with the original files or use a new --out directory")
        if not path.exists():
            atomic_json(path, config)
        atomic_json(folder / "pilot_model.json", pilot)
        candidates = []
        for d in designs:
            for arm in ARMS:
                p = d["arms"][arm]
                candidates.append({"design": d["id"], "arm": arm, "blocks": d["blocks"], "requested_scale": d["requested_scale"],
                                   "actual_scale": d["actual_scale"], "acquired_shots_per_arm": d["acquired_shots_per_arm"],
                                   "analyzed_shots_per_arm": d["analyzed_shots_per_arm"], "padding_per_arm": d["predeclared_padding_per_arm"],
                                   **{f"cal_{i:02b}_per_block": n for i, n in enumerate(p["calibration"])},
                                   "signal_per_block": p["science"]["signal"], "control_per_block": p["science"]["control"],
                                   "shared_jobs_per_pair": d["physical_jobs_per_pair"],
                                   **{k: v for k, v in d["usage_estimates_per_pair"].items() if k != "assumption"}})
        write_csv(folder / "candidate_designs.csv", candidates)
        print(f"Offline planning: {len(designs)} candidates, {len(cases)} matched cases; {config['planning_trials']} simulated pairs per cell. Zero IBM jobs or RUs.", flush=True)
        run_tasks(tasks_for(folder, config, pilot, "planning", cases, designs), args.workers)
        if source_hashes() != config['source_sha256']:
            raise ValueError('Source changed during planning; preserve the original code to resume')
        plan_rows = [aggregate(folder, config, "planning", c, d) for c in cases for d in designs]
        selection = freeze_selection(folder, config, cases, designs, plan_rows)
        valid_rows, mismatch_rows = [], []
        if selection["choice"]:
            chosen = selection["choice_design"]
            print(f"Choice frozen: {chosen['id']}, {selection['choice']['hardware_pairs']} future pairs. Starting independent validation.", flush=True)
            run_tasks(tasks_for(folder, config, pilot, "validation", cases, [chosen]), args.workers)
            valid_rows = [aggregate(folder, config, "validation", c, chosen) for c in cases]
            mismatch = {"id": "local_drop_mismatch", "base_matrix": pilot["empirical_matrix"], "matched": False, "kind": "diagnostic_only"}
            run_tasks(tasks_for(folder, config, pilot, "diagnostic", [mismatch], [chosen]), args.workers)
            mismatch_rows = [aggregate(folder, config, "diagnostic", mismatch, chosen)]
        if source_hashes() != config['source_sha256']:
            raise ValueError('Source changed during validation; preserve the original code to resume')
        status = summarize(folder, config, pilot, selection, plan_rows, valid_rows, mismatch_rows)
        selected = sorted(p for p in folder.rglob('*') if p.is_file() and p.name not in ("collector.lock", "result_sha256.json") and p.suffix not in ('.zip', '.part'))
        atomic_json(folder / "result_sha256.json", {p.relative_to(folder).as_posix(): sha256(p.read_bytes()).hexdigest() for p in selected})
        archive = folder / f"Photon_Blockade_Replication_Planning_{'Smoke' if args.smoke else 'Results'}.zip"
        temporary = archive.with_suffix('.part')
        with ZipFile(temporary, 'w', compression=ZIP_DEFLATED) as z:
            for p in selected + [folder / "result_sha256.json"]:
                z.write(p, p.relative_to(folder).as_posix())
        temporary.replace(archive)
    print(json.dumps(status, indent=2), flush=True)
    print(f"Finished. Upload {archive.resolve()}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--smoke', action='store_true', help='Small workflow test; never a hardware recommendation')
    parser.add_argument('--workers', type=int, default=min(4, os.cpu_count() or 1))
    parser.add_argument('--seed', type=int, default=26111953)
    parser.add_argument('--planning-trials', type=int)
    parser.add_argument('--validation-trials', type=int)
    parser.add_argument('--scales', type=float, nargs='+')
    parser.add_argument('--blocks', type=int, nargs='+')
    parser.add_argument('--pairs', type=int, nargs='+')
    parser.add_argument('--resource-target-ru', type=float, default=10.0, help='Planning target for the whole future series, not a current balance or a cap')
    parser.add_argument('--input', type=Path, default=HERE / 'input' / 'Photon_Blockade_Allocation_Validation_Batched_Results.zip')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if args.seed < 0 or args.workers < 1 or any(x is not None and x < 1 for x in (args.planning_trials, args.validation_trials)):
        parser.error('Use positive worker/trial counts and a nonnegative seed')
    if not np.isfinite(args.resource_target_ru) or args.resource_target_ru <= 0:
        parser.error('The resource target must be positive and finite')
    if args.scales and any(not np.isfinite(x) or not 0 < x <= 1 for x in args.scales):
        parser.error('Budget scales must be finite and in (0,1]')
    if args.blocks and any(b < 2 or b > 64 for b in args.blocks):
        parser.error('Block counts must be between 2 and 64')
    if args.pairs and any(n < 1 or n > 1024 for n in args.pairs):
        parser.error('Future pair counts must be between 1 and 1024')
    try:
        run(args)
    except (ValueError, AssertionError) as error:
        parser.exit(1, f'Validation failed: {error}\n')


if __name__ == '__main__':
    main()
