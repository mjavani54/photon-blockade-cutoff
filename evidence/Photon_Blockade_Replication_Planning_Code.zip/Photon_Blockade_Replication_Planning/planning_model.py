"""Offline paired allocation simulations, anchored to verified calibration data."""

from hashlib import sha256
import json
from pathlib import Path
import sys
from zipfile import ZipFile

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "frozen_code"))
from experiment import ARMS, POPULATIONS
from intervals import assignment_box, measured_tail_box
from matrix_readout import full_matrix_interval
from runtime_io import atomic_json


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def execution_source_hashes():
    files = [HERE / n for n in ("planning_model.py", "paired_statistics.py", "run_replication_planning.py", "input_audit.py")]
    files += sorted((HERE / "frozen_code").glob("*"))
    return {p.relative_to(HERE).as_posix(): sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}


def rng_for(*parts):
    key = digest(parts)
    return np.random.default_rng(np.random.SeedSequence([int(key[i:i + 8], 16) for i in range(0, 64, 8)]))


def load_pilot(path):
    from input_audit import audit
    audited = audit(path, HERE / "frozen_code")
    with ZipFile(path) as z:
        summary = json.loads(z.read("analysis_manifest.json"))
        schedule = json.loads(z.read("schedule.json"))
        config = json.loads(z.read("collection_manifest.json"))
        cal = sum(np.asarray(c, dtype=np.int64) for c in summary["calibration_counts"].values())
        costs = summary["physical_cost_totals"]
        stage_groups = {}
        for stage in schedule["stages"]:
            r = json.loads(z.read(f"stages/stage_{stage['stage_index']:03d}.json"))
            stage_groups.setdefault(stage["shots"], []).append(r["job_metrics"]["usage"]["value"])
        groups = sorted((shots, float(np.mean(values))) for shots, values in stage_groups.items())
        if len(groups) != 2:
            raise ValueError("RU extrapolation expects two pilot job sizes")
        (xa, ya), (xb, yb) = groups
        rate = (yb - ya) / (xb - xa)
        overhead = ya - rate * xa
        if min(rate, overhead) <= 0:
            raise ValueError("Invalid empirical RU fit")
        original = {}
        for arm, plan in schedule["arm_plans"].items():
            original[arm] = plan["calibration"] + [plan["science"][pop] for pop in POPULATIONS]
        return {"input_sha256": audited["input_archive_sha256"], "input_audit": audited,
                "backend": config["backend"], "physical_qubits": config["physical_qubits"],
                "pooled_calibration_counts": cal.tolist(), "empirical_matrix": (cal / cal.sum(axis=0)).tolist(),
                "targets": schedule["targets"], "original_allocation_vectors": original,
                "baseline_acquired_shots_per_arm": schedule["total_shots"] // 2,
                "microbatch": 64, "ru_per_shot": rate, "ru_overhead_per_job": overhead,
                "ru_fit_groups": groups, "pilot_reported_ru": costs["available_resource_units"],
                "pilot_ru_pending_jobs": costs["jobs_ru_pending"],
                "channel_fit": "Only pooled measured calibration data fit the common-response working model; science labels do not fit it."}


def apportion(total, weights):
    """Nearest largest-deficit integer allocation with at least one unit/cell."""
    weights = np.asarray(weights, dtype=float)
    if total < len(weights) or np.any(weights <= 0):
        raise ValueError("Budget cannot cover every calibration/science category")
    raw = total * weights / weights.sum()
    units = np.maximum(1, np.floor(raw).astype(int))
    while units.sum() < total:
        index = max(range(len(units)), key=lambda j: (raw[j] - units[j], -j))
        units[index] += 1
    while units.sum() > total:
        choices = [j for j in range(len(units)) if units[j] > 1]
        index = max(choices, key=lambda j: (units[j] - raw[j], -j))
        units[index] -= 1
    return units


def usage_estimate(pilot, shots, jobs):
    empirical = shots * pilot["ru_per_shot"] + jobs * pilot["ru_overhead_per_job"]
    generic = (2 * jobs + .00035 * shots) / 60
    return {"empirical_ru": empirical, "generic_ru": generic, "planning_ru": max(empirical, generic),
            "assumption": "One overhead per submitted physical job; extrapolation from provisional metrics, not a hard cap."}


def make_design(pilot, scale, blocks):
    chunk = pilot["microbatch"]
    units = int(np.floor(pilot["baseline_acquired_shots_per_arm"] * scale / (blocks * chunk) + .5))
    analyzed = units - 6
    if blocks < 1 or analyzed < 6:
        raise ValueError("Budget is too small for the block count")
    arms = {}
    for arm in ARMS:
        counts = (apportion(analyzed, pilot["original_allocation_vectors"][arm]) * chunk).tolist()
        arms[arm] = {"calibration": counts[:4], "science": dict(zip(POPULATIONS, counts[4:], strict=True))}
    shots = 2 * blocks * units * chunk
    return {"id": f"b{blocks:02d}_u{units:04d}", "requested_scale": float(scale), "blocks": blocks,
            "microbatch": chunk, "arms": arms, "physical_jobs_per_pair": 2 * blocks,
            "acquired_shots_per_pair": shots, "acquired_shots_per_arm": shots // 2,
            "analyzed_shots_per_arm": blocks * analyzed * chunk,
            "predeclared_padding_per_arm": blocks * 6 * chunk,
            "actual_scale": shots / (2 * pilot["baseline_acquired_shots_per_arm"]),
            "usage_estimates_per_pair": usage_estimate(pilot, shots, 2 * blocks)}


def model_cases(pilot, seed, posterior_worlds=2):
    empirical = pilot["empirical_matrix"]
    cases = [{"id": name, "base_matrix": empirical, "matched": True, "kind": "fixed_empirical_base"}
             for name in ("stationary", "linear_up", "linear_down", "pulse", "high_error")]
    counts = np.asarray(pilot["pooled_calibration_counts"])
    for i in range(posterior_worlds):
        rng = rng_for(seed, pilot["input_sha256"], "persistent_calibration_world", i)
        matrix = np.stack([rng.dirichlet(counts[:, j] + .5) for j in range(4)], axis=1)
        cases.append({"id": f"persistent_uncertainty_{i + 1:02d}", "base_matrix": matrix.tolist(),
                      "matched": True, "kind": "one_fixed_column_Dirichlet_sensitivity_world_for_entire_study"})
    return cases


def scaled_matrix(base, factor):
    matrix = np.eye(4) + factor * (np.asarray(base) - np.eye(4))
    if np.min(matrix) < -1e-12 or not np.allclose(matrix.sum(axis=0), 1):
        raise ValueError("Modeled response is not stochastic")
    matrix = np.maximum(matrix, 0)
    return matrix / matrix.sum(axis=0)


def response_path(case, blocks, rng):
    centers = (np.arange(blocks) + .5) / blocks
    factors = np.ones(blocks)
    if case["id"] == "linear_up":
        factors = .5 + centers
    elif case["id"] == "linear_down":
        factors = 1.5 - centers
    elif case["id"] == "high_error":
        factors[:] = 1.5
    elif case["id"] == "pulse":
        factors[(centers >= 1 / 3) & (centers < 2 / 3)] = rng.uniform(1.5, 2.5)
    cal_factors = factors.copy()
    if not case["matched"]:
        factors[:] = .75
        cal_factors[:] = 1.0
    cal = np.stack([scaled_matrix(case["base_matrix"], x) for x in cal_factors])
    sci = np.stack([scaled_matrix(case["base_matrix"], x) for x in factors])
    return cal, sci, factors


def simulate_pair(pilot, design, case, namespace, phase, trial):
    # Neither arm nor design enters the world RNG. All competitors see the
    # same physical-path draw, evaluated at their own block centers.
    cal_path, science_path, factors = response_path(case, design["blocks"], rng_for(namespace, phase, case["id"], trial, "world"))
    results = {}
    for arm in ARMS:
        rng = rng_for(namespace, phase, case["id"], design["id"], trial, arm, "observations")
        cal = np.zeros((4, 4), dtype=np.int64)
        sci = {p: np.zeros(4, dtype=np.int64) for p in POPULATIONS}
        plan = design["arms"][arm]
        for block in range(design["blocks"]):
            for state, size in enumerate(plan["calibration"]):
                cal[:, state] += rng.multinomial(size, cal_path[block, :, state])
            for pop in POPULATIONS:
                q = science_path[block] @ pilot["targets"][pop]["probabilities"]
                sci[pop] += rng.multinomial(plan["science"][pop], q / q.sum())
        cal_box = assignment_box(cal, .05 / 4)
        populations = {}
        for pop in POPULATIONS:
            low, high, status = full_matrix_interval(cal_box, measured_tail_box(sci[pop], .05 / 8))
            target = pilot["targets"][pop]["target_g2"]
            populations[pop] = {"counts": sci[pop].tolist(), "lower": float(low),
                                "upper": float(high) if np.isfinite(high) else None, "status": status,
                                "call": bool(status == "ok" and high < 1),
                                "target_covered": bool(status == "ok" and low <= target <= high)}
        signal, control = (populations[p] for p in POPULATIONS)
        results[arm] = {"calibration_counts": cal.tolist(), "populations": populations,
                        "joint_success": bool(signal["call"] and not control["call"] and control["target_covered"]),
                        "control_false_call": control["call"], "all_targets_covered": all(p["target_covered"] for p in populations.values())}
    return {"trial": trial, "world_sha256": digest({"base": case["base_matrix"], "factors": factors.tolist(), "matched": case["matched"]}),
            "arms": results, "family_all_targets_covered": all(r["all_targets_covered"] for r in results.values())}


def run_batch(task):
    if execution_source_hashes() != task["source_sha256"]:
        raise ValueError("Execution source changed after this study began")
    path = Path(task["path"])
    spec = {k: task[k] for k in ("config_sha256", "phase", "case", "design", "start", "count")}
    key = digest(spec)
    if path.exists():
        batch = json.loads(path.read_text())
        body = {k: v for k, v in batch.items() if k != "result_sha256"}
        if batch.get("spec_sha256") != key or digest(body) != batch.get("result_sha256") or len(batch["trials"]) != task["count"]:
            raise ValueError(f"Cached batch differs or is damaged: {path}")
        return {"path": str(path), "reused": True}
    trials = [simulate_pair(task["pilot"], task["design"], task["case"], task["config_sha256"], task["phase"], t)
              for t in range(task["start"], task["start"] + task["count"])]
    if execution_source_hashes() != task["source_sha256"]:
        raise ValueError("Execution source changed while this batch was running")
    batch = {**spec, "spec_sha256": key, "provenance": "synthetic_offline", "trials": trials,
             "actual_hardware_jobs": 0, "actual_hardware_shots": 0}
    batch["result_sha256"] = digest(batch)
    atomic_json(path, batch)
    return {"path": str(path), "reused": False}
