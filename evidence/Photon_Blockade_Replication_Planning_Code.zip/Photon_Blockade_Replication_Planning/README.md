# Offline planning of a repeated allocation comparison

The completed hardware pilot was a tie on joint success: both allocations detected the nominal-label signal and retained a control interval containing one. This package asks how many **fresh independent paired experiments**, at which shot budget and block count, would be needed for a meaningful comparison. It uses the completed pilot as development input and does not count it as confirmatory replication.

**Everything here runs locally. No API key, IBM connection, hardware submission, or RUs are used.** The included input is your already completed, verified 32-job result archive. NumPy and SciPy are the only required packages. The full simulations are for you to run on your computer.

## Bash commands

Extract `Photon_Blockade_Replication_Planning_Code.zip`, then open a terminal in its parent directory:

```bash
cd Photon_Blockade_Replication_Planning
python3 -m pip install -r requirements.txt
bash run.sh --smoke --workers 4
```

After the local smoke finishes, run the full offline study:

```bash
bash run.sh --workers 4
```

The bash wrapper limits numerical-library threads per worker to avoid oversubscription. It uses the `python3` from your active environment. To select a different Python executable explicitly, set `PHOTON_PYTHON`:

```bash
PHOTON_PYTHON=python bash run.sh --workers 4
```

The smoke is deliberately small and forces a diagnostic choice to exercise the complete workflow; it never recommends hardware. Its success criterion is that the workflow completes and saves valid files, not that its statistical goals pass. The full study is substantially longer than the smoke and reports batch progress. It uses CPU processes; GPUs are not needed.

Upload the full result archive:

```text
replication_planning_results/Photon_Blockade_Replication_Planning_Results.zip
```

## What is fixed and what is searched

The reference and selected allocation proportions, signal/control generating distributions, and primary per-pair confidence code remain frozen. At the original budget and 16 blocks the counts reproduce the hardware pilot exactly. Smaller budgets use deterministic integer apportionment, at least one 64-shot unit per calibration/science category, and a fixed charge of six padding PUBs per arm/block. The resulting proportions can differ slightly after rounding and minimum counts; every exact count is exported.

The default grid contains 21 candidates: 25%, 37.5%, 50%, 62.5%, 75%, 87.5%, or 100% of the prior pair's shot budget, with 4, 8, or 16 blocks. Within each candidate the two arms have exactly matched acquired shots and share one calibration job then one science job per block. The future repetition grid is 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, or 256 complete paired experiments.

Planning uses 256 simulated pairs per candidate/model cell. Seven matched-response cases are considered: stationary, increasing/decreasing error, high error, a shared pulse, and two persistent calibration-uncertainty sensitivity worlds. Each uncertainty matrix is drawn once and fixed across all trials and phases of that case; sampling uncertainty is not turned into physical drift. The pulse's jointly varying height is an explicit stress assumption, not an inferred noise path. These cases do not exhaust possible calibration uncertainty or real device behavior.

## Criteria and validation

One future observation is a complete paired experiment, not a block or a histogram row. The planned comparison is a single one-sided exact McNemar test at alpha=0.05 for greater joint-success probability in the selected arm. Its future replication count is fixed before acquisition; there is no sequential testing or optional stopping.

The planning search seeks the smallest estimated total RU cost that meets, in every listed matched case:

- At least 80% full-study comparison power, using a conservative Monte Carlo lower bound.
- At least 80% selected-arm joint-success probability per paired experiment, using a lower bound.
- Planning point-rate screens for false control calls at most 1% in either arm and family target coverage at least 95%.

The candidate and its future pair count are frozen before independent validation. Validation uses 1,024 new simulated pairs per matched case. It applies simultaneous Monte Carlo bounds to **all** of those goals, including the false-control and coverage goals. A separate calibration/science mismatch case is diagnostic and never selects a design or validates nominal coverage.

The complete full scan has 37,632 planning pairs. If a candidate qualifies, validation and the diagnostic add 8,192 pairs. These are synthetic CPU simulations, not hardware shots. Resumable batches contain 32 simulated pairs each.

**No eligible candidate, failed independent validation, and an unaffordable candidate are valid results.** The code does not force a hardware recommendation. A passing model result remains conditional on the supplied response models and is not measured hardware power.

## Resource target

The default target of **10 RUs for the entire future series** is a planning assumption, not your current balance or a reservation. The output reports whether the selected series fits this target and whether it fits the previously estimated remaining 1.13 RUs. Costs use the larger of a fit to the completed pilot's pending RU metrics and the generic timing approximation. They are not hard caps.

You can change the planning target explicitly:

```bash
bash run.sh --workers 4 --resource-target-ru 10 --out planning_target10
```

Changing this option changes the study fingerprint and requires a new output directory. The resource target does not alter the statistical eligibility criteria; an over-target statistical candidate is reported as unaffordable. This program never launches a hardware run, even if the goals pass. Changing shot budgets or block counts would require a separate hardware collector revision and schedule review.

## Resume and reproducibility

Rerun exactly the same command after interruption. Completed batches are hash-checked and reused. You may change `--workers` while resuming. Keep the original code, input, and statistical settings for the same output folder; changed settings require a new `--out` folder. Source integrity is checked before and after simulated batches and before selection/final scoring. The future hardware pair count is not changed after validation is inspected.

Optional developer checks, also local:

```bash
python3 verify_planning.py
```

The included verification record checks the exact paired-test calculation against an independent trinomial enumeration, null rejection probabilities, the original allocation/count/resource identities, simulation phase independence, persistent uncertainty worlds, cache corruption detection, and planning-only selection. Workflow verification covers the bash entry point, multiprocessing, resume, archive hashes, and the no-eligible branch. No full scientific grid is run remotely for you.

`METHODS.md` details the assumptions and formulas. The source package includes the original result archive, exact frozen collector/inference sources, and an input audit. Result ledgers record synthetic provenance and zero new hardware usage. `SOURCE_SHA256SUMS` covers this delivered package.
