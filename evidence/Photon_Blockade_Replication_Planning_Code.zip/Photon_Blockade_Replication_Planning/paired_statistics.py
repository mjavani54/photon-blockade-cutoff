"""Exact one-sided paired binary test and finite-Monte-Carlo planning bounds."""

from functools import lru_cache

import numpy as np
from scipy.stats import beta, binom


def lower_binomial(count, size, tail_alpha):
    return 0.0 if count == 0 else float(beta.ppf(tail_alpha, count, size - count + 1))


def upper_binomial(count, size, tail_alpha):
    return 1.0 if count == size else float(beta.ppf(1 - tail_alpha, count + 1, size - count))


def paired_pvalue(selected_only, reference_only):
    """Directional exact McNemar: selected has a higher joint-success rate."""
    if min(selected_only, reference_only) < 0:
        raise ValueError("Discordance counts cannot be negative")
    size = selected_only + reference_only
    return 1.0 if size == 0 else float(binom.sf(selected_only - 1, size, .5))


@lru_cache(maxsize=64)
def critical_wins(maximum_pairs, test_alpha=.05):
    critical = np.full(maximum_pairs + 1, maximum_pairs + 1, dtype=int)
    for discordant in range(1, maximum_pairs + 1):
        wins = np.arange(discordant + 1)
        accepted = wins[binom.sf(wins - 1, discordant, .5) <= test_alpha]
        if accepted.size:
            critical[discordant] = int(accepted[0])
    critical.setflags(write=False)
    return critical


def paired_test_power(selected_only_probability, reference_only_probability, pairs, test_alpha=.05):
    """Exact finite-study rejection probability for iid paired outcomes."""
    win, loss = float(selected_only_probability), float(reference_only_probability)
    if pairs < 1 or min(win, loss) < 0 or win + loss > 1 + 1e-12 or not 0 < test_alpha < 1:
        raise ValueError("Invalid paired-power parameters")
    discordance = min(1.0, win + loss)
    if discordance == 0 or win == 0:
        return 0.0
    d = np.arange(pairs + 1)
    conditional = binom.sf(critical_wins(pairs, test_alpha) - 1, d, win / discordance)
    result = np.sum(binom.pmf(d, pairs, discordance) * conditional)
    return float(np.clip(result, 0, 1))


def cell_counts(trials):
    # Cells indexed (reference success, selected success).
    cells = {"both_fail": 0, "selected_only": 0, "reference_only": 0, "both_success": 0}
    for trial in trials:
        ref = trial["arms"]["reference_allocation"]["joint_success"]
        sel = trial["arms"]["selected_allocation"]["joint_success"]
        key = "both_success" if ref and sel else "reference_only" if ref else "selected_only" if sel else "both_fail"
        cells[key] += 1
    return cells


def study_power_bounds(cells, pairs, tail_alpha, test_alpha=.05):
    """Power monotonicity plus two one-sided exact binomial bounds.

    Simultaneous coverage for these two endpoints is at least 1-2*tail_alpha.
    A larger family of models/endpoints is handled by the caller's alpha split.
    """
    size = sum(cells.values())
    if size < 1:
        raise ValueError("No Monte Carlo pairs")
    wins, losses = cells["selected_only"], cells["reference_only"]
    wl = lower_binomial(wins, size, tail_alpha)
    wh = upper_binomial(wins, size, tail_alpha)
    ll = lower_binomial(losses, size, tail_alpha)
    lh = upper_binomial(losses, size, tail_alpha)
    # Enforce the probability simplex while retaining the worst/most optimistic
    # componentwise bounds. The rejection region increases in wins and decreases
    # in losses, so these give valid conservative power bounds.
    pessimistic_loss = min(lh, 1 - wl)
    optimistic_win = min(wh, 1 - ll)
    return {"mc_pairs": size, **cells, "planned_hardware_pairs": pairs,
            "selected_only_probability": wins / size, "reference_only_probability": losses / size,
            "paired_success_rate_difference": (wins - losses) / size,
            "study_power_plugin": paired_test_power(wins / size, losses / size, pairs, test_alpha),
            "study_power_lower_bound": paired_test_power(wl, pessimistic_loss, pairs, test_alpha),
            "study_power_upper_bound": paired_test_power(optimistic_win, ll, pairs, test_alpha),
            "selected_only_probability_lower": wl, "reference_only_probability_upper": lh,
            "lower_power_mc_tail_alpha_per_endpoint": tail_alpha}
