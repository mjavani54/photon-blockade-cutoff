"""Verify the supplied numerical records without rerunning cavity simulations."""

import csv
from hashlib import sha256
import json
import math
from pathlib import Path
from collections import Counter
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def same(a, b):
    assert math.isfinite(float(a)) and math.isfinite(float(b))
    assert math.isclose(float(a), float(b), rel_tol=2e-10, abs_tol=2e-13), (a, b)


def maximum(rows, field):
    row = max(rows, key=lambda r: r[field])
    return {"case_key": row["case_key"], "value": row[field]}


def main():
    archive = HERE / "input/Photon_Blockade_Physics_Audit_Results.zip"
    expected = json.loads((HERE / "expected_protocol.json").read_text())
    sparse_cache = json.loads((HERE / "sparse_cache_m4.json").read_text())
    with ZipFile(archive) as z:
        assert z.testzip() is None, "ZIP CRC error"
        names = z.namelist()
        assert len(names) == len(set(names)), "Duplicate ZIP entries"
        assert all(not Path(n).is_absolute() and ".." not in Path(n).parts for n in names)
        file_hashes = json.loads(z.read("result_sha256.json"))
        assert set(names) == set(file_hashes) | {"result_sha256.json"}
        for name, want in file_hashes.items():
            assert sha256(z.read(name)).hexdigest() == want, name
        config = json.loads(z.read("config.json"))
        assert config == expected, "Run does not match the delivered default full protocol"
        reported = json.loads(z.read("verification_summary.json"))
        assert reported == json.loads((HERE / "input/verification_summary.json").read_text())
        archived_evidence = json.loads(z.read("archived_evidence/existing_evidence_audit.json"))
        checks = [json.loads(z.read(n)) for n in names if n.startswith("checks/") and n.endswith(".json")]
    config_sha = digest(config)
    expected_checks = {(r["kind"], r["record"]["key"]): r["record"] for r in expected["checks"]}
    actual_checks = {(r["kind"], r["record"]["key"]): r for r in checks}
    assert len(checks) == 225 and len(actual_checks) == 225
    assert set(actual_checks) == set(expected_checks)
    references, independent, reductions = [], [], []
    for row in checks:
        assert row["status"] == "completed" and row["actual_new_hardware_jobs"] == 0
        assert row["provenance"] == "classical_numerical_audit"
        assert row["record"] == expected_checks[(row["kind"], row["record"]["key"])]
        assert row["settings"] == config["settings"] and row["config_sha256"] == config_sha
        spec = {k: row[k] for k in ("kind", "record", "settings", "config_sha256")}
        assert row["spec_sha256"] == digest(spec)
        assert row["result_sha256"] == digest({k: v for k, v in row.items() if k != "result_sha256"})
        r, source = row["result"], row["record"]
        assert r["case_key"] == source["key"]
        if row["kind"] == "reference":
            assert r["reference_cutoffs_checked"] == [source["reference_cutoff"] + 4, source["reference_cutoff"] + 8]
            assert max(r["reference_cutoffs_checked"]) <= config["settings"]["reference_cap"]
            assert r["new_high_reference_mean"] > 0 and r["new_high_reference_g2"] >= 0
            same(r["old_to_high_scaled_g2"], abs(source["reference_g2"] - r["new_high_reference_g2"]) / max(1., r["new_high_reference_g2"]))
            same(r["old_to_high_relative_mean"], abs(source["reference_mean"] - r["new_high_reference_mean"]) / r["new_high_reference_mean"])
            error = abs(source["selected_g2"] - r["new_high_reference_g2"]) / max(1., source["selected_g2"])
            same(error, r["selected_cutoff_scaled_error_against_high"])
            assert r["rule_pass_against_high"] == (error <= .025)
            assert r["archived_rule_pass"] == source["original_cutoff_pass"]
            metrics = [r[k] for k in ("old_to_high_scaled_g2", "new_pair_scaled_g2", "old_to_high_relative_mean", "new_pair_relative_mean")]
            assert all(math.isfinite(v) and v >= 0 for v in metrics)
            assert r["higher_reference_check_passed"] == (max(metrics) <= 2e-6)
            assert r["higher_reference_check_passed"]
            if source["cohort"] == "followup":
                assert r["rule_pass_against_high"]
            if not source["parameters"]["couplings"]:
                p = source["parameters"]
                mu = p["drive"] ** 2 / (.25 + p["cavity_detuning"] ** 2)
                analytic = r["analytic_control"]
                same(mu, analytic["mean"])
                same(abs(r["new_high_reference_g2"] - 1), analytic["g2_error"])
                same(abs(r["new_high_reference_mean"] / mu - 1), analytic["relative_mean_error"])
                assert r["analytic_control_passed"] and max(analytic[k] for k in ("g2_error", "relative_mean_error", "total_variation")) <= 2e-6
            references.append({"case_key": source["key"], "cohort": source["cohort"], "group": source["group"], **r})
        elif row["kind"] in ("dense", "integration"):
            assert r["cutoff"] == 4 and r["independent_method"] == row["kind"]
            d = r["independent_diagnostics"]
            p = d["probabilities"]
            assert len(p) == 5 and all(math.isfinite(v) for v in p)
            mean = sum(n * v for n, v in enumerate(p))
            g2 = sum(n * (n-1) * v for n, v in enumerate(p)) / mean ** 2
            same(mean, d["mean"]); same(g2, d["g2"])
            sparse = sparse_cache[source["key"]]
            # An independent comparison with archived finite-cutoff distributions.
            # This does not recompute the stationary linear systems.
            l1 = sum(abs(a-b) for a, b in zip(sparse["probabilities"], p, strict=True))
            gd = abs(sparse["g2"] - g2) / max(1., sparse["g2"])
            md = abs(sparse["mean"] - mean) / sparse["mean"]
            same(l1, r["photon_probability_l1_difference"])
            same(gd, r["scaled_g2_difference"])
            same(md, r["relative_mean_difference"])
            assert max(l1, r["photon_probability_l1_difference"]) <= 2e-7
            assert max(gd, md, r["scaled_g2_difference"], r["relative_mean_difference"]) <= 2e-6
            assert d["residual_max"] <= 1e-7 and d["trace_error"] <= 1e-8 and d["hermiticity_error"] <= 1e-8
            assert d["minimum_density_eigenvalue"] >= -1e-8 and r["independent_solver_check_passed"]
            if row["kind"] == "integration":
                assert d["final_time"] == 600. and d["derivative_evaluations"] > 0
            independent.append({"case_key": source["key"], "method": row["kind"],
                                "probability_l1": r["photon_probability_l1_difference"],
                                "scaled_g2_difference": r["scaled_g2_difference"],
                                "relative_mean_difference": r["relative_mean_difference"],
                                "residual_max": d["residual_max"], "minimum_density_eigenvalue": d["minimum_density_eigenvalue"]})
        else:
            assert row["kind"] == "reduction" and r["decoupled_reduction_passed"]
            assert r["decoupled_emitter_probability_l1_difference"] <= 1e-9
            reductions.append(r)
    assert Counter(r["kind"] for r in checks) == {"reference": 217, "dense": 5, "integration": 2, "reduction": 1}
    worst = maximum(references, "old_to_high_scaled_g2")
    reconstructed = {"schema_version": 1, "mode": "full", "status": "checks_passed", "reference_cases_checked": 217,
                     "independent_dense_checks": 5, "independent_time_integrations": 2, "decoupled_emitter_checks": 1,
                     "failures": [], "worst_reference_g2_shift": worst["value"],
                     "followup_guard_failures_against_larger_reference": 0, "actual_new_hardware_jobs": 0,
                     "actual_resource_units_used": 0, "interpretation": reported["interpretation"]}
    assert reported == reconstructed
    fresh = [r for r in references if r["cohort"] == "followup" and r["group"] in ("broad", "polariton", "strong_drive")]
    assert len(fresh) == 192 and all(r["rule_pass_against_high"] for r in fresh)
    initial_misses = [r for r in references if r["cohort"] == "initial" and not r["rule_pass_against_high"]]
    assert {r["case_key"] for r in initial_misses} == {"initial:S037", "initial:M037"}
    controls = [r for r in references if "analytic_control" in r]
    assert len(controls) == 10
    findings = {"status": "verified", "archive_sha256": sha256(archive.read_bytes()).hexdigest(),
                "archive_members": len(names), "file_hashes_verified": len(file_hashes), "record_hashes_verified": len(checks),
                "protocol_and_source_hashes_match_delivered_code": True, "separately_uploaded_summary_matches_archive": True,
                "summary_reconstructed_from_records": True, "reference_cases": len(references),
                "followup_reference_cases": sum(r["cohort"] == "followup" for r in references),
                "initial_stress_reference_cases": sum(r["cohort"] == "initial" for r in references),
                "worst_reference_g2_shift": worst, "reference_tolerance": 2e-6,
                "reference_tolerance_to_worst_shift_ratio": 2e-6 / worst["value"],
                "worst_new_pair_g2_shift": maximum(references, "new_pair_scaled_g2"),
                "worst_reference_mean_shift": maximum(references, "old_to_high_relative_mean"),
                "worst_new_pair_mean_shift": maximum(references, "new_pair_relative_mean"),
                "new_guard_cases": len(fresh), "new_guard_passes": sum(r["rule_pass_against_high"] for r in fresh),
                "new_guard_worst_scaled_error": maximum(fresh, "selected_cutoff_scaled_error_against_high"),
                "original_known_misses_retained": [{"case_key": r["case_key"], "scaled_error": r["selected_cutoff_scaled_error_against_high"]} for r in initial_misses],
                "independent_dense_checks": 5, "time_integrations": 2, "decoupled_reduction_checks": 1,
                "empty_cavity_analytic_controls": len(controls),
                "independent_max_probability_l1": max(r["probability_l1"] for r in independent),
                "independent_max_scaled_g2_difference": max(r["scaled_g2_difference"] for r in independent),
                "independent_max_relative_mean_difference": max(r["relative_mean_difference"] for r in independent),
                "independent_max_residual": max(r["residual_max"] for r in independent),
                "empty_control_max_total_variation": max(r["analytic_control"]["total_variation"] for r in controls),
                "actual_new_hardware_jobs": 0, "actual_resource_units_used": 0,
                "new_steady_state_solves_in_this_analysis": 0,
                "limits": ["The default full protocol covers 15 initial stress cases, not every initial case at larger new references.",
                           "Small reference changes and solver agreement are empirical numerical evidence, not a universal truncation bound.",
                           "Dense and time-integration comparisons are at finite cutoff m=4.",
                           "The archive stores numerical summaries rather than full density matrices at the larger cutoffs.",
                           "The new two-emitter cases are paired and structured; zero misses is not an iid population guarantee."]}
    (HERE / "analysis_summary.json").write_text(json.dumps(findings, indent=2) + "\n")
    (HERE / "historical_evidence.json").write_text(json.dumps(archived_evidence, indent=2) + "\n")
    columns = ["case_key", "cohort", "group", "reference_cutoffs_checked", "old_to_high_scaled_g2", "new_pair_scaled_g2",
               "old_to_high_relative_mean", "new_pair_relative_mean", "selected_cutoff_scaled_error_against_high", "rule_pass_against_high"]
    with (HERE / "reference_checks.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=columns); w.writeheader()
        for r in sorted(references, key=lambda r: r["case_key"]): w.writerow({k: r[k] for k in columns})
    with (HERE / "independent_checks.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(independent[0])); w.writeheader(); w.writerows(independent)
    print(json.dumps(findings, indent=2))


if __name__ == "__main__":
    main()
