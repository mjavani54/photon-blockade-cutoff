# Full photon-cutoff physics verification: analysis

The uploaded default full run passes its predeclared numerical verification protocol. The archive is complete, its checksums verify, and the separately uploaded summary agrees with the archived summary. The numerical evidence supports the empirical cutoff-transfer result on the tested cases. It does not establish a universal truncation bound or quantum advantage.

## Results

| Check | Result |
| --- | --- |
| Larger-reference cases | 217/217 pass |
| Coverage of those reference cases | All 202 follow-up records plus 15 initial stress points |
| Independent dense stationary comparisons | 5/5 pass at photon cutoff m=4 |
| Direct density-matrix time integrations | 2/2 pass at m=4 and final time 600 |
| Decoupled-emitter reduction | 1/1 pass |
| Empty-cavity analytic controls | 10/10 pass; included in the 217 reference cases |
| Verification failures | None |
| New hardware jobs / RUs | 0 / 0 |

The largest archived-to-larger-reference scaled g2 change is **1.5968780089448403e-7**, for `initial:C081`, compared with the **2e-6** tolerance. It is about 8.0% of that tolerance. The maximum relative mean-photon-number change is **3.033117154697205e-8**, also for `initial:C081`. The larger-to-larger reference changes have the same maxima. These are numerical consistency checks, not bounds on every possible omitted Hilbert-space contribution.

Across the five dense and two time-integration comparisons, the maximum photon-probability L1 difference is **1.8415581559683147e-12**, maximum scaled g2 difference is **1.0908096946819188e-13**, and maximum relative mean difference is **1.1512105471799959e-14**. The maximum reported independent stationary residual is **1.822121538810238e-11**. All meet their predeclared thresholds. The empty-cavity controls have maximum Poisson total variation **4.305727086023848e-16**.

## Consequence for cutoff transfer

All **192 new two-emitter cases** selected by the revised guard still pass against the larger references. The worst scaled error is **0.016826563522709153** (1.6826563523%), for `followup:strong_drive-002-unequal`, against the 0.025 (2.5%) budget. The original archived worst value was 0.016826562999418523; the larger-reference check does not materially change the conclusion.

The original rule remains **238/240** on its original two-emitter test set. Its two historical misses are retained, rather than reclassified as successes:

| Original-rule case | Scaled error against the larger reference |
| --- | ---: |
| initial:S037 | 0.02539626895155114 |
| initial:M037 | 0.025138620966805098 |

Those rule violations are expected historical outcomes, not failures of the numerical-verification protocol. The revised guard passes both known-miss diagnostic points. Its **192/192** new-case result is reported separately from those two recovery checks. The guard requires an extra photon-register qubit in **14/192** new cases. The result is a measured reliability/cost tradeoff, not a cost-free improvement.

The scaled error is `abs(g2_selected - g2_reference) / max(1, g2_selected)`. Below g2=1, the 0.025 budget is an absolute g2 error of 0.025. It should not be described uniformly as a 2.5% relative error.

## What was independently checked in this analysis

The review verified ZIP integrity and **230 file hashes**, all **225 individual check-record hashes**, each record's specification hash and configuration identity, and the exact case list and parameters against the delivered code's default full protocol. The source-code and original-input fingerprints match that delivered version. The delivered code archive SHA-256 is `dd12681f4b276044873755c47be5d72e7e3a39398e4e2e6f54285c57b8ebd3a6`.

The uploaded results archive SHA-256 is `53ae929c577c77752b4c5b9f47e9f982d8b9b438ad72fd17f1b88aebd71ec1bf`.

The summary was reconstructed from the individual records, rather than accepted on its own. Selected-cutoff errors were recalculated from the saved larger-reference moments. For the dense and integration checks, moments were recomputed from the saved independent photon probabilities and compared against archived sparse m=4 distributions. Saved numerical diagnostic flags and reference changes were checked against the declared tolerances. No new steady-state grids or hardware experiments were run during this review.

## Limits and next step

This is the default full protocol, not the optional `--all-pilot` extension. It checks all follow-up records and 15 initial stress points at larger references. The previous cached-data audit covers all 436 initial cases, but the present run does not compute new larger references for every initial case. There is no failure in this result that requires a blanket rerun.

The dense and time-integration implementations are compared at a common finite cutoff m=4; agreement there validates implementation consistency, not the infinite-dimensional physics by itself. The larger-reference records contain moments and diagnostics rather than complete density matrices. This review checks those saved records and does not independently repeat their linear solves.

The new cases are paired and structured. Zero observed misses is descriptive evidence on those families, not an independent-binomial guarantee for arbitrary cavities. The guard was designed after inspecting the initial misses. Keep that chronology explicit in the methods and keep the original failures visible.

The next step is to consolidate the manuscript and reproducibility package around the empirical cutoff/shot-planning contribution. Preserve the original and revised-rule results as separate stages, include the guard's register cost, and distinguish the classical cavity calculations from the later hardware readout/allocation demonstration. This audit addresses the numerical reproducibility concern; publication novelty still needs a clear argument against prior work. Additional processor collection is not required to close this numerical-verification stage.

## Reproduce this review

With Python 3.10 or newer, run from this folder:

```bash
python3 analyze_results.py
```

This uses only the Python standard library, reads the unchanged uploaded files under `input/`, and regenerates `analysis_summary.json`, `historical_evidence.json`, `reference_checks.csv`, and `independent_checks.csv`. `expected_protocol.json` was reconstructed from the previously delivered code and frozen input archives; `sparse_cache_m4.json` contains the five archived finite-cutoff distributions used for the independent probability comparisons. The full record-level input archive is included so the review remains reproducible.
