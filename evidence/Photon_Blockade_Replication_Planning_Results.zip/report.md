# Offline replication planning

**Model-based planning only; no IBM jobs or RUs were used.**

The prior hardware pilot was used as development input. Its two successful arms are not counted as new confirmatory replications. The common response model uses pooled calibration counts only; the allocation fractions and generating distributions stay frozen. Model changes, shot budgets, block counts, and future independent replication are being planned, not retrospectively validated on that hardware pilot.

## Candidate

Frozen candidate `b04_u0594` uses 304,128 acquired shots and 8 shared physical jobs per paired experiment, repeated 64 times. Estimated series usage is 130.608 RUs, using the larger of the two per-pair planning estimates. Cost-target fit: False (target 10.00 RUs). This is not a hard usage cap.

Selection status: `selected_on_planning_simulations_only`. Independent validation uses new observation and physical-path streams after the choice, including the replication count, is frozen. Matched-model goals met: **True**. Worst validation lower bound for full-study test power: 0.9234054381487532. Smallest validation lower bound for the selected arm's per-pair joint success: 0.8517207794237236. Largest validation upper bound for either arm's false-control probability: 0.0034223938682366685. Smallest validation lower bound for simultaneous target coverage in a paired experiment: 0.9965776061317634.

## Statistical target

The primary future test is one directional exact McNemar test at alpha=0.05: the selected allocation has higher joint-success probability than the reference. One observation is a complete independently randomized paired allocation experiment, not a block or histogram row. The future pair count is fixed before collection; there is no repeated testing or outcome-dependent stopping. Full-study comparison power must be at least 0.80; the selected arm's per-pair joint-success probability must also be at least 0.80. The false-control cap per arm is 0.010, and paired family-coverage goal is 0.95 in every listed matched model.

Repeated-study rejection probabilities are computed exactly from simulated discordance probabilities. The code uses conservative one-sided exact binomial bounds for Monte Carlo uncertainty. For a fixed validation choice, four discordance bounds (lower/upper endpoints for both probabilities), two control-call bounds, one selected-joint-success bound, and one family-coverage bound per matched case share total Monte Carlo error 0.05 by a union bound. This is simulation uncertainty conditional on the models, not coverage over unknown physical response models. The minimum/maximum across the specified cases is not a guarantee over every possible channel.

## Model and resource limits

The calibration-derived posterior sensitivity matrices are drawn once per case and remain fixed across all designs, phases, trials, and future repetitions within that case. They are persistent unknown-response alternatives, not independent per-block drift or fresh epistemic draws for each future repetition. Finite sensitivity draws do not exhaust calibration uncertainty. Explicit linear/high-error/pulse paths are stress assumptions, not measured drift. The pulse height varies jointly for both arms across simulated pairs by a predeclared physical-path model. Calibration/science matching holds within each modeled block; the separate mismatch case is diagnostic and never selects a winner or certifies coverage.

Each future pair models two distinct calibration datasets and two populations per arm in one shared calibration/science job pair per block. Arm observations are independent conditional on the shared response path. Acquisition costs include 64-shot rounding, at least one unit per analyzed category, and six padding PUBs per arm/block. Changing block counts changes calibration cadence; the old 16-block hardware schedule cannot execute these designs unchanged. Timing/history effects beyond these models are not included. The nominal marginal count simulation is exact for the stated block-fixed independent mixture model; padding is charged without simulating its discarded outcomes.

Empirical RU estimates extrapolate this pilot's pending metrics; generic estimates assume one preparation overhead per physical job. Neither accounts for every server chunk, future timing change, or plan multiplier. RUs of shared jobs are counted once. The 10.00-RU resource target is an editable planning assumption, not a verified balance or reserved allowance. Any hardware collection needs a separately reviewed schedule and an actual current balance.

The primary interval code is unchanged and reuses family alpha=0.05 within each pair. That is separate from alpha=0.05 for the future between-allocation comparison. A nominal type-I guarantee for comparing the binary recorded outcomes does not prove physical cutoff accuracy or calibration response matching. The benchmark uses X-only nominal number labels and does not implement cavity dynamics.

## Files

`candidate_designs.csv` gives exact counts and per-pair costs; `planning_study_grid.csv` gives every candidate/pair-count score. `selection_frozen.json` records the choice and planning hashes before validation. `simulation_summary.csv`, `validation_study_power.csv`, and `validation_summary.json` record results, including null/ineligible outcomes. `batches/` preserves all simulated counts and decisions with integrity hashes and independent phase/trial keys. `config.json` and `pilot_model.json` retain the full input/source/config fingerprint and verified model inputs.
