"""Plot independent model-validation results; no hardware access."""

import csv
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

HERE=Path(__file__).resolve().parent
NAMES={'stationary':'Stationary','linear_up':'Increasing error','linear_down':'Decreasing error',
       'pulse':'Pulse','high_error':'High error','persistent_uncertainty_01':'Persistent uncertainty 01',
       'persistent_uncertainty_02':'Persistent uncertainty 02'}


def main():
    with (HERE/'validation_case_comparison.csv').open(newline='',encoding='utf-8') as stream:
        rows=list(csv.DictReader(stream))
    plt.rcParams.update({'font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
    fig,(ax,powerax)=plt.subplots(1,2,figsize=(9.2,5.0),sharey=True)
    for i,row in enumerate(rows):
        ref=float(row['reference_joint_success']);sel=float(row['selected_joint_success']);lo=float(row['selected_joint_lower_bound'])
        ax.plot(ref,i-.12,'o',color='#3778A7',markersize=5,label='Reference point estimate' if i==0 else None)
        ax.hlines(i+.12,lo,sel,color='#9B4F96',linewidth=2)
        ax.vlines(lo,i+.07,i+.17,color='#9B4F96',linewidth=1.2)
        ax.plot(sel,i+.12,'o',color='#9B4F96',markersize=5,label='Selected point estimate and lower bound' if i==0 else None)
        point=float(row['future64_comparison_power_plugin'])
        lower=float(row['future64_comparison_power_lower_bound']);upper=float(row['future64_comparison_power_upper_bound'])
        powerax.errorbar(point,i,xerr=[[max(0,point-lower)],[max(0,upper-point)]],fmt='o',color='#27877B',capsize=4,markersize=5,linewidth=2)
    for panel in (ax,powerax):
        panel.axvline(.8,color='#777777',linestyle='--',linewidth=1)
        panel.xaxis.set_major_formatter(PercentFormatter(1))
        panel.grid(axis='x',alpha=.18)
    ax.set(xlim=(.25,1.015),ylim=(-.5,len(rows)-.5),xlabel='Joint-success probability',title='A  Per-pair model success')
    ax.set_yticks(range(len(rows)),[NAMES[row['case']] for row in rows])
    ax.invert_yaxis()
    powerax.set(xlim=(.79,1.005),xlabel='Power of the fixed future 64-pair test',title='B  Model-based comparison power')
    powerax.set_xticks([.8,.85,.9,.95,1.0])
    fig.suptitle('Refined four-block plan passes independent model validation',fontsize=12,fontweight='semibold',y=.985)
    handles,labels=ax.get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.925),ncol=2,fontsize=8,frameon=False)
    fig.text(.5,.025,'2,048 independent validation simulations per matched case. Whiskers show conservative MC bounds.\nDashed lines: 80% goals. Conditional model probabilities; no new hardware data.\nThe proposed 64-pair hardware series remains uncollected and over the 10-RU resource target.',ha='center',fontsize=8,color='#444444')
    fig.tight_layout(rect=(0,.16,1,.84))
    fig.savefig(HERE/'refined_validation.png',dpi=300,bbox_inches='tight')
    fig.savefig(HERE/'refined_validation.pdf',bbox_inches='tight')
    plt.close(fig)


if __name__=='__main__':
    main()
