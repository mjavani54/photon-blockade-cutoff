# Refined replication planning: independently validated model goals

## Decision

The refined study selected the **four-block half-budget candidate `b04_u0594` with 64 future complete paired experiments**. That choice was frozen on planning simulations and passed independent validation in all seven specified matched-response model cases.

**The statistical model goals passed. The proposed hardware series remains above the 10-RU resource target and has not been collected.** Keep hardware collection paused and preserve the current result as a completed model-based planning study. Further tuning of this same comparison is not needed to establish that these particular conditional model goals pass.

## Independent validation

There are 2,048 fresh validation pairs per matched case, for 14,336 validation pairs in total. None of these are new hardware measurements.

| Validation quantity | Goal | Conservative bound across the seven cases |
| --- | --- | ---: |
| Power of the frozen future 64-pair allocation comparison | At least 80% | Lower bound **92.3405%** |
| Selected allocation's joint-success probability per paired experiment | At least 80% | Lower bound **85.1721%** |
| False-control probability in either arm per paired experiment | At most 1% | Upper bound **0.34224%** |
| All four generating targets covered in one paired experiment | At least 95% | Lower bound **99.6578%** |

The power bound is most restrictive in persistent calibration-uncertainty case 01. Selected joint success is most restrictive in the high-error case. The bounds account for finite Monte Carlo uncertainty using the original exact-binomial bounds and family error split across eight probability endpoints per matched case. They are conditional on the modeled observations and response paths; they do not cover every unknown physical noise model or prove empirical hardware power.

Observed point rates in the independent validation simulations were:

| Model case | Reference joint success | Selected joint success | Lower bound on future 64-pair test power |
| --- | ---: | ---: | ---: |
| Stationary | 77.98% | 98.93% | 93.26% |
| Increasing error | 76.90% | 98.83% | 94.89% |
| Decreasing error | 77.39% | 98.88% | 94.67% |
| Pulse | 34.96% | 88.09% | 99.999% |
| High error | 32.03% | 87.60% | 99.999% |
| Persistent uncertainty 01 | 77.88% | 98.88% | 92.34% |
| Persistent uncertainty 02 | 74.71% | 99.22% | 98.57% |

The selected-minus-reference joint-success differences range from 20.95 to 55.57 percentage points in these simulation point estimates. Using the same simultaneous discordance bounds, the smallest conservative lower bound on that difference is **17.29 percentage points**. This quantifies a conditional model-based advantage; it is not a measured hardware improvement.

There were zero observed control false calls and zero observed paired family noncoverage events in each matched validation case. Zero observed events do not imply zero probability. The separate mismatch diagnostic also had no observed false control calls or noncoverage events, but was excluded from selection and all nominal-goal certification. A favorable result in that one mismatch stress does not validate arbitrary calibration/science mismatch or drift.

## Frozen proposed experiment and resource requirement

One proposed paired experiment has four blocks. Each block would use one shared calibration job followed by one shared science job, with distinct outcomes for the two arms. The allocation per block is:

| Category | Reference | Selected |
| --- | ---: | ---: |
| Calibration 00 | 3,264 | 11,264 |
| Calibration 01 | 3,136 | 7,104 |
| Calibration 10 | 3,072 | 384 |
| Calibration 11 | 3,072 | 128 |
| Signal science | 12,544 | 14,080 |
| Control science | 12,544 | 4,672 |
| Extra acquired science outcomes | 384 | 384 |

Per complete pair, acquisition is **304,128 shots in eight physical jobs**: 152,064 acquired and 150,528 analyzed outcomes per arm. The total predeclared exclusions are 3,072 outcomes per pair. This is half the acquisition of the preceding full hardware pair, but that reduction is a proposed model-based design, not demonstrated hardware shot savings.

For 64 fresh complete paired experiments:

| Resource | Proposed total |
| --- | ---: |
| Physical jobs | 512 |
| Acquired shots | 19,464,192 |
| Analyzed shots | 19,267,584 |
| Predeclared extra outcomes excluded | 196,608 |
| Estimate from prior recorded RU metrics | 110.185344 RUs |
| Generic timing estimate used for planning | 130.607787 RUs |
| Planning target | 10 RUs |

The planning estimate is about **13.1 times** the 10-RU target. Each pair's two estimates are 1.721646 and 2.040747 RUs. They are extrapolations from provisional prior metrics and a generic timing formula, not guaranteed consumption bounds. Larger shared jobs can change server partitioning and overhead. Shared physical job costs are counted once, not once per arm.

The eight-job proposed collector has not been implemented or run by this planning package. The preceding fixed hardware collector used sixteen blocks and cannot execute this design unchanged. A funded hardware study would need a concrete collector/schedule review, fixed 64-pair acquisition and analysis rules, a current verified allowance, and no outcome-dependent stopping. A handful of additional pairs would provide further feasibility observations, but would not execute the validated 64-pair comparison.

## Integrity, provenance, and phase separation

Input: `Photon_Blockade_Replication_Planning_Results(1).zip`; SHA-256 `e2ad9e553238201092f5f4fb92443a393998fdb964319734ee97e706b5330e9b`.

The archive has 970 members and 960 batches: 448 planning, 448 validation, and 64 diagnostic. It contains 14,336 planning pairs, 14,336 independent validation pairs, and 2,048 diagnostic pairs, or **30,720 simulated pairs in total**. No IBM jobs or RUs were used for this study or its review.

The audit checked archive CRCs, all supplied output/batch hashes, exact source and config fingerprints, the canonical calibration-derived pilot model, regenerated candidate designs/cases, every saved calibration/science count total, every endpoint flag, and all trial IDs. Binary pair outcomes were independently recounted. Recomputing selection using planning data alone reproduced the candidate and 64-pair count. Every original summary table, frozen choice, status JSON, and report reproduced byte for byte. Nine stratified numerical records across all three phases reproduced exactly from their random-stream definitions; the entire simulation grid was not rerun during review.

Archive file timestamps place completion of planning before the frozen selection and validation after it, consistent with the original program's phase order. These timestamps are consistency metadata, not an independent external timestamp attestation. The inference about phase separation also relies on the audited source, explicit phase/config random-stream namespaces, and planning-only reproduction of selection.

This refinement used a different complete config fingerprint from the earlier broad grid, so its observation/path streams are fresh. The same calibration-derived sensitivity cases persist as fixed nuisance alternatives. The original broader search and this targeted refinement are development history; neither makes the existing hardware pilot a confirmatory repeated comparison.

## Claims supported and next step

| Claim | Current evidence |
| --- | --- |
| The chosen plan passes the stated power, selected-success, control, and coverage goals in the seven response models | Supported by independently validated Monte Carlo calculations and reproduced audit |
| The selected allocation improves model joint-success probability at the matched half-shot budget | Supported conditionally by the fresh validation simulations |
| A powered confirmatory hardware comparison fits a 10-RU series target | Unsupported; estimated cost is about 130.6 RUs |
| Hardware superiority or 50% hardware shot savings have been demonstrated | Unsupported; the completed hardware evidence remains one full-budget paired feasibility pilot |
| These X-only measurements directly demonstrate physical photon blockade or one-to-two-emitter cavity dynamics | Unsupported by this benchmark; those physics claims require the separate cavity simulations |

**Recommended next step:** freeze this result and consolidate the paper's evidence. Review the numerical photon-cutoff and one-emitter/two-emitter transfer results, their hold-out design, and truncation-error accounting. Tie each manuscript claim to its actual data source. The hardware pilot can support implementation feasibility; the present refined study can support conditional allocation and prospective resource claims. A substantially funded fresh hardware series would be needed for the proposed empirical superiority claim.

A suitable summary of this branch is: calibration-derived models and independent Monte Carlo validation support a four-block, matched-half-shot allocation comparison with a fixed 64-pair design; its conservative worst-case comparison-power lower bound exceeds 92%, but the confirmatory hardware series was not executed because its estimated RU requirement exceeds the available planning target. This statement should accompany the model assumptions and the limited scope of the existing hardware pilot.

## Reproduce the review

`review_verification.json` records every audit result and replay specification. `validation_case_comparison.csv` contains the derived comparison data. Original numeric tables and the frozen choice are copied unchanged. The figure is available in PNG and PDF, with its plotting script.

With the previously supplied planner code and its NumPy/SciPy requirements:

```bash
python3 review_refined.py \
  "/path/to/Photon_Blockade_Replication_Planning_Results(1).zip" \
  --planner-code "/path/to/Photon_Blockade_Replication_Planning"
```

Run ordinary Python without `-O`, which would disable audit assertions. Plotting additionally requires Matplotlib. The original uploaded archive is unchanged and is not duplicated into this analysis package. `SHA256SUMS` covers the delivered analysis files.
