"""Offline audit of the completed two-candidate refined planning study."""

import argparse
from collections import Counter
import csv
from hashlib import sha256
import io
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from zipfile import ZipFile


def check_trial(trial, design, pilot):
    family = True
    for arm, ar in trial["arms"].items():
        plan = design["arms"][arm]
        cal = ar["calibration_counts"]
        assert len(cal) == 4 and all(len(row) == 4 and all(isinstance(n, int) and n >= 0 for n in row) for row in cal)
        assert [sum(cal[i][j] for i in range(4)) for j in range(4)] == [design["blocks"] * n for n in plan["calibration"]]
        for population, result in ar["populations"].items():
            assert sum(result["counts"]) == design["blocks"] * plan["science"][population]
            assert all(isinstance(n, int) and n >= 0 for n in result["counts"])
            target = pilot["targets"][population]["target_g2"]
            high = float("inf") if result["upper"] is None else result["upper"]
            assert result["call"] == (result["status"] == "ok" and high < 1)
            assert result["target_covered"] == (result["status"] == "ok" and result["lower"] <= target <= high)
        signal, control = (ar["populations"][p] for p in ("signal", "control"))
        assert ar["joint_success"] == (signal["call"] and not control["call"] and control["target_covered"])
        assert ar["control_false_call"] == control["call"]
        assert ar["all_targets_covered"] == all(p["target_covered"] for p in ar["populations"].values())
        family = family and ar["all_targets_covered"]
    assert trial["family_all_targets_covered"] == family


def review(archive, planner_code, output):
    archive, planner_code, output = (Path(p).resolve() for p in (archive, planner_code, output))
    sys.path.insert(0, str(planner_code))
    from planning_model import digest, make_design, model_cases, simulate_pair, load_pilot
    from run_replication_planning import aggregate, freeze_selection, summarize, source_hashes
    output.mkdir(parents=True, exist_ok=True)
    with ZipFile(archive) as z:
        names = z.namelist()
        assert len(names) == len(set(names)) and z.testzip() is None
        hashes = json.loads(z.read("result_sha256.json"))
        assert set(hashes) == set(names) - {"result_sha256.json"}
        for name, expected in hashes.items():
            assert sha256(z.read(name)).hexdigest() == expected, name
        config = json.loads(z.read("config.json"))
        pilot = json.loads(z.read("pilot_model.json"))
        selection = json.loads(z.read("selection_frozen.json"))
        status = json.loads(z.read("validation_summary.json"))
        assert config["source_sha256"] == source_hashes()
        assert digest(config) == selection["config_sha256"] == status["config_sha256"]
        current = load_pilot(planner_code / "input" / "Photon_Blockade_Allocation_Validation_Batched_Results.zip")
        assert digest(pilot) == digest(current)
        assert config["selection_cases"] == model_cases(pilot, config["seed"], 2)
        assert not config["smoke"] and config["planning_trials"] == 1024 and config["validation_trials"] == 2048
        assert len(config["designs"]) == 2 and len(config["selection_cases"]) == 7
        designs = {d["id"]: d for d in config["designs"]}
        for d in designs.values():
            assert d == make_design(pilot, .5, d["blocks"])
        chosen = selection["choice_design"]
        assert chosen == designs["b04_u0594"] and selection["choice"]["hardware_pairs"] == 64
        assert not selection["selection_uses_validation"]
        mismatch = {"id": "local_drop_mismatch", "base_matrix": pilot["empirical_matrix"], "matched": False, "kind": "diagnostic_only"}
        cases = {c["id"]: c for c in config["selection_cases"]}
        cases[mismatch["id"]] = mismatch
        batch_names = [n for n in names if n.startswith("batches/")]
        assert len(batch_names) == 960
        batch_phase = Counter()
        trial_phase = Counter()
        cells = {}
        for name in batch_names:
            batch = json.loads(z.read(name))
            phase = batch["phase"]
            assert phase in ("planning", "validation", "diagnostic")
            assert batch["config_sha256"] == digest(config)
            spec = {k: batch[k] for k in ("config_sha256", "phase", "case", "design", "start", "count")}
            assert batch["spec_sha256"] == digest(spec)
            assert batch["result_sha256"] == digest({k: v for k, v in batch.items() if k != "result_sha256"})
            assert batch["case"] == cases[batch["case"]["id"]] and batch["design"] == designs[batch["design"]["id"]]
            assert batch["actual_hardware_jobs"] == batch["actual_hardware_shots"] == 0
            assert [t["trial"] for t in batch["trials"]] == list(range(batch["start"], batch["start"] + batch["count"]))
            if phase == "diagnostic":
                assert batch["case"] == mismatch
            else:
                assert batch["case"]["matched"]
            if phase != "planning":
                assert batch["design"] == chosen
            key = phase, batch["case"]["id"], batch["design"]["id"]
            cells.setdefault(key, []).extend(batch["trials"])
            batch_phase[phase] += 1
            trial_phase[phase] += len(batch["trials"])
            for trial in batch["trials"]:
                check_trial(trial, batch["design"], pilot)
        assert dict(batch_phase) == {"planning": 448, "validation": 448, "diagnostic": 64}
        assert dict(trial_phase) == {"planning": 14336, "validation": 14336, "diagnostic": 2048}
        assert len(cells) == 22
        for (phase, _, _), trials in cells.items():
            trials.sort(key=lambda t: t["trial"])
            expected = config["planning_trials"] if phase == "planning" else config["validation_trials"]
            assert [t["trial"] for t in trials] == list(range(expected))
        planned_cases = config["selection_cases"]
        with TemporaryDirectory(prefix="refined_planning_review_") as temporary:
            folder = Path(temporary)
            for name in names:
                relative = Path(name)
                assert not relative.is_absolute() and ".." not in relative.parts
                target = folder / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(name))
            plan_rows = [aggregate(folder, config, "planning", c, d) for c in planned_cases for d in config["designs"]]
            validation_rows = [aggregate(folder, config, "validation", c, chosen) for c in planned_cases]
            diagnostic_rows = [aggregate(folder, config, "diagnostic", mismatch, chosen)]
            for row in plan_rows + validation_rows + diagnostic_rows:
                counts = Counter((bool(t["arms"]["reference_allocation"]["joint_success"]), bool(t["arms"]["selected_allocation"]["joint_success"]))
                                 for t in cells[row["phase"], row["case"], row["design"]])
                for pair, key in (((False, False), "both_fail"), ((False, True), "selected_only"),
                                  ((True, False), "reference_only"), ((True, True), "both_success")):
                    assert row[key] == counts[pair]
            assert freeze_selection(folder, config, planned_cases, config["designs"], plan_rows) == selection
            assert summarize(folder, config, pilot, selection, plan_rows, validation_rows, diagnostic_rows) == status
            outputs = ("planning_study_grid.csv", "selection_frozen.json", "simulation_summary.csv",
                       "validation_summary.json", "validation_study_power.csv", "report.md")
            for name in outputs:
                assert (folder / name).read_bytes() == z.read(name), name
        replays = []
        specifications = [("planning", "stationary", chosen["id"], 0),
                          ("planning", "persistent_uncertainty_02", "b08_u0297", 1023),
                          ("planning", "pulse", chosen["id"], 511),
                          ("validation", "stationary", chosen["id"], 0),
                          ("validation", "pulse", chosen["id"], 1023),
                          ("validation", "high_error", chosen["id"], 2047),
                          ("validation", "persistent_uncertainty_01", chosen["id"], 511),
                          ("diagnostic", "local_drop_mismatch", chosen["id"], 0),
                          ("diagnostic", "local_drop_mismatch", chosen["id"], 2047)]
        for phase, case_id, design_id, trial_id in specifications:
            actual = simulate_pair(pilot, designs[design_id], cases[case_id], digest(config), phase, trial_id)
            assert actual == cells[phase, case_id, design_id][trial_id]
            replays.append({"phase": phase, "case": case_id, "design": design_id, "trial": trial_id})
        validation_power = list(csv.DictReader(io.StringIO(z.read("validation_study_power.csv").decode())))
        by_case = {r["case"]: r for r in validation_power}
        rates = []
        for row in validation_rows:
            power = by_case[row["case"]]
            rates.append({"case": row["case"], "mc_pairs": row["mc_pairs"],
                          "reference_joint_success": row["reference_joint_rate"], "selected_joint_success": row["selected_joint_rate"],
                          "selected_joint_lower_bound": row["selected_joint_lower_bound"],
                          "joint_success_difference": row["selected_joint_rate"] - row["reference_joint_rate"],
                          "difference_mc_lower_bound": float(power["selected_only_probability_lower"]) - float(power["reference_only_probability_upper"]),
                          "future64_comparison_power_plugin": float(power["study_power_plugin"]),
                          "future64_comparison_power_lower_bound": float(power["study_power_lower_bound"]),
                          "future64_comparison_power_upper_bound": float(power["study_power_upper_bound"]),
                          "selected_control_false_upper_bound": row["selected_control_false_upper_bound"],
                          "reference_control_false_upper_bound": row["reference_control_false_upper_bound"],
                          "family_coverage_lower_bound": row["family_coverage_lower_bound"]})
        selection_time = z.getinfo("selection_frozen.json").date_time
        chronology = (max(z.getinfo(n).date_time for n in batch_names if n.startswith("batches/planning/"))
                      <= selection_time <= min(z.getinfo(n).date_time for n in batch_names if n.startswith("batches/validation/")))
        assert chronology and status["matched_model_goals_met"] and not status["ready_for_hardware_schedule_review"]
        pairs = selection["choice"]["hardware_pairs"]
        summary = {"status": "passed", "input_archive_sha256": sha256(archive.read_bytes()).hexdigest(),
                   "archive_members": len(names), "batch_counts_by_phase": dict(batch_phase),
                   "trial_counts_by_phase": dict(trial_phase), "total_simulated_pairs": sum(trial_phase.values()),
                   "all_hashes_source_config_model_and_count_invariants": "passed",
                   "all_summary_outputs_reproduced_byte_for_byte": True,
                   "planning_only_choice_and64_pair_count_reproduced": True,
                   "archive_file_times_consistent_with_freeze_before_validation": chronology,
                   "chronology_limit": "Archive timestamps are consistency metadata, not an external timestamp attestation.",
                   "stratified_numeric_replays": replays, "independent_validation_cases": len(rates),
                   "matched_model_goals_met": status["matched_model_goals_met"],
                   "worst_validation_study_power_lower_bound": status["minimum_validation_study_power_lower_bound"],
                   "worst_validation_selected_joint_lower_bound": status["minimum_validation_selected_joint_lower_bound"],
                   "largest_validation_control_false_upper_bound": status["maximum_validation_control_false_upper_bound"],
                   "smallest_validation_family_coverage_lower_bound": status["minimum_validation_family_coverage_lower_bound"],
                   "worst_validation_difference_lower_bound": min(r["difference_mc_lower_bound"] for r in rates),
                   "planned_hardware_pairs": pairs, "future_physical_jobs": pairs * chosen["physical_jobs_per_pair"],
                   "future_acquired_shots": pairs * chosen["acquired_shots_per_pair"],
                   "future_empirical_estimate_ru": pairs * chosen["usage_estimates_per_pair"]["empirical_ru"],
                   "future_generic_estimate_ru": pairs * chosen["usage_estimates_per_pair"]["generic_ru"],
                   "within10ru_target": status["within_resource_target"],
                   "actual_new_hardware_jobs_during_review": 0, "actual_resource_units_used": 0}
        (output / "review_verification.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        with (output / "validation_case_comparison.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rates[0]))
            writer.writeheader(); writer.writerows(rates)
        for name in ("candidate_designs.csv", "planning_study_grid.csv", "selection_frozen.json", "simulation_summary.csv",
                     "validation_summary.json", "validation_study_power.csv"):
            (output / name).write_bytes(z.read(name))
        print(json.dumps({k: v for k, v in summary.items() if k != "stratified_numeric_replays"}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("--planner-code", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    review(args.archive, args.planner_code, args.out)
