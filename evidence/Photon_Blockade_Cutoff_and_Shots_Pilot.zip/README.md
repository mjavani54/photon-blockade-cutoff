# Photon cutoff and shot budgets for cavity QED

This pilot tests whether a photon cutoff rule calibrated on a driven Jaynes–Cummings cavity transfers to a driven Tavis–Cummings cavity with two emitters. The observable is the steady-state intracavity second-order correlation at zero delay,

$$g^{(2)}(0)=\frac{\langle n(n-1)\rangle}{\langle n\rangle^2}.$$

The study uses classical Lindblad steady states and independent photon measurements with ideal readout. Photon qubit counts describe a binary encoding of the cavity levels.

## Pilot results

The proposal used the frozen one-emitter multiplier $\lambda=1.64599$ and passed the cutoff budget on 64/64 held-out one-emitter cases. Both two-emitter cohorts used that same multiplier.

| Cutoff selection on 240 two-emitter cases | Cases within cutoff budget | Worst scaled error | Cases using four photon qubits |
| --- | ---: | ---: | ---: |
| Fixed cutoff $m=3$ | 139 | 54.45% | 0 |
| Boundary probability | 206 | 91.11% | 38 |
| Adjacent change | 238 | 12.81% | 27 |
| Adjacent change and pair weight | 238 | 2.54% | 6 |

The proposed rule passed 119/120 cases in each two-emitter cohort. Both misses, `S037` and `M037`, were bunched states at $\eta=0.80$, $\Delta_c=0$, $G=0.9$, and base emitter decay $\gamma=0.38$. The selected $m=7$ gave scaled errors of 2.540% and 2.514%. The next cutoff, $m=8$, gave errors of 1.076% and 1.086% using one additional photon qubit.

The prospective shot criterion passed at or below $10^8$ shots for 143/240 two-emitter cases and at or below $10^6$ shots for 69/240. The median among cases with a passing plan was 1,258,925 shots. All 36,608 simulated batches with passing plans achieved the total error target against the reference, and 36,595 simultaneously covered the finite-cutoff value and met the width criterion. Of the 97 cap-limited cases, 22 met the width target in at least 95% of the simulated batches at the cap. The shot plan is a conservative sufficiency criterion.

Twelve of 14 two-emitter cases with reference $g^{(2)}(0)<0.9$ yielded an antibunching call in at least 95% of batches at their assigned or capped shot count. There were zero antibunching calls in 55,552 two-emitter batches with reference $g^{(2)}(0)\ge1$. The 3,072 empty-cavity batches yielded three false antibunching calls, all in cases where the prospective shot criterion was unmet at the cap.

A separate dense time integration of the two-emitter master equation from the vacuum-ground state to $t\kappa=300$ agreed with the sparse stationary photon distribution within $5.3\times10^{-15}$ at a spot-check point. Adding a decoupled second emitter reproduced the one-emitter photon distribution to $1.2\times10^{-16}$. The data contain 436 cases and 6,989 finite-cutoff photon distributions. The transfer result applies to the parameter families and ideal sampling model described below.

## Reproduce the results

Use Python 3.10 or newer in the extracted project directory. The frozen calibration file records the exact NumPy and SciPy versions used for the supplied run.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python run_study.py --stage calibrate --workers 4 --out rerun
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python run_study.py --stage validate --workers 4 --out rerun
python plot_results.py --results rerun
```

Use fewer workers on machines with limited memory. The validation stage checks the calibration CSV checksum and numerical settings before applying the saved rule.

## Physical model and test cases

Set the cavity photon loss rate $\kappa=1$ and use units of $\kappa$ for frequencies, couplings, drives, and decay rates. Detunings are mode or emitter frequency minus drive frequency. Write $a$ for the cavity annihilation operator and $\sigma_i^-$ for the lowering operator of emitter $i$.

$$
H=\Delta_c a^\dagger a+\eta(a+a^\dagger)
+\sum_i\big[\Delta_i\sigma_i^+\sigma_i^-+g_i(a^\dagger\sigma_i^-+a\sigma_i^+)\big],
\qquad
\dot\rho=-i[H,\rho]+\mathcal D[a]\rho+\sum_i\gamma_i\mathcal D[\sigma_i^-]\rho.
$$

Here $\mathcal D[L]\rho=L\rho L^\dagger-\{L^\dagger L,\rho\}/2$. The emitter losses are independent and the bath is at zero temperature. Solve the vectorized stationary equation with unit trace. Each solve checks the stationary residual, trace, Hermiticity, and positivity of the density matrix.

- **One-emitter calibration, 120 cases.** The product grid uses $G=g\in\{0.9,2,3.5\}$, $\gamma\in\{0.12,0.38\}$, $\eta\in\{0.025,0.075,0.20,0.45,0.80\}$ and $\Delta_c/G\in\{0,1/\sqrt{2},\sqrt{3}/2,1\}$. The bare emitter and cavity frequencies agree.
- **One-emitter holdout, 64 cases.** The bare emitter is detuned from the cavity by $\pm 0.16G$. This cohort uses intermediate couplings, drive strengths and drive detunings from the factory in `run_study.py`.
- **Two identical emitters, 120 cases.** The same grid of $G,\gamma,\eta,\Delta_c$ has equal emitter couplings $G/\sqrt{2}$, cavity-matched emitter frequencies, and decay $\gamma$ per emitter.
- **Two mismatched emitters, 120 cases.** At each matched grid point the couplings are $(\sqrt{0.75}G,0.50G)$, the bare emitter detunings from the cavity are $(-0.30G,+0.25G)$, and the emitter decays are $(0.80\gamma,1.20\gamma)$.
- **Empty cavity, 12 controls.** A coherent drive and vacuum loss give the analytic values $g^{(2)}(0)=1$ and $\bar n=\eta^2/(1/4+\Delta_c^2)$. The numerical reference is checked against both. Restricting the register to $\{0,1\}$ gives $g^{(2)}(0)=0$ for all of these controls.

For the reference, begin at photon cutoff 12 and increase it by two until the most recent two solutions agree within $2\times10^{-6}$ in scaled $g^{(2)}$ and relative $\bar n$. The maximum reference cutoff is 24. The reference is used for calibration and for evaluation. Per-case decisions on the held-out sets use the adjacent-cutoff data and the fixed calibration parameters.

## Cutoff rule

Let $m$ be the largest retained photon number, $g_m$ the corresponding $g^{(2)}(0)$, $\bar n_m$ the mean photon number, and $p^{(m)}_n$ the photon populations. Use the scale $s_m=\max(1,g_m)$. The target end-to-end error is $0.10s_m$, split into $0.025s_m$ for cutoff and $0.075s_m$ for sampling. This keeps an absolute tolerance in the antibunched regime and uses a relative scale for highly bunched states.

For each trial cutoff, compute the adjacent change and the contribution of the newly admitted Fock level to the higher-cutoff correlation:

$$
D_m=\frac{1}{s_m}\max\left(
|g_{m+1}-g_m|,\;
\frac{m(m+1)p^{(m+1)}_{m+1}}{\bar n_{m+1}^2}
\right).
$$

With $\delta=2\times 10^{-6}$ and $e_m=|g_m-g_{\rm ref}|/s_m$, fit $\lambda=\max(1,\max_{\rm cal}(e_m+\delta)/(D_m+\delta))$ across all calibration cases and candidate cutoffs. Choose the smallest $m\in\{2,\ldots,15\}$ with $\lambda(D_m+\delta)\le 0.025$. The one-level lookahead is a classical pilot solve. The measurement stage uses only levels $0,\ldots,m$ and a photon register of $\lceil\log_2(m+1)\rceil$ qubits. The multiplier is an empirical safeguard calibrated over the supplied parameter grid.

The adjacent-change baseline uses the same calibration formula with just $|g_{m+1}-g_m|/s_m$. The boundary-probability baseline tests $p^{(m+1)}_{m+1}$ against the smallest such probability observed among one-emitter candidates failing the cutoff target. The fixed cutoff baseline always uses $m=3$.

## Shot rule and confidence intervals

For the selected cutoff, let $t_j=P(n\ge j)$. The moments satisfy

$$
\bar n=\sum_{j=1}^m t_j,\qquad
\langle n(n-1)\rangle=2\sum_{j=2}^m(j-1)t_j.
$$

The $j$th tail count from $S$ shots has a binomial distribution with parameters $S,t_j$. Construct exact Clopper–Pearson intervals with tail error $0.05/(2m)$ on each side. Bonferroni's inequality gives at least 95% simultaneous coverage across tails. Summing the lower and upper bounds for the two moments gives $[\nu_L/\mu_U^2,\nu_U/\mu_L^2]$ for $g_m$. When $\mu_L=0$, the upper limit is infinite. A zero observed two-photon count still yields a positive upper bound on its probability.

For planning, use the selected classical photon distribution to enclose each prospective tail count between its binomial quantiles at $0.05/(2m)$ and $1-0.05/(2m)$. All counts lie in this band with probability at least 95% under the pilot distribution. Using the lower and upper count extremes in the same interval calculation conservatively bounds the width. Select the first shot count on the grid from $10^3$ to $10^8$ with width at most $0.15s_m$. If none passes, report a cap-limited case and sample at $10^8$ for diagnosis.

Draw 256 independent batches per case with a cutoff. Use each interval midpoint as the estimate of $g_m$. The two 95% statements give at least 90% probability of simultaneous coverage and width attainment under the selected model for shot plans that meet the width criterion. The end-to-end precision statement additionally requires the empirical cutoff error to be within budget. Expand each measured interval by $0.025s_m$ on each side for a decision about the reference. An upper limit below one indicates antibunching, and a lower limit above one indicates bunching.

## Files

| File | Contents |
| --- | --- |
| `results/rule.json` | Frozen calibration parameters, settings, seed, and calibration checksum |
| `results/calibration_cases.csv` and `results/validation_cases.csv` | Physical parameters, references, selected cutoffs, shot counts, and batch results |
| `results/calibration_cutoffs.csv` and `results/validation_cutoffs.csv` | Photon distributions and diagnostics at every solved cutoff |
| `results/summary.json` | Group-level outcomes and frozen rule checksum |
| `results/two_emitter_transfer.png` | Comparison of cutoff error and shot requirements on the two-emitter cases |

The scaled-error columns divide by $\max(1,g_m)$ for the evaluated cutoff. A value of `shot_plan_feasible=0` with `shots=100000000` means the prospective width criterion was unmet on the shot grid. Batch totals remain available for those cases. A cutoff of $m=2$ still requires two photon qubits. Empty fields indicate an unavailable decision or diagnostic.

## References

- Birnbaum et al., *Photon blockade in an optical cavity with one trapped atom*. [Nature, 2005](https://doi.org/10.1038/nature03804)
- Marinelli et al., *Photon blockade in a Tavis-Cummings system*. [Physical Review Applied, 2025](https://escholarship.org/uc/item/2bq581m7)
- *Digital quantum simulation of cavity quantum electrodynamics*. [Quantum Science and Technology, 2025](https://doi.org/10.1088/2058-9565/ae0af0)
- Etienney, Robin, and Rouchon, *A posteriori error estimates for the Lindblad master equation*. [Quantum, 2026](https://doi.org/10.22331/q-2026-03-16-2031)
- Clopper–Pearson binomial interval. [SciPy reference](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats._result_classes.BinomTestResult.proportion_ci.html)
