"""Calibrate on one emitter and evaluate the frozen rule on separate cases."""

import argparse
from concurrent.futures import ProcessPoolExecutor
import csv
from dataclasses import asdict
import hashlib
from itertools import product
import json
from math import ceil, log2, sqrt
from pathlib import Path
import platform
from statistics import median

import numpy as np
import scipy

from cavity import Case, solve_steady_state
from sampling import ALPHA, BATCHES, BETA, SHOT_GRID, SHOT_TOLERANCE, evaluate_shots, plan_shots


CUTOFF_TOLERANCE = 0.025
REFERENCE_TOLERANCE = 2e-6
MAX_CUTOFF = 15
MAX_REFERENCE = 24
RNG_SEED = 20261116


def settings():
    return {
        "cutoff_tolerance": CUTOFF_TOLERANCE,
        "reference_tolerance": REFERENCE_TOLERANCE,
        "maximum_candidate_cutoff": MAX_CUTOFF,
        "maximum_reference_cutoff": MAX_REFERENCE,
        "shot_grid": SHOT_GRID.tolist(),
        "shot_tolerance": SHOT_TOLERANCE,
        "alpha": ALPHA,
        "beta": BETA,
        "batches": BATCHES,
        "seed": RNG_SEED,
    }


def study_cases():
    calibration = []
    symmetric = []
    asymmetric = []
    grid = product(
        (0.9, 2.0, 3.5),
        (0.12, 0.38),
        (0.025, 0.075, 0.20, 0.45, 0.80),
        (0.0, 1 / sqrt(2), sqrt(3) / 2, 1.0),
    )
    for index, (g, gamma, drive, detuning_fraction) in enumerate(grid, 1):
        detuning = g * detuning_fraction
        pair_id = f"P{index:03d}"
        calibration.append(Case(
            f"C{index:03d}", "one_calibration", pair_id, drive, detuning,
            (g,), (detuning,), (gamma,),
        ))
        symmetric.append(Case(
            f"S{index:03d}", "two_identical", pair_id, drive, detuning,
            (g / sqrt(2),) * 2, (detuning,) * 2, (gamma,) * 2,
        ))
        asymmetric.append(Case(
            f"M{index:03d}", "two_mismatched", pair_id, drive, detuning,
            (sqrt(0.75) * g, 0.5 * g),
            (detuning - 0.30 * g, detuning + 0.25 * g),
            (0.8 * gamma, 1.2 * gamma),
        ))

    holdout = []
    grid = product(
        (1.25, 2.65), (0.04, 0.12, 0.32, 0.65), (0.0, 0.62, 0.78, 0.97), (-0.16, 0.16),
    )
    for index, (g, drive, detuning_fraction, offset) in enumerate(grid, 1):
        detuning = g * detuning_fraction
        holdout.append(Case(
            f"H{index:03d}", "one_holdout", "", drive, detuning,
            (g,), (detuning + offset * g,), (0.22,),
        ))

    controls = [
        Case(f"E{index:02d}", "empty", "", drive, detuning, (), (), ())
        for index, (drive, detuning) in enumerate(
            product((0.025, 0.04, 0.075, 0.20, 0.45, 0.80), (0.0, 0.65)), 1
        )
    ]
    return calibration, controls + holdout + symmetric + asymmetric


def solve_case(case):
    states = {m: solve_steady_state(case, m) for m in range(1, MAX_CUTOFF + 2)}
    for cutoff in range(12, MAX_REFERENCE + 1, 2):
        if cutoff not in states:
            states[cutoff] = solve_steady_state(case, cutoff)
        current = states[cutoff]
        previous = states[cutoff - 2]
        g2_change = abs(current.g2 - previous.g2)
        scaled_change = g2_change / max(1.0, current.g2)
        mean_change = abs(current.mean - previous.mean) / current.mean
        if max(scaled_change, mean_change) <= REFERENCE_TOLERANCE:
            break
    else:
        raise ArithmeticError(f"No converged reference for {case.case_id}")

    reference_g2 = current.g2
    reference_mean = current.mean
    if not case.couplings:
        reference_g2 = 1.0
        reference_mean = case.drive**2 / (0.25 + case.cavity_detuning**2)
        if max(abs(current.g2 - 1), abs(current.mean / reference_mean - 1)) > REFERENCE_TOLERANCE:
            raise ArithmeticError(f"Empty-cavity analytic check failed for {case.case_id}")

    return {
        "case": case,
        "states": states,
        "reference_cutoff": cutoff,
        "reference_g2": reference_g2,
        "reference_mean": reference_mean,
        "reference_g2_step": g2_change,
        "reference_g2_scaled_step": scaled_change,
        "reference_mean_relative_step": mean_change,
        "reference_numerical_g2": current.g2,
        "reference_numerical_mean": current.mean,
    }


def cutoff_rows(solved):
    states = solved["states"]
    rows = []
    for cutoff, state in states.items():
        scale = max(1.0, state.g2)
        absolute_error = abs(state.g2 - solved["reference_g2"])
        row = {
            "case_id": solved["case"].case_id,
            "group": solved["case"].group,
            "cutoff": cutoff,
            "photon_qubits": ceil(log2(cutoff + 1)),
            "mean": state.mean,
            "g2": state.g2,
            "absolute_error": absolute_error,
            "g2_error_scale": scale,
            "scaled_error": absolute_error / scale,
            "probabilities": json.dumps(state.probabilities.tolist(), separators=(",", ":")),
            "stationary_residual": state.residual,
            "next_g2_change": "",
            "next_g2_scaled_change": "",
            "next_boundary_probability": "",
            "next_boundary_g2_term": "",
            "scaled_proposal_score": "",
        }
        if 2 <= cutoff <= MAX_CUTOFF:
            next_state = states[cutoff + 1]
            change = abs(next_state.g2 - state.g2)
            boundary_probability = next_state.probabilities[-1]
            boundary_g2_term = cutoff * (cutoff + 1) * boundary_probability / next_state.mean**2
            row.update(
                next_g2_change=change,
                next_g2_scaled_change=change / scale,
                next_boundary_probability=float(boundary_probability),
                next_boundary_g2_term=float(boundary_g2_term),
                scaled_proposal_score=float(max(change, boundary_g2_term) / scale),
            )
        rows.append(row)
    return rows


def calibrate(cutoffs):
    candidates = [row for row in cutoffs if row["scaled_proposal_score"] != ""]
    floor = REFERENCE_TOLERANCE
    return {
        "proposal_multiplier": max(
            1.0,
            max((row["scaled_error"] + floor) / (row["scaled_proposal_score"] + floor) for row in candidates),
        ),
        "difference_multiplier": max(
            1.0,
            max((row["scaled_error"] + floor) / (row["next_g2_scaled_change"] + floor) for row in candidates),
        ),
        "boundary_threshold": min(
            (row["next_boundary_probability"]
             for row in candidates if row["scaled_error"] > CUTOFF_TOLERANCE),
            default=1.0,
        ),
        "calibration_cases": len({row["case_id"] for row in cutoffs}),
        "settings": settings(),
        "runtime": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__},
    }


def score_case(solved, rows, rule):
    case = solved["case"]
    candidates = [row for row in rows if row["scaled_proposal_score"] != ""]
    floor = REFERENCE_TOLERANCE
    chosen = {
        "proposed": next((
            row for row in candidates
            if rule["proposal_multiplier"] * (row["scaled_proposal_score"] + floor) <= CUTOFF_TOLERANCE
        ), None),
        "difference": next((
            row for row in candidates
            if rule["difference_multiplier"] * (row["next_g2_scaled_change"] + floor) <= CUTOFF_TOLERANCE
        ), None),
        "boundary": next((
            row for row in candidates if row["next_boundary_probability"] < rule["boundary_threshold"]
        ), None),
        "fixed3": rows[2],
    }
    case_parameters = asdict(case)
    for key in ("couplings", "emitter_detunings", "emitter_decays"):
        case_parameters[key] = json.dumps(case_parameters[key], separators=(",", ":"))
    result = {
        **case_parameters,
        "emitters": len(case.couplings),
        "collective_coupling": sqrt(sum(g**2 for g in case.couplings)),
        **{key: value for key, value in solved.items() if key.startswith("reference_")},
        "one_photon_g2": solved["states"][1].g2,
    }
    for method, row in chosen.items():
        result[f"{method}_cutoff"] = row["cutoff"] if row else ""
        result[f"{method}_photon_qubits"] = row["photon_qubits"] if row else ""
        result[f"{method}_absolute_error"] = row["absolute_error"] if row else ""
        result[f"{method}_scaled_error"] = row["scaled_error"] if row else ""
        result[f"{method}_pass"] = int(row is not None and row["scaled_error"] <= CUTOFF_TOLERANCE)

    result.update(
        selected_g2="", selected_mean="", selected_pair_probability="", selected_scaled_error_proxy="",
        shots="", shot_plan_feasible=0, shot_plan_width_bound="", batches=0,
        batch_width_pass=0, batch_finite_coverage=0, batch_reference_coverage=0,
        batch_total_error_pass=0, batch_coverage_and_width_pass=0, batch_antibunching=0,
        batch_bunching=0, batch_zero_pairs=0,
    )
    if chosen["proposed"]:
        row = chosen["proposed"]
        state = solved["states"][row["cutoff"]]
        cutoff_budget = CUTOFF_TOLERANCE * row["g2_error_scale"]
        shot_budget = SHOT_TOLERANCE * row["g2_error_scale"]
        shots, feasible, width = plan_shots(state.probabilities, shot_budget)
        seed = np.random.SeedSequence([RNG_SEED, *case.case_id.encode("ascii")])
        result.update(
            selected_g2=state.g2,
            selected_mean=state.mean,
            selected_pair_probability=float(state.probabilities[2:].sum()),
            selected_scaled_error_proxy=rule["proposal_multiplier"] * (row["scaled_proposal_score"] + floor),
            shots=shots,
            shot_plan_feasible=int(feasible),
            shot_plan_width_bound=width,
            batches=BATCHES,
            **evaluate_shots(
                state.probabilities, shots, np.random.default_rng(seed),
                state.g2, solved["reference_g2"], cutoff_budget, shot_budget,
            ),
        )
    return result


def aggregate(rows):
    def describe(cohort):
        planned = [row for row in cohort if int(row["shot_plan_feasible"])]
        cases_with_batches = [row for row in cohort if int(row["batches"])]
        antibunched = [row for row in cohort if float(row["reference_g2"]) < 0.9]
        unblocked = [row for row in cohort if float(row["reference_g2"]) >= 1.0]
        total_planned = sum(int(row["batches"]) for row in planned)
        return {
            "cases": len(cohort),
            "cutoff": {
                method: {
                    "selected": sum(row[f"{method}_cutoff"] != "" for row in cohort),
                    "passes": sum(int(row[f"{method}_pass"]) for row in cohort),
                    "worst_scaled_error": max(
                        (float(row[f"{method}_scaled_error"])
                         for row in cohort if row[f"{method}_scaled_error"] != ""),
                        default=None,
                    ),
                    "median_cutoff": median([
                        int(row[f"{method}_cutoff"]) for row in cohort if row[f"{method}_cutoff"] != ""
                    ]) if any(row[f"{method}_cutoff"] != "" for row in cohort) else None,
                    "photon_qubit_counts": {
                        str(qubits): sum(str(row[f"{method}_photon_qubits"]) == str(qubits) for row in cohort)
                        for qubits in (2, 3, 4)
                    },
                }
                for method in ("proposed", "difference", "boundary", "fixed3")
            },
            "shot_count_certified_within_grid": len(planned),
            "shot_count_certified_within_one_million": sum(int(row["shots"]) <= 1_000_000 for row in planned),
            "median_certified_shots": median([int(row["shots"]) for row in planned]) if planned else None,
            "certified_batches": total_planned,
            "certified_batches_width_pass": sum(int(row["batch_width_pass"]) for row in planned),
            "certified_batches_finite_coverage": sum(int(row["batch_finite_coverage"]) for row in planned),
            "certified_batches_reference_coverage": sum(int(row["batch_reference_coverage"]) for row in planned),
            "certified_batches_total_error_pass": sum(int(row["batch_total_error_pass"]) for row in planned),
            "certified_batches_coverage_and_width_pass": sum(
                int(row["batch_coverage_and_width_pass"]) for row in planned
            ),
            "reference_g2_range": [min(float(row["reference_g2"]) for row in cohort),
                                  max(float(row["reference_g2"]) for row in cohort)],
            "reference_mean_range": [min(float(row["reference_mean"]) for row in cohort),
                                    max(float(row["reference_mean"]) for row in cohort)],
            "strong_antibunching_cases_g2_lt_0p9": len(antibunched),
            "strong_antibunching_cases_called_in_95pct_of_batches": sum(
                int(row["batch_antibunching"]) >= ceil(0.95 * BATCHES) for row in antibunched
            ),
            "non_antibunched_batches": sum(int(row["batches"]) for row in unblocked),
            "false_antibunching_batches": sum(int(row["batch_antibunching"]) for row in unblocked),
            "g2_reference_check_worst_scaled_step": max(float(row["reference_g2_scaled_step"]) for row in cohort),
            "reference_cutoff_max": max(int(row["reference_cutoff"]) for row in cohort),
            "sampled_batches": sum(int(row["batches"]) for row in cases_with_batches),
        }

    groups = {row["group"] for row in rows}
    summary = {group: describe([row for row in rows if row["group"] == group]) for group in sorted(groups)}
    summary["two_combined"] = describe([row for row in rows if int(row["emitters"]) == 2])
    return summary


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def solve_cohort(cases, workers):
    with ProcessPoolExecutor(max_workers=workers) as executor:
        results = []
        for index, solved in enumerate(executor.map(solve_case, cases, chunksize=1), 1):
            results.append(solved)
            if index % 20 == 0 or index == len(cases):
                print(f"Solved {index}/{len(cases)} cases", flush=True)
    return results


def score_cohort(solutions, cutoffs, rule):
    case_rows = [score_case(solved, rows, rule) for solved, rows in zip(solutions, cutoffs, strict=True)]
    return case_rows, [row for case in cutoffs for row in case]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("calibrate", "validate", "all"), default="all")
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--out", type=Path, default=Path("results"))
    args = parser.parse_args()
    if args.workers < 1:
        parser.error("--workers must be positive")
    args.out.mkdir(parents=True, exist_ok=True)
    calibration, validation = study_cases()
    calibration_path = args.out / "calibration_cases.csv"
    calibration_sweep = args.out / "calibration_cutoffs.csv"
    rule_path = args.out / "rule.json"
    if args.stage in ("calibrate", "all"):
        print("One-emitter calibration", flush=True)
        solutions = solve_cohort(calibration, args.workers)
        cutoffs = [cutoff_rows(solved) for solved in solutions]
        rule = calibrate([row for case in cutoffs for row in case])
        case_rows, sweep = score_cohort(solutions, cutoffs, rule)
        write_csv(calibration_path, case_rows)
        write_csv(calibration_sweep, sweep)
        rule["calibration_csv_sha256"] = hashlib.sha256(calibration_sweep.read_bytes()).hexdigest()
        rule_path.write_text(json.dumps(rule, indent=2) + "\n", encoding="utf-8")
        print(f"Frozen cutoff rule written to {rule_path}", flush=True)

    if args.stage in ("validate", "all"):
        rule = json.loads(rule_path.read_text(encoding="utf-8"))
        if rule["settings"] != settings() or rule["calibration_csv_sha256"] != hashlib.sha256(
            calibration_sweep.read_bytes()
        ).hexdigest():
            raise ValueError("Frozen rule settings or calibration data differ from the saved study")
        print("Empty-cavity controls and held-out emitter cases", flush=True)
        solutions = solve_cohort(validation, args.workers)
        case_rows, sweep = score_cohort(solutions, [cutoff_rows(solved) for solved in solutions], rule)
        write_csv(args.out / "validation_cases.csv", case_rows)
        write_csv(args.out / "validation_cutoffs.csv", sweep)
        with calibration_path.open(encoding="utf-8", newline="") as stream:
            calibration_rows = list(csv.DictReader(stream))
        summary = aggregate(calibration_rows + case_rows)
        summary["frozen_rule_sha256"] = hashlib.sha256(rule_path.read_bytes()).hexdigest()
        (args.out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        print(f"Validation complete. See {args.out / 'summary.json'}", flush=True)


if __name__ == "__main__":
    main()
