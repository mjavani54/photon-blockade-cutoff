"""Plot held-out two-emitter cutoff errors and shot budgets."""

import argparse
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import PercentFormatter
import numpy as np

from run_study import CUTOFF_TOLERANCE
from sampling import SHOT_GRID


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--results", type=Path, default=Path("results"))
    args = parser.parse_args()
    with (args.results / "validation_cases.csv").open(encoding="utf-8", newline="") as stream:
        rows = [row for row in csv.DictReader(stream) if row["emitters"] == "2"]

    plt.rcParams.update({
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.labelcolor": "#24313a",
        "axes.edgecolor": "#8b969c",
        "xtick.color": "#24313a",
        "ytick.color": "#24313a",
    })
    figure, (left, right) = plt.subplots(1, 2, figsize=(11.6, 4.65), layout="constrained")

    comparisons = (
        ("fixed3", "Fixed three-photon cutoff", "#848e97", (0, (2, 2))),
        ("boundary", "Boundary probability", "#b86035", (0, (5, 2))),
        ("difference", "Adjacent change", "#5464a3", (0, (5, 2, 1, 2))),
        ("proposed", "Adjacent change + pair weight", "#147a72", "-"),
    )
    for method, label, color, linestyle in comparisons:
        errors = sorted(float(row[f"{method}_scaled_error"]) for row in rows if row[f"{method}_cutoff"])
        display_errors = np.maximum(errors, 2e-6)
        fraction = np.arange(1, len(errors) + 1) / len(rows)
        left.step(display_errors, fraction, where="post", color=color,
                  linestyle=linestyle, linewidth=1.9, label=label)
    left.axvline(CUTOFF_TOLERANCE, color="#26313b", linewidth=1, linestyle=":", zorder=0)
    left.text(CUTOFF_TOLERANCE * 1.15, 0.06, "2.5% cutoff\nbudget", fontsize=9, color="#26313b")
    left.set(xscale="log", ylim=(0, 1.03),
             xlabel=r"Scaled cutoff error $|g_m-g_{\mathrm{ref}}|/\max(1,g_m)$",
             ylabel="Fraction of two-emitter cases")
    left.yaxis.set_major_formatter(PercentFormatter(1))
    left.grid(axis="y", alpha=0.18)
    left.set_title("a   Photon cutoff accuracy", loc="left", fontweight="bold", pad=12)
    left.legend(loc="lower right", facecolor="white", framealpha=0.97, edgecolor="none",
                fontsize=8.6, bbox_to_anchor=(1, 0.18))

    cutoff_rows = [row for row in rows if row["proposed_cutoff"]]
    status_colors = {True: "#147a72", False: "#b86035"}
    for antibunched, color in status_colors.items():
        cohort = [row for row in cutoff_rows if (float(row["reference_g2"]) < 1) == antibunched]
        for feasible in (False, True):
            subset = [row for row in cohort if bool(int(row["shot_plan_feasible"])) == feasible]
            mean = [float(row["selected_mean"]) for row in subset]
            shots = [int(row["shots"]) for row in subset]
            right.scatter(mean, shots, s=21 if feasible else 26,
                          marker="o" if feasible else "^",
                          edgecolors=color, facecolors=color if feasible else "none",
                          alpha=0.75, linewidths=0.85)
    right.axhline(SHOT_GRID[-1], color="#26313b", linestyle=":", linewidth=1, zorder=0)
    right.axhline(1_000_000, color="#acb5b8", linestyle="--", linewidth=0.9, zorder=0)
    right.set(xscale="log", yscale="log", ylim=(1.5e4, 2.2e8),
              xlabel=r"Mean photon number $\bar n$ at the selected cutoff", ylabel="Shots")
    right.yaxis.grid(alpha=0.18)
    right.set_title("b   Measurement budget", loc="left", fontweight="bold", pad=12)
    right.legend(handles=[
        Line2D([], [], marker="o", color="#147a72", linestyle="none", label=r"Reference $g^{(2)}(0)<1$"),
        Line2D([], [], marker="o", color="#b86035", linestyle="none", label=r"Reference $g^{(2)}(0)\geq 1$"),
        Line2D([], [], marker="^", markerfacecolor="none", color="#56616a",
               linestyle="none", label="Budget criterion unmet by the cap"),
    ], loc="lower left", frameon=False, fontsize=8.6)

    figure.savefig(args.results / "two_emitter_transfer.png", dpi=230)
    plt.close(figure)


if __name__ == "__main__":
    main()
