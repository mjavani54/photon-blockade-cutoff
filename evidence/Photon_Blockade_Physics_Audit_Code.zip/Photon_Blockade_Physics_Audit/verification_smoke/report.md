# Photon-cutoff physics verification

{
  "schema_version": 1,
  "mode": "smoke",
  "status": "checks_passed",
  "reference_cases_checked": 6,
  "independent_dense_checks": 5,
  "independent_time_integrations": 2,
  "decoupled_emitter_checks": 1,
  "failures": [],
  "worst_reference_g2_shift": 5.7339621863269524e-09,
  "followup_guard_failures_against_larger_reference": 0,
  "actual_new_hardware_jobs": 0,
  "actual_resource_units_used": 0,
  "interpretation": "Finite numerical cross-checks only. Agreement does not prove a universal or infinite-dimensional truncation-error bound."
}

Retain all failures. This run does not refit the multiplier or replace the original known misses. Smoke is a workflow/spot check, not the full transfer verification.
