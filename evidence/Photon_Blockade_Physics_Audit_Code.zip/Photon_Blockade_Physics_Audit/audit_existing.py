"""Audit archived cavity results without repeating their steady-state grids."""

import argparse
from dataclasses import asdict
from hashlib import sha256
import json
from math import ceil, log2
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np


def close(a, b, tol=3e-11):
    return abs(float(a)-float(b)) <= tol*max(1.,abs(float(a)),abs(float(b)))


def rows(path):
    import csv
    with Path(path).open(newline='',encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def moment_check(row, population_key):
    p=np.asarray(json.loads(row[population_key]) if isinstance(row[population_key],str) else row[population_key])
    m=int(row['cutoff']);assert len(p)==m+1 and np.isfinite(p).all() and p.min()>=0 and close(p.sum(),1)
    n=np.arange(m+1);mean=float(p@n);g2=float(p@(n*(n-1))/mean**2)
    assert close(mean,row['mean']) and close(g2,row['g2']), (row['case_id'],m,'moments')
    assert float(row['stationary_residual']) <= 1e-10


def audit(source_root,output):
    source_root=Path(source_root).resolve();output=Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    root=source_root/'extracted'
    pilot=root/'Photon_Blockade_Cutoff_and_Shots_Pilot'
    follow_code=root/'Photon_Blockade_Followup_Code'/'photon_blockade_followup'
    follow=root/'photon_blockade_followup_results'/'photon_blockade_followup_results'
    sys.path.insert(0,str(pilot));import run_study as initial
    sys.path.insert(0,str(follow_code));import run_followup as followup
    rule=json.loads((pilot/'results/rule.json').read_text())
    assert sha256((pilot/'results/calibration_cutoffs.csv').read_bytes()).hexdigest()==rule['calibration_csv_sha256']
    assert (pilot/'results/rule.json').read_bytes()==(follow_code/'pilot_rule.json').read_bytes()
    manifest=json.loads((follow/'manifest.json').read_text())
    for name,want in manifest['input_sha256'].items():
        assert sha256((follow_code/name).read_bytes()).hexdigest()==want,name
    assert manifest['mode']=='full'
    calibration=rows(pilot/'results/calibration_cases.csv');validation=rows(pilot/'results/validation_cases.csv')
    ctrace=rows(pilot/'results/calibration_cutoffs.csv');vtrace=rows(pilot/'results/validation_cutoffs.csv')
    all_cases=calibration+validation;all_trace=ctrace+vtrace
    assert len(calibration)==120 and len(validation)==316 and len(all_trace)==6989
    for row in all_trace:moment_check(row,'probabilities')
    reference={r['case_id']:r for r in all_cases}
    physical_cal,physical_val=initial.study_cases()
    for case,row in zip(physical_cal+physical_val,all_cases,strict=True):
        assert case.case_id==row['case_id'] and case.group==row['group']
        for key in ('drive','cavity_detuning'):assert close(getattr(case,key),row[key])
        for key in ('couplings','emitter_detunings','emitter_decays'):
            assert np.allclose(getattr(case,key),json.loads(row[key]),rtol=1e-14,atol=1e-14)
    candidates=[r for r in ctrace if r['scaled_proposal_score']!='']
    fitted=max(1.,max((float(r['scaled_error'])+initial.REFERENCE_TOLERANCE)/(float(r['scaled_proposal_score'])+initial.REFERENCE_TOLERANCE) for r in candidates))
    assert close(fitted,rule['proposal_multiplier'],1e-14)
    assert all(r['group']=='one_calibration' for r in ctrace)
    by_case={}
    for r in all_trace:
        by_case.setdefault(r['case_id'],{})[int(r['cutoff'])]=r
        ref=reference[r['case_id']]
        expected=abs(float(r['g2'])-float(ref['reference_g2']))/max(1.,float(r['g2']))
        assert close(expected,r['scaled_error'])
    selected=[];higher_reference=[]
    for row in all_cases:
        states=by_case[row['case_id']]
        feasible=[m for m in range(2,16) if rule['proposal_multiplier']*(float(states[m]['scaled_proposal_score'])+initial.REFERENCE_TOLERANCE)<=initial.CUTOFF_TOLERANCE]
        assert int(row['proposed_cutoff'])==min(feasible)
        m=int(row['proposed_cutoff']);err=abs(float(states[m]['g2'])-float(row['reference_g2']))/max(1.,float(states[m]['g2']))
        assert close(err,row['proposed_scaled_error']) and int(row['proposed_pass'])==int(err<=.025)
        assert int(row['proposed_photon_qubits'])==ceil(log2(m+1))
        hi=states[max(states)];refm=int(row['reference_cutoff'])
        shift=abs(float(hi['g2'])-float(row['reference_g2']))/max(1.,float(hi['g2']))
        higher_reference.append({'case_id':row['case_id'],'group':row['group'],'recorded_reference_cutoff':refm,
                                 'highest_cached_cutoff':max(states),'reference_to_highest_cached_scaled_g2_shift':shift})
        selected.append({'case_id':row['case_id'],'group':row['group'],'cutoff':m,'scaled_error':err,'pass':err<=.025})
    summary=json.loads((pilot/'results/summary.json').read_text())
    assert initial.aggregate(all_cases)=={k:v for k,v in summary.items() if k!='frozen_rule_sha256'}
    assert summary['frozen_rule_sha256']==sha256((pilot/'results/rule.json').read_bytes()).hexdigest()
    specifications=followup.make_cases(False)
    assert sha256(followup.json_text([asdict(c) for c in specifications]).encode()).hexdigest()==manifest['case_parameters_sha256']
    cache=[json.loads((follow/'case_cache'/f'{case.case_id}.json').read_text()) for case in specifications]
    assert len(cache)==202
    frows=[];ftrace=[];trace_metrics_checked=0
    for spec,data in zip(specifications,cache,strict=True):
        row=data['case'];states={int(r['cutoff']):r for r in data['cutoffs']};frows.append(row);ftrace.extend(data['cutoffs'])
        assert row['status']=='ok' and spec.case_id==row['case_id']
        for k in ('couplings','emitter_detunings','emitter_decays'):assert np.allclose(getattr(spec,k),row[k],rtol=1e-14,atol=1e-14)
        assert close(spec.drive,row['drive']) and close(spec.cavity_detuning,row['cavity_detuning'])
        for state in states.values():moment_check(state,'populations')
        def state_at(m):
            r=states[m]
            return SimpleNamespace(g2=r['g2'],mean=r['mean'],probabilities=np.asarray(r['populations']))
        trace={};chosen=followup.choose_cutoffs(state_at,trace)
        reference_m,refg,refmean,refchange=followup.solve_reference(state_at,spec)
        assert reference_m==row['reference_cutoff'] and close(refg,row['reference_g2']) and close(refmean,row['reference_mean'])
        assert close(refchange,row['reference_convergence'])
        for m,metrics in trace.items():
            for key,value in metrics.items():assert close(value,states[m][key])
            trace_metrics_checked+=1
        for method,m in chosen.items():
            assert m==row[f'{method}_cutoff']
            error=abs(float(states[m]['g2'])-refg)/max(1.,float(states[m]['g2']))
            assert close(error,row[f'{method}_scaled_error']) and row[f'{method}_cutoff_pass']==(error<=.025)
            assert row[f'{method}_qubits']==ceil(log2(m+1))
    assert len(ftrace)==1930
    # Exact CSV/table reconstruction from the saved typed caches.
    from tempfile import TemporaryDirectory
    with TemporaryDirectory(prefix='cavity_audit_tables_') as tmp:
        tmp=Path(tmp);followup.write_csv(tmp/'cases.csv',frows);followup.write_csv(tmp/'cutoff_trace.csv',ftrace)
        assert (tmp/'cases.csv').read_bytes()==(follow/'cases.csv').read_bytes()
        assert (tmp/'cutoff_trace.csv').read_bytes()==(follow/'cutoff_trace.csv').read_bytes()
    groups={g:followup.summarize([r for r in frows if r['group']==g]) for g in (*followup.FAMILY_RANGES,'known_miss','empty')}
    groups['all_new_two_emitter_cases']=followup.summarize([r for r in frows if r['group'] in followup.FAMILY_RANGES])
    assert groups==json.loads((follow/'summary.json').read_text())
    # Five numerical sampling replays; no steady-state grid is rerun here.
    replay=[]
    for cid in ('S037','M037','polariton-027-equal','strong_drive-019-unequal','empty-01'):
        data=next(d for d in cache if d['case']['case_id']==cid);r=data['case'];s=next(s for s in data['cutoffs'] if s['cutoff']==r['guard_cutoff'])
        state=SimpleNamespace(g2=s['g2'],mean=s['mean'],probabilities=np.asarray(s['populations']))
        sampled=followup.compare_shot_plans(state,r['reference_g2'],cid)
        for key,value in sampled.items():
            if isinstance(value,float):assert close(value,r[key]),(cid,key)
            else:assert value==r[key],(cid,key)
        replay.append(cid)
    import csv
    with (output/'cached_reference_checks.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(higher_reference[0]));writer.writeheader();writer.writerows(higher_reference)
    report={'status':'passed','calibration_one_emitter_cases':120,'one_emitter_holdout_cases':64,
            'initial_two_emitter_cases':240,'initial_two_emitter_passes':summary['two_combined']['cutoff']['proposed']['passes'],
            'initial_misses':[r['case_id'] for r in all_cases if r['group'].startswith('two_') and int(r['proposed_pass'])==0],
            'frozen_multiplier_reproduced':fitted,'frozen_rule_and_source_hashes_verified':True,
            'initial_cached_distributions_checked':len(all_trace),'followup_cached_distributions_checked':len(ftrace),
            'followup_new_two_emitter_cases':192,'followup_guard_passes':groups['all_new_two_emitter_cases']['cutoffs']['guard']['within_error_budget'],
            'followup_pilot_passes':groups['all_new_two_emitter_cases']['cutoffs']['pilot']['within_error_budget'],
            'followup_guard_worst_scaled_error':groups['all_new_two_emitter_cases']['cutoffs']['guard']['worst_scaled_error'],
            'guard_recovers_known_misses':groups['known_miss']['guard_recovers_cutoff_miss'],
            'followup_extra_photon_qubit_cases':groups['all_new_two_emitter_cases']['additional_photon_qubit_cases'],
            'followup_summaries_and_tables_reproduced':True,'followup_lookahead_rows_reproduced':trace_metrics_checked,
            'sampled_shot_plan_replays':replay,
            'initial_worst_reference_vs_highest_cached_scaled_g2_shift':max(r['reference_to_highest_cached_scaled_g2_shift'] for r in higher_reference),
            'initial_cached_reference_shifts_over_2e_minus6':sum(r['reference_to_highest_cached_scaled_g2_shift']>2e-6 for r in higher_reference),
            'independent_dense_or_time_solver_record_in_original_summary':False,
            'reference_limit':'Consecutive-cutoff convergence and small stationary residuals are empirical numerical checks, not rigorous infinite-dimensional steady-state error bounds.',
            'actual_new_hardware_jobs':0,'actual_resource_units_used':0,'steady_state_grids_recomputed':False}
    (output/'existing_evidence_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sources',type=Path,required=True)
    parser.add_argument('--out',type=Path,default=Path(__file__).parent)
    args=parser.parse_args();audit(args.sources,args.out)
