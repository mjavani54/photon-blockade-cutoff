# Evidence audit: photon cutoff, shots, and transfer

## Assessment

The saved results support an empirical cutoff-selection study with transfer tests from one emitter to two emitters. They do not support a universal cutoff guarantee. The revised guard has a clean result on the supplied new test set, but its additional register cost must be reported. The IBM experiments test readout and allocation for prescribed number-label mixtures; they do not simulate driven cavity dynamics on the processor.

The next useful action is to run the larger-reference verification in this package. It addresses numerical reproducibility before adding further hardware experiments. Passing it would strengthen the existing numerical evidence; it would not, by itself, establish novelty or a rigorous truncation bound.

## Physical model and error definition

The archived solver uses a driven Jaynes-Cummings / Tavis-Cummings Hamiltonian, independent vacuum Lindblad cavity and emitter losses, and cavity decay rate kappa=1. Couplings, detunings, emitter decay rates, and drive amplitudes are preserved in the supplied archives and generated check records. Photon cutoff m retains photon numbers 0 through m, so the photon space has dimension m+1.

The reported cutoff error is

```text
abs(g2_at_selected_cutoff - g2_at_reference) / max(1, g2_at_selected_cutoff).
```

Thus the 2.5% budget is an absolute g2 error budget of 0.025 when the selected g2 is below one, and a relative error budget above one. It should be called a **scaled error budget**, not uniformly a 2.5% relative error.

## Reproduced evidence

| Stage | Audit result | Interpretation |
| --- | --- | --- |
| One-emitter calibration | 120 cases; multiplier 1.645991686678409 reproduced | Calibration only; no two-emitter cases used to fit this multiplier |
| One-emitter holdout | 64/64 within the cutoff budget | Descriptive performance on the specified holdout set |
| Initial two-emitter transfer | 238/240 within budget | Two misses must be retained: S037 and M037 |
| Original rule on new follow-up cases | 191/192 within budget | The original one-lookahead rule still has a miss |
| Revised two-level guard | 192/192 new cases within budget | Empirical validation of a guard designed after inspecting the initial misses |
| Guard worst new-case scaled error | 0.016826562999418523 | Below the 0.025 budget on this set |
| Guard register cost | Extra photon-register qubit in 14/192 cases | The improvement has a resource cost |
| Known misses revisited | Guard recovers both | Diagnostic recovery; exclude from the 192 new cases |
| Initial reference consistency | Worst scaled g2 shift 2.7018731854338542e-8 against the highest cached cutoff | Strong cached numerical consistency; not an infinite-dimensional certificate |

The initial study contains 120 one-emitter calibration cases, 64 one-emitter holdout cases, 240 two-emitter cases, and 12 empty-cavity controls. The follow-up contains 192 new two-emitter cases, the two known misses, and eight empty-cavity controls. The new two-emitter set uses 32 scrambled Sobol points in each of three parameter families, with equal and unequal coupling variants. These paired structured cases are not 192 independent draws from a population of all possible cavities. A zero-miss result does not justify a binomial generalization guarantee.

The one-emitter multiplier was frozen before initial transfer. The revised guard adds two-cutoff lookahead after inspecting the two initial misses, while retaining that multiplier. Report this sequence explicitly. Pooling the original and follow-up tests as though a single unchanged rule passed all cases would misrepresent the experiment.

The two initial misses occur for drive 0.8, zero cavity detuning, collective coupling 0.9, and base emitter decay 0.38. The selected cutoff is m=7; their scaled errors are approximately 0.0253963 and 0.0251386. They are small budget overruns, but they still falsify a claim that the original rule always meets its target.

For context, the initial two-emitter fixed-m=3 baseline passed 139/240 cases, the boundary-population rule passed 206/240, and the adjacent-change rule passed 238/240. Equal pass counts do not imply equal errors or cost. The moment-aware and adjacent-change rules both passed 238/240, with worst scaled errors approximately 2.54% and 12.81%, respectively. The proposed rule required a four-qubit photon register in six cases, versus 27 for the adjacent-change rule and 38 for the boundary rule. These are photon-register counts only: emitter qubits, dynamics simulation, state preparation, and classical planning are outside those figures.

## What the audit reproduced

The executable archived-data audit checked 6,989 initial and 1,930 follow-up cached distributions, recomputed their moments, verified source fingerprints and physical parameter generation, reproduced the frozen multiplier and cutoff choices, and reconstructed the follow-up tables and summary from typed case caches. It also reproduced 766 saved lookahead rows and five selected shot-plan simulations. This is not a rerun of every Monte Carlo experiment.

The original README describes dense-solver, time-integration, and decoupled-emitter spot checks. The inspected summary does not preserve numerical records for those checks. This package supplies executable independent checks and saves their records; it does not assume the earlier spot checks were never performed.

The preparation smoke run checks six larger-reference points, five independent dense solutions, two direct time integrations, and one decoupled-emitter reduction. Its 14 checks passed. The maximum old-reference-to-larger-reference scaled g2 shift among those six points was 5.7339621863269524e-9. The full verification remains to be run locally.

The default full protocol covers all 202 follow-up records plus 15 initial stress points. It includes C117, whose m=4 result sets the archived calibration envelope. It does not refit that envelope. Dense construction and time integration check the finite-dimensional generator at m=4; the larger-cutoff checks assess reference convergence separately. Agreement between these checks still does not bound every possible omitted tail or parameter regime.

## Shots, pilots, and cost accounting

Shot planning and interval coverage must be distinguished. The original simultaneous 95% tail-probability intervals and a separate 95% planning-count event provide a union-bound joint guarantee of at least 90% for simultaneous coverage and planned width, under their stated assumptions. They do not imply a 95% unconditional joint guarantee. Preserve the separate coverage, width, and decision endpoints.

The allocation and finite-pilot result manifests match the corresponding archived input/code fingerprints. In the finite-pilot results, 36,864 trial rows represent 4,608 distinct pilot draws reused across eight policy/goal comparisons. Analyses comparing policies should preserve that pairing. Counting all rows as independent pilot experiments inflates the effective sample size.

The saved finite-pilot expenditure identity was verified: pilot shots plus the selected calibration shots plus signal science shots, or pilot shots alone if no plan was selected. The matched control science observations in that early experiment are a separate validation diagnostic, as described by its README. Later paired hardware experiments charge both populations. Do not compare these totals as though they have identical experimental scope.

## Relationship to hardware

The hardware mixture used for the later readout work matches the cutoff-m=3 distribution of `polariton-027-equal` exactly. Its finite-mixture g2 is 0.5437676426767554; the cavity reference is 0.5450050331780175, an absolute difference of 0.0012373905012621478. This links the hardware test target to a simulated physical case.

The processor prepares prescribed computational-basis labels using X gates and measures them. That validates a readout/allocation task for this target distribution. It does not demonstrate photon blockade, transfer of a cavity Hamiltonian on hardware, quantum state-preparation advantage, or a quantum speedup. Hardware sampling uncertainty and physical cutoff bias are different contributions and should be reported separately.

The later refined replication design is already frozen and requires much more hardware time than the previously reported remaining allowance. No new processor collection is needed for the numerical verification supplied here.

## Defensible research claim

A suitable claim is: a one-emitter-calibrated, moment-aware cutoff heuristic was evaluated on specified two-emitter families, and a subsequently designed two-level guard reduced observed budget violations with a measurable register-cost tradeoff. Shot allocation and finite-pilot planning were studied under explicit statistical and readout models.

Avoid claims of the first adaptive photon cutoff, a rigorous truncation certificate, universal transfer, physical photon-blockade observation on the IBM device, or quantum advantage. Novelty must be argued against existing truncation/error-estimation and blockade literature, rather than inferred from successful tests alone.

Relevant primary literature checked for positioning:

- Etienney, Robin, and Rouchon, *A posteriori error estimates for the Lindblad master equation*, Quantum 10, 2031 (2026): https://quantum-journal.org/papers/q-2026-03-16-2031/ . This work supplies explicit a posteriori error bounds; the empirical convergence checks here should not be presented as equivalent certification.
- Marinelli et al., *Photon blockade in a Tavis-Cummings system*, Physical Review Applied 24, 044103 (2025): https://journals.aps.org/prapplied/abstract/10.1103/st87-3cxz . Multi-emitter photon blockade itself is an established research subject.

## Decision after the local run

If the full result reports `checks_passed`, use the saved numerical records to strengthen the methods and reproducibility package, then consolidate the manuscript around the empirical cutoff/shot-allocation contribution. If any check fails, inspect it before changing the rule, tolerance, or test set. A revised method requires a recorded revision and a fresh validation set; deleting inconvenient failures would invalidate the transfer argument.
