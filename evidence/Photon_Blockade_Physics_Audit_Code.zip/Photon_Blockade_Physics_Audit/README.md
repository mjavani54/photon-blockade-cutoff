# Photon-blockade physics audit

This package checks the numerical foundation of the photon-cutoff transfer study before manuscript preparation. It contains the original source archives, an audit of saved results, and additional numerical checks. Everything runs on your CPU. There is no IBM connection, API-key prompt, hardware submission, or RU usage.

Read `EVIDENCE_AUDIT.md` for the findings and limits of the current evidence. The original rule passed 238/240 initial two-emitter cases. The revised guard passed 192/192 new two-emitter cases, with an additional photon-register qubit in 14 cases. These are empirical results over specified test sets.

## Run in Bash / WSL

Extract `Photon_Blockade_Physics_Audit_Code.zip`, open a terminal in its extracted parent directory, and run:

```bash
cd Photon_Blockade_Physics_Audit
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
bash run.sh --smoke --workers 2
```

The supplied workflow was tested with Python 3.12.14, NumPy 2.5.5, and SciPy 1.18.1. Other Python versions were not tested here. If an existing environment already contains these dependencies, activate it and omit the environment-creation steps. The Bash launcher uses `python3`; set `PHOTON_PYTHON` to another interpreter if needed.

After smoke reports `"status": "checks_passed"`, run the full verification:

```bash
bash run.sh --workers 2
```

Upload this generated file for analysis:

```text
physics_audit_results/Photon_Blockade_Physics_Audit_Results.zip
```

The folder is inside `Photon_Blockade_Physics_Audit`. The terminal also prints its absolute path. If any check reports `checks_need_review`, upload the ZIP with the failed checks preserved. A finished process alone does not mean all numerical checks passed.

Use one worker if memory is limited:

```bash
bash run.sh --workers 1
```

Run the same command after an interruption to reuse completed checks. Failed numerical checks are also retained, rather than silently retried. Changing code, dependency versions, reference settings, or the check selection requires a new output folder, for example `--out physics_audit_results_v2`. Do not run two commands against the same output folder simultaneously. Keep the extracted source and input files unchanged during a run.

## What runs

| Check | Smoke | Default full run |
| --- | ---: | ---: |
| Archived-data and frozen-rule audit | Complete | Complete |
| Larger-reference cases | 6 | 217 |
| Additional sparse cutoffs per reference case | 2 | 2 |
| Independently constructed dense stationary solutions | 5 | 5 |
| Direct density-matrix time integrations | 2 | 2 |
| Decoupled-emitter reduction | 1 | 1 |
| Hardware jobs / RUs | 0 / 0 | 0 / 0 |

The default full run covers all 202 follow-up records: 192 new two-emitter cases, two previously known failures, and eight empty-cavity controls. It also covers 15 selected initial stress points, including the case that sets the calibration-envelope multiplier. The deterministic initial stress selection uses archived results; it is a numerical diagnostic, not a new statistical holdout. The exact list is in `planned_full_checks.json`.

For every selected reference, the program solves at the archived reference cutoff plus four and plus eight. It checks both the original-to-larger and larger-to-larger changes in scaled photon correlation and relative mean photon number against `2e-6`. The selected cutoff is then scored against the larger reference without refitting the multiplier or changing its selection. Original known failures remain failures in the historical result.

The independent dense and time-integration checks use photon cutoff `m=4` and compare implementations at that same finite cutoff. Empty-cavity points also have analytic Poisson checks. All thresholds and physical parameters are saved in the result records. Numerical agreement is evidence of consistency, not a proof of an infinite-dimensional error bound.

To check larger references for every initial case as well, optionally run this more expensive extension in a separate folder:

```bash
bash run.sh --all-pilot --workers 2 --out physics_audit_all_pilot
```

It covers 638 records, with two additional reference solves per record. It is not necessary for the first upload. The default full scientific run and this optional extension have **not** been run here; the included local verification covers the smoke protocol and restart/archive integrity.

## Files to inspect

- `EVIDENCE_AUDIT.md`: claim-by-claim interpretation and limitations.
- `claims.csv`: compact evidence ledger.
- `existing_evidence_audit.json`: reproduced historical cutoff/transfer results.
- `development_lineage_audit.json`: allocation, finite-pilot, and hardware-target lineage checks.
- `cached_reference_checks.csv`: all 436 initial references compared with the highest cached cutoff.
- `workflow_verification.json`: smoke and restart checks performed when preparing this package.
- `verification_smoke/`: raw records and summary of the preparation smoke run.
- `source_manifest.json`: source archive identities and SHA-256 hashes.
- `input/`: three unchanged physics source/result archives needed by the executable audit.
- `SOURCE_SHA256SUMS.json`: integrity hashes for the delivered package files.

Each run creates `config.json`, per-check JSON records, archived-evidence audit files, `verification_summary.json`, and a result ZIP with its own hash manifest. The program verifies the original input archives, source hashes, and completed result hashes. No external data download is needed after installing the two dependencies.
