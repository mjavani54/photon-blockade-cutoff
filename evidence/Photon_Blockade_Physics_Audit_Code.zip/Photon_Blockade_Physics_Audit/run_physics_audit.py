"""Additional classical numerical checks; no quantum hardware connection."""

import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import asdict
from hashlib import sha256
from importlib.metadata import version
import json
import multiprocessing
import os
from pathlib import Path
import subprocess
import sys
from zipfile import ZipFile,ZIP_DEFLATED

import numpy as np
from scipy.stats import poisson

from frozen_core.cavity import Case,solve_steady_state
from independent_checks import dense_steady,integrate_steady

HERE=Path(__file__).resolve().parent


@contextmanager
def run_lock(folder):
    with (folder/'audit.lock').open('a+b') as stream:
        if os.name=='nt':
            import msvcrt
            stream.write(b'0');stream.flush();stream.seek(0)
            msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        try:yield
        finally:
            if os.name=='nt':
                stream.seek(0);msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(stream.fileno(),fcntl.LOCK_UN)


def digest(value):
    return sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.part');tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)


def source_hashes():
    names=('run_physics_audit.py','independent_checks.py','audit_existing.py','frozen_core/cavity.py','input_hashes.json')
    return {n:sha256((HERE/n).read_bytes()).hexdigest() for n in names}


def prepare_sources(folder):
    hashes=json.loads((HERE/'input_hashes.json').read_text())
    assert sha256((HERE/'frozen_core/cavity.py').read_bytes()).hexdigest()==hashes['frozen_cavity_sha256']
    for name,want in hashes['archives'].items():
        source=HERE/'input'/name
        if sha256(source.read_bytes()).hexdigest()!=want:raise ValueError(f'Input archive changed: {name}')
        with ZipFile(source) as z:
            if z.testzip() is not None:raise ValueError(f'Archive CRC error: {name}')
            for member in z.infolist():
                relative=Path(member.filename)
                if relative.is_absolute() or '..' in relative.parts:raise ValueError('Unsafe archived path')
                if member.is_dir() or '__MACOSX' in relative.parts:continue
                target=folder/'extracted'/source.stem/relative
                target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(member))
    return hashes


def csv_rows(path):
    import csv
    with path.open(newline='') as stream:return list(csv.DictReader(stream))


def parameters(row):
    return {k:(json.loads(row[k]) if isinstance(row[k],str) else row[k]) for k in ('couplings','emitter_detunings','emitter_decays')}|{
        'drive':float(row['drive']),'cavity_detuning':float(row['cavity_detuning'])}


def registry(sources):
    root=sources/'extracted';pilot=root/'Photon_Blockade_Cutoff_and_Shots_Pilot'/'results'
    follow=root/'photon_blockade_followup_results'/'photon_blockade_followup_results'
    initial=csv_rows(pilot/'calibration_cases.csv')+csv_rows(pilot/'validation_cases.csv')
    records={}
    for r in initial:
        records['initial:'+r['case_id']]={'key':'initial:'+r['case_id'],'case_id':r['case_id'],'cohort':'initial',
            'group':r['group'],'parameters':parameters(r),'reference_cutoff':int(r['reference_cutoff']),
            'reference_g2':float(r['reference_g2']),'reference_mean':float(r['reference_mean']),
            'selected_g2':float(r['selected_g2']),'selected_cutoff':int(r['proposed_cutoff']),
            'original_cutoff_pass':bool(int(r['proposed_pass']))}
    for path in sorted((follow/'case_cache').glob('*.json')):
        r=json.loads(path.read_text())['case']
        records['followup:'+r['case_id']]={'key':'followup:'+r['case_id'],'case_id':r['case_id'],'cohort':'followup',
            'group':r['group'],'parameters':parameters(r),'reference_cutoff':int(r['reference_cutoff']),
            'reference_g2':float(r['reference_g2']),'reference_mean':float(r['reference_mean']),
            'selected_g2':float(r['selected_g2']),'selected_cutoff':int(r['guard_cutoff']),
            'original_cutoff_pass':bool(r['guard_cutoff_pass'])}
    assert len(records)==638
    return records,initial


def choose_reference_cases(records,initial,smoke,all_pilot):
    if smoke:
        keys=['followup:S037','followup:M037','followup:polariton-027-equal','followup:strong_drive-019-unequal','initial:C001','initial:E11']
    else:
        keys=[k for k in records if k.startswith('followup:')]
        # Fixed, outcome-independent-of-the-new-check stress selection from
        # archived results; these are diagnostic points, not a new holdout.
        if all_pilot:keys += [k for k in records if k.startswith('initial:')]
        else:
            target=[]
            for sort_key in (lambda r:float(r['reference_mean']),lambda r:-float(r['reference_g2']),lambda r:-float(r['proposed_scaled_error'])):
                target += sorted(initial,key=sort_key)[:3]
            hold=[r for r in initial if r['group']=='one_holdout']
            target += sorted(hold,key=lambda r:float(r['reference_mean']))[:2]
            # C117 supplies the archived calibration envelope maximum (at m=4).
            keys += ['initial:'+r['case_id'] for r in target]+['initial:C001','initial:C117','initial:H001','initial:E01','initial:E11']
    return [records[k] for k in dict.fromkeys(keys)]


def solve(record,cutoff):
    p=record['parameters']
    case=Case(record['case_id'],record['group'],'',p['drive'],p['cavity_detuning'],
              tuple(p['couplings']),tuple(p['emitter_detunings']),tuple(p['emitter_decays']))
    return solve_steady_state(case,cutoff)


def reference_check(record,settings):
    m=record['reference_cutoff'];targets=[m+4,m+8]
    if max(targets)>settings['reference_cap']:raise ValueError('Reference cap prevents the two specified larger-cutoff checks')
    states=[solve(record,n) for n in targets];a,b=states
    scale=max(1.,b.g2)
    shifts={'old_to_high_scaled_g2':abs(record['reference_g2']-b.g2)/scale,
            'new_pair_scaled_g2':abs(a.g2-b.g2)/scale,
            'old_to_high_relative_mean':abs(record['reference_mean']-b.mean)/b.mean,
            'new_pair_relative_mean':abs(a.mean-b.mean)/b.mean}
    new_error=abs(record['selected_g2']-b.g2)/max(1.,record['selected_g2'])
    result={'case_key':record['key'],'reference_cutoffs_checked':targets,**shifts,
            'new_high_reference_g2':b.g2,'new_high_reference_mean':b.mean,
            'selected_cutoff_scaled_error_against_high':new_error,
            'archived_rule_pass':record['original_cutoff_pass'],'rule_pass_against_high':new_error<=.025,
            'higher_reference_check_passed':max(shifts.values())<=settings['reference_tolerance']}
    if not record['parameters']['couplings']:
        p=record['parameters'];mu=p['drive']**2/(.25+p['cavity_detuning']**2)
        q=poisson.pmf(np.arange(targets[-1]+1),mu)
        tv=.5*(float(np.abs(b.probabilities-q).sum())+float(poisson.sf(targets[-1],mu)))
        result['analytic_control']={'mean':mu,'g2_error':abs(b.g2-1),'relative_mean_error':abs(b.mean/mu-1),'total_variation':tv}
        result['analytic_control_passed']=max(abs(b.g2-1),abs(b.mean/mu-1),tv)<=settings['reference_tolerance']
    return result


def independent_check(record,kind,settings):
    cutoff=4;sparse=solve(record,cutoff)
    independent=dense_steady(record['parameters'],cutoff) if kind=='dense' else integrate_steady(record['parameters'],cutoff,settings['integration_time'])
    difference=float(np.abs(sparse.probabilities-np.asarray(independent['probabilities'])).sum())
    gdiff=abs(sparse.g2-independent['g2'])/max(1.,sparse.g2)
    mdiff=abs(sparse.mean-independent['mean'])/sparse.mean
    valid=(difference<=2e-7 and gdiff<=2e-6 and mdiff<=2e-6 and independent['residual_max']<=1e-7
           and independent['trace_error']<=1e-8 and independent['hermiticity_error']<=1e-8
           and independent['minimum_density_eigenvalue']>=-1e-8)
    return {'case_key':record['key'],'cutoff':cutoff,'independent_method':kind,'photon_probability_l1_difference':difference,
            'scaled_g2_difference':gdiff,'relative_mean_difference':mdiff,'independent_diagnostics':independent,
            'independent_solver_check_passed':bool(valid)}


def reduction_check(record):
    base=solve(record,4)
    p=dict(record['parameters']);p['couplings']=list(p['couplings'])+[0.]
    p['emitter_detunings']=list(p['emitter_detunings'])+[.37];p['emitter_decays']=list(p['emitter_decays'])+[.23]
    expanded={**record,'parameters':p}
    other=solve(expanded,4);delta=float(np.abs(base.probabilities-other.probabilities).sum())
    return {'case_key':record['key'],'cutoff':4,'decoupled_emitter_probability_l1_difference':delta,
            'scaled_g2_difference':abs(base.g2-other.g2)/max(1.,base.g2),'decoupled_reduction_passed':delta<=1e-9}


def run_task(task):
    if source_hashes()!=task['sources']:raise ValueError('Audit code changed after this run began')
    path=Path(task['path']);spec={k:task[k] for k in ('kind','record','settings','config_sha256')}
    key=digest(spec)
    if path.exists():
        record=json.loads(path.read_text())
        if record['spec_sha256']!=key or digest({k:v for k,v in record.items() if k!='result_sha256'})!=record['result_sha256']:
            raise ValueError('Cached numerical check differs or is damaged')
        return {'path':str(path),'reused':True}
    try:
        if task['kind']=='reference':value=reference_check(task['record'],task['settings'])
        elif task['kind'] in ('dense','integration'):value=independent_check(task['record'],task['kind'],task['settings'])
        else:value=reduction_check(task['record'])
        body={'status':'completed','result':value}
    except Exception as error:
        body={'status':'numerical_issue','error_type':type(error).__name__,'error':str(error)}
    if source_hashes()!=task['sources']:raise ValueError('Audit code changed during a numerical check')
    result={**spec,'spec_sha256':key,'provenance':'classical_numerical_audit',**body,'actual_new_hardware_jobs':0}
    result['result_sha256']=digest(result);atomic_json(path,result)
    return {'path':str(path),'reused':False}


def summarize(folder,config,tasks):
    records=[json.loads(Path(t['path']).read_text()) for t in tasks]
    failures=[];references=[]
    for record in records:
        if record['status']!='completed':failures.append({'kind':record['kind'],'case':record['record']['key'],'reason':record.get('error')});continue
        value=record['result']
        if record['kind']=='reference':
            references.append(value)
            ok=value['higher_reference_check_passed'] and value.get('analytic_control_passed',True)
            if record['record']['cohort']=='followup':ok=ok and value['rule_pass_against_high']
        elif record['kind']=='reduction':ok=value['decoupled_reduction_passed']
        else:ok=value['independent_solver_check_passed']
        if not ok:failures.append({'kind':record['kind'],'case':record['record']['key'],'reason':'A predeclared numerical threshold failed'})
    status={'schema_version':1,'mode':'smoke' if config['smoke'] else 'full','status':'checks_passed' if not failures else 'checks_need_review',
            'reference_cases_checked':len(references),'independent_dense_checks':sum(r['kind']=='dense' for r in records),
            'independent_time_integrations':sum(r['kind']=='integration' for r in records),
            'decoupled_emitter_checks':sum(r['kind']=='reduction' for r in records),'failures':failures,
            'worst_reference_g2_shift':max((r['old_to_high_scaled_g2'] for r in references),default=None),
            'followup_guard_failures_against_larger_reference':sum(not r['result']['rule_pass_against_high'] for r in records if r['kind']=='reference' and r['record']['cohort']=='followup' and r['status']=='completed'),
            'actual_new_hardware_jobs':0,'actual_resource_units_used':0,
            'interpretation':'Finite numerical cross-checks only. Agreement does not prove a universal or infinite-dimensional truncation-error bound.'}
    atomic_json(folder/'verification_summary.json',status)
    (folder/'report.md').write_text('# Photon-cutoff physics verification\n\n'+json.dumps(status,indent=2)+'\n\nRetain all failures. This run does not refit the multiplier or replace the original known misses. Smoke is a workflow/spot check, not the full transfer verification.\n')
    return status


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--smoke',action='store_true')
    parser.add_argument('--workers',type=int,default=2)
    parser.add_argument('--all-pilot',action='store_true',help='Also recompute larger references for all 436 initial cases')
    parser.add_argument('--reference-cap',type=int,default=40)
    parser.add_argument('--integration-time',type=float,default=600.)
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    if args.workers<1 or args.reference_cap<20 or not np.isfinite(args.integration_time) or args.integration_time<=0:parser.error('Invalid worker count, cutoff cap, or integration time')
    folder=args.out or HERE/('physics_audit_smoke' if args.smoke else 'physics_audit_results')
    folder.mkdir(parents=True,exist_ok=True)
    with run_lock(folder):execute(args,folder)


def execute(args,folder):
    sources=HERE/'source_data';inputs=prepare_sources(sources)
    subprocess.run([sys.executable,str(HERE/'audit_existing.py'),'--sources',str(sources),'--out',str(folder/'archived_evidence')],check=True)
    records,initial=registry(sources)
    reference_cases=choose_reference_cases(records,initial,args.smoke,args.all_pilot)
    settings={'reference_tolerance':2e-6,'reference_cap':args.reference_cap,'integration_time':args.integration_time}
    tasks=[]
    for r in reference_cases:tasks.append({'kind':'reference','record':r})
    for key in ('initial:C001','initial:H001','followup:S037','followup:M037','followup:polariton-027-equal'):
        tasks.append({'kind':'dense','record':records[key]})
    for key in ('followup:S037','followup:polariton-027-equal'):tasks.append({'kind':'integration','record':records[key]})
    tasks.append({'kind':'reduction','record':records['initial:C001']})
    config={'protocol_id':'photon-cutoff-physics-audit-v1','smoke':args.smoke,'all_pilot':args.all_pilot,'settings':settings,
            'input_hashes':inputs,'sources':source_hashes(),'packages':{n:version(n) for n in ('numpy','scipy')},
            'checks':deepcopy(tasks),'actual_new_hardware_jobs':0}
    cfg=folder/'config.json'
    if cfg.exists() and json.loads(cfg.read_text())!=config:raise ValueError('This directory has different code or settings. Use the original version or a new --out folder')
    atomic_json(cfg,config)
    namespace=digest(config)
    for task in tasks:
        key=task['record']['key'].replace(':','_')
        task.update(settings=settings,sources=config['sources'],config_sha256=namespace,path=str(folder/'checks'/f"{task['kind']}_{key}.json"))
    print(f"{'Smoke' if args.smoke else 'Full'} classical audit: {len(reference_cases)} larger-reference points and 8 independent checks. Zero IBM jobs or RUs.",flush=True)
    context=multiprocessing.get_context('spawn')
    with ProcessPoolExecutor(max_workers=args.workers,mp_context=context) as pool:
        for index,future in enumerate(as_completed([pool.submit(run_task,t) for t in tasks]),1):
            result=future.result();print(f"  {index}/{len(tasks)} {'reused' if result['reused'] else 'completed'} {Path(result['path']).stem}",flush=True)
    if source_hashes()!=config['sources']:raise ValueError('Audit code changed during the run')
    status=summarize(folder,config,tasks)
    files=sorted(p for p in folder.rglob('*') if p.is_file() and p.suffix not in ('.zip','.part') and p.name not in ('result_sha256.json','audit.lock'))
    atomic_json(folder/'result_sha256.json',{p.relative_to(folder).as_posix():sha256(p.read_bytes()).hexdigest() for p in files})
    archive=folder/f"Photon_Blockade_Physics_Audit_{'Smoke' if args.smoke else 'Results'}.zip"
    with ZipFile(archive.with_suffix('.part'),'w',compression=ZIP_DEFLATED) as z:
        for p in files+[folder/'result_sha256.json']:z.write(p,p.relative_to(folder).as_posix())
    archive.with_suffix('.part').replace(archive)
    print(json.dumps(status,indent=2),flush=True);print(f'Finished. Upload {archive.resolve()}',flush=True)


if __name__=='__main__':main()
