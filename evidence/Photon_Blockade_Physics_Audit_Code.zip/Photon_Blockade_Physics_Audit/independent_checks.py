"""Independent dense density-operator checks for the archived cavity model."""

from functools import reduce

import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import solve


def operators(parameters, cutoff):
    """Construct dense operators independently of the sparse-vectorized source."""
    emitters=len(parameters['couplings']);n=cutoff+1
    destroy=np.zeros((n,n),dtype=complex)
    for photon in range(1,n):destroy[photon-1,photon]=np.sqrt(photon)
    a=np.kron(destroy,np.eye(2**emitters))
    h=parameters['cavity_detuning']*(a.conj().T@a)+parameters['drive']*(a+a.conj().T)
    jumps=[a]
    for i,(coupling,delta,gamma) in enumerate(zip(parameters['couplings'],parameters['emitter_detunings'],parameters['emitter_decays'],strict=True)):
        factors=[np.eye(n)]+[np.array([[0.,1.],[0.,0.]]) if j==i else np.eye(2) for j in range(emitters)]
        sm=reduce(np.kron,factors)
        h=h+delta*(sm.conj().T@sm)+coupling*(a.conj().T@sm+a@sm.conj().T)
        jumps.append(np.sqrt(gamma)*sm)
    return h,jumps


def generator(h,jumps):
    products=[j.conj().T@j for j in jumps]
    def rhs(rho):
        result=-1j*(h@rho-rho@h)
        for j,q in zip(jumps,products,strict=True):
            result=result+j@rho@j.conj().T-.5*(q@rho+rho@q)
        return result
    return rhs


def diagnostics(rho,rhs,cutoff):
    raw=rho.diagonal().real.reshape(cutoff+1,-1).sum(axis=1)
    mean=float(raw@np.arange(cutoff+1))
    if mean<=0:raise ArithmeticError('Nonpositive photon mean')
    g2=float(raw@(np.arange(cutoff+1)*(np.arange(cutoff+1)-1))/mean**2)
    return {'probabilities':raw.tolist(),'mean':mean,'g2':g2,
            'residual_max':float(np.max(np.abs(rhs(rho)))),
            'trace_error':float(abs(np.trace(rho)-1)),
            'hermiticity_error':float(np.max(np.abs(rho-rho.conj().T))),
            'minimum_density_eigenvalue':float(np.linalg.eigvalsh((rho+rho.conj().T)/2)[0])}


def dense_steady(parameters,cutoff):
    h,jumps=operators(parameters,cutoff);rhs=generator(h,jumps);d=len(h)
    # Apply the density-matrix equation to every matrix unit explicitly.
    # This avoids reusing any Kronecker-vectorization formula from cavity.py.
    matrix=np.empty((d*d,d*d),dtype=complex)
    for column in range(d*d):
        i,j=column%d,column//d
        basis=np.zeros((d,d),dtype=complex);basis[i,j]=1
        matrix[:,column]=rhs(basis).reshape(-1,order='F')
    matrix[0,:]=0;matrix[0,np.arange(d)*(d+1)]=1
    target=np.zeros(d*d,dtype=complex);target[0]=1
    rho=solve(matrix,target,assume_a='gen').reshape((d,d),order='F')
    return diagnostics(rho,rhs,cutoff)


def integrate_steady(parameters,cutoff,final_time):
    h,jumps=operators(parameters,cutoff);rhs=generator(h,jumps);d=len(h)
    initial=np.zeros((d,d),dtype=complex);initial[0,0]=1
    def derivative(t,vector):return rhs(vector.reshape((d,d),order='F')).reshape(-1,order='F')
    solution=solve_ivp(derivative,(0,float(final_time)),initial.reshape(-1,order='F'),method='DOP853',
                       atol=2e-11,rtol=2e-10,t_eval=[float(final_time)])
    if not solution.success:raise ArithmeticError(solution.message)
    result=diagnostics(solution.y[:,-1].reshape((d,d),order='F'),rhs,cutoff)
    result.update(final_time=float(final_time),derivative_evaluations=int(solution.nfev))
    return result
